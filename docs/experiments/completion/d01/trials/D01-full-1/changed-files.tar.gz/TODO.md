# MokioClaw Todo

## Plan

Done: take_batch validates limit first, then slices and deletes at most limit items from the front. Visible tests pass (2 passed) and boundary self-checks pass.

## Todos

- [x] **todo-1** `completed` Rewrite take_batch in src/batch_queue.py: validate limit<0 (raise ValueError before any mutation), slice at most limit items FIFO, del items[:n], return batch.
- [x] **todo-2** `completed` Run PYTHONPATH=src:. python -m pytest -q and self-check boundaries (limit=0, limit<0 with empty/non-empty list, drain, empty queue).

## Acceptance Criteria

- take_batch returns at most limit items in FIFO order and removes them from items
- Remaining items keep their original relative order
- limit=0 returns [] and does not consume any item
- limit<0 raises ValueError and leaves items unchanged (including empty list)
- Normal drain (limit >= len) and empty-queue behavior preserved
- Visible tests pass with PYTHONPATH=src:. python -m pytest -q
- Only src/batch_queue.py modified

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
