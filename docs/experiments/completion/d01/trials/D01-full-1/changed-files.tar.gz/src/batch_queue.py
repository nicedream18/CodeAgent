def take_batch(items, limit):
    """Remove a FIFO batch from a mutable list."""
    if limit < 0:
        raise ValueError("limit must be non-negative")
    n = min(limit, len(items))
    batch = items[:n]
    del items[:n]
    return batch
