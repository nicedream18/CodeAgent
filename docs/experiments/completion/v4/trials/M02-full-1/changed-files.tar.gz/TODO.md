# MokioClaw Todo

## Plan

Source edits done; now verifying with visible tests.

## Todos

- [ ] **todo-1** `pending` generation.py: validate_generation raises model_output_truncated for output_limit before argument validation.
- [ ] **todo-2** `pending` openai_provider.py: single re-decision, second truncation safe stop, not_executed for all declared calls, empty synthetic args.
- [x] **todo-3** `completed` Run PYTHONPATH=src:. python -m pytest on relevant visible tests and report results. — Targeted: 46 passed, 4 errors (missing examples/mcp/echo_server.py). Full: 330 passed, 5 failed, 15 errors — all environment-related (missing example file, StopIteration in cancellation tests, bash shim path), none in truncation logic.

## Acceptance Criteria

- Any response with finish_reason length/max_tokens invalidates all tool calls from that response, including complete-looking ones
- Every declared call on a truncated response gets a not_executed tool result
- Only one re-decision attempt is allowed; a second truncation stops safely
- Raw partial JSON is never executed using SDK-completed argument values
- Cancellation, correction and budget checks remain intact
- Visible tests pass under PYTHONPATH=src:. python -m pytest

## Verification Commands

- `PYTHONPATH=src:. python -m pytest tests/test_project_optimization.py tests/test_reliability_extensions.py tests/test_optimization_integration.py -q`
- `PYTHONPATH=src:. python -m pytest -q`
