# MokioClaw Recovery

- status: failed
- mode: light
- updated_at: 2026-10-17T05:48:17.010061+00:00
- latest_node: codeAgent
- next_node: 
- attempts: 0 / 3
- workspace: /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/completion-20261017-m02-v3/trials/M02-full-1/workspace
- resume: `uv run mokioclaw --resume /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/completion-20261017-m02-v3/trials/M02-full-1/workspace`

## Task
模型返回 length/max_tokens 时，该响应的所有工具调用（包括看似完整的调用）都必须作废并补齐未执行结果；只允许重新决策一次，再次截断安全停止。原始半截 JSON 不得用 SDK 补全值执行。保留取消、纠正和预算检查。
允许修改范围：src/mokioclaw/**

评测环境：只修改允许的源代码，禁止修改测试、依赖和测试配置。隐藏测试在外部验收。可以新增源代码辅助文件；TODO.md/NOTEPAD.md/HISTORY_SUMMARY.md 为允许的过程记录。Bash 使用离线 Docker 和预装依赖，不要联网或装包；使用 PYTHONPATH=src:. python -m pytest 运行可见测试。不使用网页、MCP、自定义 hooks、持久授权或后台执行。最后如实说明实现与验证，最后一行用 AGENT_CLAIM: solved 或 AGENT_CLAIM: unsolved 标明自评。

## Plan
Edits applied to generation.py and openai_provider.py; now run the visible test suite and fix any regressions.

## Todos
- [completed] Read exact source in providers/generation.py and providers/openai_provider.py to confirm truncation handling gaps.
- [pending] Implement truncation voiding + collision-safe declared_calls + not_executed backfill.
- [pending] Verify single re-decision and safe stop on second truncation; preserve cancel/correction/budget checks.
- [pending] Run PYTHONPATH=src:. python -m pytest -q and fix regressions.

## Acceptance Criteria
- On finish_reason length/max_tokens, every tool call in that response is voided (no execution), including complete-looking ones, and not_executed results are backfilled for all of them.
- Only one re-decision attempt is allowed; a second truncation stops safely with model_generation_stopped.
- Partial/truncated JSON args are never executed using SDK-completed values.
- Cancellation, correction and budget checks remain intact.
- Visible test suite passes under PYTHONPATH=src:. python -m pytest.

## Verification Commands
- PYTHONPATH=src:. python -m pytest -q

## Sources
- (none)

## Recent Summaries
- research: (none)
- codeAgent: ## Report

### Files changed (both within allowed scope `src/mokioclaw/**`)

**1. `src/mokioclaw/providers/generation.py`**
- `validate_generation`: replaced the disabled `if False:` truncation check with a real one — `if result.reason == "output_limit": raise ModelGenerationStopped("model_output_truncated", message)`. This runs **before** any tool-argument JSON validation, so on `finish_reason` `length`/`max_tokens` every declared call (complete-looking or partial) is voided and no partial JSON or SDK-completed argument value can be executed.
- `declared_calls`: rewritten to be collision-safe and non-destructive:
  - Complete calls from `tool_calls` + `invalid_tool_calls` are enumerated first, keyed by `id` when present else a stable positional key `call_<position>`.
  - `tool_call_chunks` fragments are only added for keys not already present, so a chunk fragment can never overwrite a complete call.
  - Insertion order is preserved via an `order` list; non-dict items and `None` messages are skipped safely.

**2. `src/mokioclaw/providers/openai_provider.py`**
- `invoke_streaming`: docstring updated to state the contract (truncation voids all declared calls; exactly one re-decision; second truncation re-raises so lifecycle emits `model_generation_stopped` and the run stops safely).
- Made the retry backfill defensive: `_text_content(getattr(exc.message, "content", ""))` instead of `exc.message.content`, so a `None`/content-less assembled message cannot raise `AttributeError` inside the retry path.
- Existing behavior retained unchanged: `attempt < 2` single retry, synthet...
- verifier: (none)
- last_error: (none)

## Recent Files
- .codegraph/.gitignore (173 bytes)
- .codegraph/daemon.pid (144 bytes)
- .gitignore (83 bytes)
- .mokioclaw/changes/completion-20261017-m02-v3-M02-full-1/3e155c7426e14439898aca78bee40625.bin (3590 bytes)
- .mokioclaw/changes/completion-20261017-m02-v3-M02-full-1/db4faf7b491143dc9dbd8d2e6ca16a51.bin (13827 bytes)
- .mokioclaw/changes/completion-20261017-m02-v3-M02-full-1/manifest.json (918 bytes)
- .mokioclaw/diagnostics/bash-stderr-09dc583b5dd546a59a0d7d82e74f49ed.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-0cc8f743e5b54112ade6820f3b6ecfa8.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-cbf1ae367ad54ca18b7971c78f225642.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-d6e9dc09fb73413c843cf4f978828ed1.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-ec77a51f5f5e40b48a479e55562af5a6.log (0 bytes)
- .mokioclaw/diagnostics/bash-stdout-588af9a6b2f44a5788aac3238c3b9430.log (1683 bytes)
- .mokioclaw/diagnostics/bash-stdout-7c64ed77821f4e4fad7ee4dae42f5de1.log (2752 bytes)
- .mokioclaw/diagnostics/bash-stdout-91d83342767341198779dca4a9a3d92e.log (1383 bytes)
- .mokioclaw/diagnostics/bash-stdout-b9ebe7efd12647ae9754cefed80b971c.log (1867 bytes)
- .mokioclaw/diagnostics/bash-stdout-cb41374c2cb84b0fbb4d740c748c6b15.log (1654 bytes)
- .mokioclaw/diagnostics/model-stream-1145071ef2104df1948587281bf1f5c8.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-1b03cf02a5e2481da3251d083a252f42.log (45 bytes)
- .mokioclaw/diagnostics/model-stream-22bc79b2a8cd43d9a13844b25a2f5984.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-2a02f68848e04154a41e951c98675258.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-3ae4720dbe0845559476c582ec7041a6.log (88 bytes)
- .mokioclaw/diagnostics/model-stream-5d213c55104944bb8158fad85143bce7.log (46 bytes)
- .mokioclaw/diagnostics/model-stream-69d7bd024bb94c54b8e5e32a2a86cf36.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-6ccb1ab7c57947279b060c039c85110b.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-6d4d317c81124406af01e2000008d2e8.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-909969805ec24e9290003bbf3020574e.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-993ccd5796054a3eb2e0ae16d8d4caa5.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-9f17bc4127404e6aac18bdf897720cb4.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-ada81e1aa959404ab06a84def942a2f3.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-adef4c901caf42c7b3fa1aeefeeb03c0.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-af462a9242cb4ceb83a2832f1321da71.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-b4cd220fe5ca42d4b796e6e013af8cf5.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-d00ecd72440447e8848e040fd29db73e.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-d4c9a33c67ce462f9b900e35ef62798c.log (6869 bytes)
- .mokioclaw/diagnostics/model-stream-da7bc86396cf49dc9e75dbb5aa34624d.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-dc28dee5ef854c78b4711ab8dd964108.log (2984 bytes)
- .mokioclaw/diagnostics/model-stream-e9d239fa39a94b6abccf785cfd7f1c3c.log (68 bytes)
- .mokioclaw/diagnostics/model-stream-ffa2b5cafb844465a69f7ef3a09f60dc.log (0 bytes)
- .mokioclaw/inbox/local-901c3e54009643fea9f3c6ba194b25b7.json (2 bytes)
- .mokioclaw/memory/repo-171fb728e45334d035401e13.json (6076 bytes)
