# MokioClaw Todo

## Plan

Edits applied to generation.py and openai_provider.py; now run the visible test suite and fix any regressions.

## Todos

- [x] **todo-1** `completed` Read exact source in providers/generation.py and providers/openai_provider.py to confirm truncation handling gaps.
- [ ] **todo-2** `pending` Implement truncation voiding + collision-safe declared_calls + not_executed backfill.
- [ ] **todo-3** `pending` Verify single re-decision and safe stop on second truncation; preserve cancel/correction/budget checks.
- [ ] **todo-4** `pending` Run PYTHONPATH=src:. python -m pytest -q and fix regressions.

## Acceptance Criteria

- On finish_reason length/max_tokens, every tool call in that response is voided (no execution), including complete-looking ones, and not_executed results are backfilled for all of them.
- Only one re-decision attempt is allowed; a second truncation stops safely with model_generation_stopped.
- Partial/truncated JSON args are never executed using SDK-completed values.
- Cancellation, correction and budget checks remain intact.
- Visible test suite passes under PYTHONPATH=src:. python -m pytest.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
