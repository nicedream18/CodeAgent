# MokioClaw Todo

## Plan

Exploration confirmed: generation.py has dead `if False:` guard in validate_generation; openai_provider.invoke_streaming already has an unreachable one-shot retry with backfill. Now make the edits and run tests.

## Todos

- [ ] **todo-1** `pending` Read exact source of generation.py and openai_provider.py (DONE - confirmed dead guard + unreachable retry)
- [ ] **todo-2** `pending` Edit generation.py: raise ModelGenerationStopped('model_output_truncated') on output_limit before JSON validation
- [ ] **todo-3** `pending` Verify/adjust openai_provider.invoke_streaming retry: void ALL declared calls incl. complete-looking ones, backfill synthetic ToolMessages
- [ ] **todo-4** `pending` Ensure exactly one re-decision; second truncation stops safely with no execution
- [ ] **todo-5** `pending` Preserve cancellation, correction and budget checks on retry path
- [ ] **todo-6** `pending` Run PYTHONPATH=src:. python -m pytest -q and confirm pass

## Acceptance Criteria

- validate_generation raises ModelGenerationStopped('model_output_truncated') for finish_reason length/max_tokens
- All declared tool calls in a truncated response are voided and backfilled with synthetic not-executed ToolMessages
- Exactly one re-decision; second truncation stops safely
- No execution of SDK-completed half-truncated JSON args
- Cancellation/correction/budget checks preserved
- PYTHONPATH=src:. python -m pytest passes

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
