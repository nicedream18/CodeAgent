def take_batch(items, limit):
    """Remove a FIFO batch from a mutable list."""
    if limit < 0:
        raise ValueError("limit must be non-negative")
    batch = items[:limit]
    del items[:len(batch)]
    return batch
