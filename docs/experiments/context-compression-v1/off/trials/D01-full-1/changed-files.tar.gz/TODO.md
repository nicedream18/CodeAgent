# MokioClaw Todo

## Plan

Fix completed and verified: single-file change in src/batch_queue.py, visible tests pass, boundary cases checked.

## Todos

- [x] **todo-1** `completed` Rewrite take_batch in src/batch_queue.py: validate limit<0 -> ValueError before mutating; limit=0 -> return [] without consuming; otherwise remove at most limit items FIFO in place, preserving remainder order.
- [x] **todo-2** `completed` Run PYTHONPATH=src:. python -m pytest -q plus inline boundary checks (limit=0, limit<0 with non-empty and empty list, limit>len, partial batch remainder order).

## Acceptance Criteria

- take_batch returns at most limit items in FIFO order and removes them from items in place
- Remaining items keep their original relative order
- limit=0 returns [] and leaves items unchanged
- limit<0 raises ValueError and leaves items unchanged (including empty list)
- Empty queue and full-drain behavior preserved
- Visible tests pass with PYTHONPATH=src:. python -m pytest -q
- Only src/batch_queue.py modified

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
