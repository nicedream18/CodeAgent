def take_batch(items, limit):
    """Remove a FIFO batch from a mutable list."""
    if limit < 0:
        raise ValueError("limit must be non-negative")
    batch = []
    while items and len(batch) < limit:
        batch.append(items.pop(0))
    return batch
