# MokioClaw Todo

## Plan

Completed: single-file fix in src/batch_queue.py (validate limit<0 first, off-by-one corrected), verified with visible pytest and explicit boundary checks.

## Todos

- [x] **todo-1** `completed` Rewrite take_batch in src/batch_queue.py: validate limit<0 (raise ValueError before mutating, even for empty list), return [] for limit=0 without consuming, return at most limit items in FIFO order via pop(0), preserve remaining order and drain/empty behavior.
- [x] **todo-2** `completed` Run PYTHONPATH=src:. python -m pytest -q and self-check boundary cases (limit=0, limit<0 with empty/non-empty list, limit>len, empty queue). — pytest: 2 passed; boundary script printed 'boundaries ok' (exit 0). git status failed only because workspace is not a git repo.

## Acceptance Criteria

- take_batch returns at most limit items in FIFO order and removes them from items
- Remaining items keep their original relative order
- limit=0 returns [] and leaves items unchanged
- limit<0 raises ValueError and leaves items unchanged (including empty list)
- Normal drain (limit>=len) and empty-queue behavior preserved
- PYTHONPATH=src:. python -m pytest -q passes
- Only src/batch_queue.py modified

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
