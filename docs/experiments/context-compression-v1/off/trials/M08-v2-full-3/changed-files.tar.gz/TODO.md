# MokioClaw Todo

## Plan

Implementation complete; remaining work is targeted verification of the --since behavior and fixing any defect found.

## Todos

- [x] **todo-1** `completed` Add --since ISO8601 (Z/UTC offset required) filter to `mokioclaw trace` in src/mokioclaw/cli/app.py: parse before any reader/daemon work, raise typer.BadParameter on invalid/missing-tz, compare in UTC inclusive (>=), skip records with missing/invalid timestamps only when --since given, keep --follow composition.
- [-] **todo-2** `in_progress` Verify: run PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py plus ad-hoc CLI checks for --since boundary, invalid/no-tz usage error (exit 2, no run started), legacy records, and --follow combination.

## Acceptance Criteria

- `mokioclaw trace --since <ISO8601 with Z or UTC offset>` filters records by timestamp compared in UTC, inclusive of the boundary instant.
- Invalid or timezone-less --since values produce a CLI usage error (exit code 2) before any run/reader work starts.
- Records with missing or invalid timestamps are skipped when --since is given; output without --since is unchanged.
- follow composes with --since and other filters (filter applied on every poll iteration).
- Only files under src/mokioclaw are modified; tests and fixtures untouched.
- PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py passes.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
- `PYTHONPATH=src:. python -m mokioclaw.cli.app trace --help`
