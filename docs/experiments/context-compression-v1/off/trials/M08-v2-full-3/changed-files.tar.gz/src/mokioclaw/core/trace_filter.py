"""Time filtering helpers for ``mokioclaw trace``.

Kept side-effect free so the CLI can validate ``--since`` before touching the
daemon or constructing any reader.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Mapping

__all__ = ["parse_since", "parse_timestamp", "record_at_or_after"]


def _parse_iso8601(value: str) -> datetime | None:
    """Parse an ISO8601 string, returning ``None`` when it is not parseable."""
    text = value.strip()
    if not text:
        return None
    if text.endswith(("Z", "z")):
        text = text[:-1] + "+00:00"
    try:
        return datetime.fromisoformat(text)
    except (TypeError, ValueError):
        return None


def parse_since(value: str) -> datetime:
    """Parse a ``--since`` value into an aware UTC datetime.

    Raises ``ValueError`` when the value is unparseable or carries no explicit
    UTC designator / numeric offset.
    """
    parsed = _parse_iso8601(value)
    if parsed is None:
        raise ValueError(f"Invalid ISO8601 timestamp: {value!r}")
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError(
            f"Timestamp must include a UTC designator 'Z' or a numeric UTC offset: {value!r}"
        )
    return parsed.astimezone(timezone.utc)


def parse_timestamp(value: Any) -> datetime | None:
    """Parse a record timestamp into an aware UTC datetime, or ``None``."""
    if not isinstance(value, str):
        return None
    parsed = _parse_iso8601(value)
    if parsed is None or parsed.tzinfo is None or parsed.utcoffset() is None:
        return None
    return parsed.astimezone(timezone.utc)


def record_at_or_after(record: Mapping[str, Any], since: datetime) -> bool:
    """Return True when ``record`` has a valid timestamp at or after ``since``."""
    record_ts = parse_timestamp(record.get("timestamp"))
    if record_ts is None:
        return False
    return record_ts >= since
