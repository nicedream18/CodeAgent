# MokioClaw Todo

## Plan

Implementation done by codeAgent (grep_tool.py fixed_strings + rg -F; registry.py GrepTool param). Remaining: run visible pytest and ad-hoc parity checks.

## Todos

- [ ] **todo-1** `pending` Add fixed_strings=False to grep() in src/mokioclaw/tools/grep_tool.py (re.escape for Python backend, '-F' for rg).
- [ ] **todo-2** `pending` Expose fixed_strings: bool=False on GrepTool in src/mokioclaw/tools/registry.py and forward to grep().
- [-] **todo-3** `in_progress` Verify: run visible pytest plus ad-hoc checks for literal metacharacters, ignore_case, Chinese paths, ignore rules, head_limit, and rg-vs-python parity.

## Acceptance Criteria

- grep accepts fixed_strings and treats ., (, ), [, ] literally when enabled
- GrepTool schema exposes fixed_strings: bool = False and forwards it
- fixed_strings composes with ignore_case, glob, head_limit, ignore rules and Chinese paths
- rg and Python backends return identical matches content and order
- Default regex behavior unchanged; visible pytest passes

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
