# MokioClaw Todo

## Plan

Single focused implementation in the trace CLI command plus targeted verification.

## Todos

- [-] **todo-1** `in_progress` Add --since ISO8601 (timezone-required, UTC-compared, inclusive) filter to `mokioclaw trace` in src/mokioclaw/cli/app.py; invalid/naive values raise CLI usage error before any run/read; skip records with missing/invalid timestamps only when --since set; compose with --follow and other filters.
- [ ] **todo-2** `pending` Verify: run visible pytest suite plus ad-hoc CLI checks for --since boundary, naive/invalid rejection, legacy records, and --follow composition.

## Acceptance Criteria

- `mokioclaw trace --since <ISO8601 with Z or ±HH:MM>` filters records by timestamp >= since, compared in UTC, boundary inclusive
- Invalid or timezone-less --since exits with a CLI usage error (non-zero, usage message) and starts no run/read
- Records with missing or invalid timestamps are skipped when --since is given; output unchanged when --since is absent
- since composes with --follow, --run-id, --layer, --direction
- PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py passes; only src/mokioclaw/** modified

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
- `PYTHONPATH=src:. python -m mokioclaw trace --help`
- `PYTHONPATH=src:. python -m mokioclaw trace --since 2024-01-01T00:00:00`
