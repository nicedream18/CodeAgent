# MokioClaw Recovery

- status: finished
- mode: light
- updated_at: 2026-10-18T11:35:45.838347+00:00
- latest_node: final
- next_node: final
- attempts: 1 / 3
- workspace: /Users/nicedream/.cache/mokioclaw/eval/context-compression-v1/experiments/context-compression-20261018-v1-off/trials/M08-v2-full-2/workspace
- resume: `uv run mokioclaw --resume /Users/nicedream/.cache/mokioclaw/eval/context-compression-v1/experiments/context-compression-20261018-v1-off/trials/M08-v2-full-2/workspace`

## Task
为 mokioclaw trace 增加 --since ISO8601 时间过滤，要求带 Z 或 UTC 偏移、包含边界时刻并按 UTC 比较。不合法或没有时区的参数返回 CLI 用法错误，不能启动任何运行。旧记录无时间戳或时间戳无效时，在有 --since 条件下跳过；无该参数时仍保持原输出。--follow 与其他筛选可组合。

本工作区是固定工程任务切片，不是原仓库的完整测试环境。可见基础检查命令：PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py。该检查验证基础读写/搜索、CLI 帮助和本地 stdio fixture；目标边界请自行验证。隐藏目标及固定回归由外部评分器在全新离线容器重建。只修改 src/mokioclaw 下实现，保留测试和示例 fixture。
允许修改范围：src/mokioclaw/**

评测环境：只修改允许的源代码，禁止修改测试、依赖和测试配置。隐藏测试在外部验收。可以新增源代码辅助文件；TODO.md/NOTEPAD.md/HISTORY_SUMMARY.md 为允许的过程记录。Bash 使用离线 Docker 和预装依赖，不要联网或装包；使用 PYTHONPATH=src:. python -m pytest 运行可见测试。不使用网页、MCP、自定义 hooks、持久授权或后台执行。最后如实说明实现与验证，最后一行用 AGENT_CLAIM: solved 或 AGENT_CLAIM: unsolved 标明自评。

## Plan
Single focused implementation in the trace CLI command plus targeted verification.

## Todos
- [completed] Add --since ISO8601 (timezone-required, UTC-compared, inclusive) filter to `mokioclaw trace` in src/mokioclaw/cli/app.py; invalid/naive values raise CLI usage error before any run/read; skip records with missing/invalid timestamps only when --since set; compose with --follow and other filters.
- [completed] Verify: run visible pytest suite plus ad-hoc CLI checks for --since boundary, naive/invalid rejection, legacy records, and --follow composition.

## Acceptance Criteria
- `mokioclaw trace --since <ISO8601 with Z or ±HH:MM>` filters records by timestamp >= since, compared in UTC, boundary inclusive
- Invalid or timezone-less --since exits with a CLI usage error (non-zero, usage message) and starts no run/read
- Records with missing or invalid timestamps are skipped when --since is given; output unchanged when --since is absent
- since composes with --follow, --run-id, --layer, --direction
- PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py passes; only src/mokioclaw/** modified

## Verification Commands
- PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py
- PYTHONPATH=src:. python -m mokioclaw trace --help
- PYTHONPATH=src:. python -m mokioclaw trace --since 2024-01-01T00:00:00

## Sources
- (none)

## Recent Summaries
- research: (none)
- codeAgent: ## Summary

### Files changed (only under `src/mokioclaw/**`)

**`src/mokioclaw/core/transport_trace.py`** — added three reusable helpers above `TraceReader` (offsets untouched):
- `parse_since(value: str) -> datetime`: strips whitespace, normalizes trailing `Z`/`z` → `+00:00`, parses with `datetime.fromisoformat`, rejects naive values (`tzinfo is None` or `utcoffset() is None`), and returns `parsed.astimezone(UTC)`. Raises `ValueError` with a clear message for empty/invalid/naive input.
- `parse_record_timestamp(value) -> datetime | None`: defensive parse of a record's `timestamp` (accepts `datetime` objects, strings with `Z` or offsets); returns `None` for missing, empty, non-string, unparseable, or naive values.
- `record_at_or_after(record, since) -> bool`: `True` only when the record has a valid timestamp `>= since` (inclusive, UTC comparison).

**`src/mokioclaw/cli/app.py`** — `trace_command`:
- New parameter `since: str | None = None` (option `--since`), docstring updated to describe it.
- `--since` is parsed **before** `TraceReader()` is constructed and before any file read; a `ValueError` is re-raised as `typer.BadParameter(..., param_hint="--since")`, producing a Click usage error (exit 2) with no traceback and no run/read started.
- Filter applied alongside existing `run_id`/`layer`/`direction` checks inside the read loop, so it composes with `--follow` (each newly read record is filtered) and with the other filters. When `--since` is absent, `since_at` is `None` and no filtering/skipping occurs — output path unchanged.

### Verification (all run offline in th...
- verifier: `--since` is implemented in the trace CLI with timezone-required parsing, UTC-inclusive comparison, legacy/invalid-timestamp skipping only when set, and composition with other filters including --follow. Visible tests pass and ad-hoc CLI checks confirm all boundary behaviors.
- last_error: (none)

## Recent Files
- .codegraph/.gitignore (173 bytes)
- .codegraph/daemon.pid (144 bytes)
- .gitignore (83 bytes)
- .mokioclaw/changes/context-compression-20261018-v1-off-M08-v2-full-2/c05c97b5e402474d93410bd107ab94f4.bin (5753 bytes)
- .mokioclaw/changes/context-compression-20261018-v1-off-M08-v2-full-2/cbbf3c32fe9340bba65cc8441686cf99.bin (17801 bytes)
- .mokioclaw/changes/context-compression-20261018-v1-off-M08-v2-full-2/manifest.json (910 bytes)
- .mokioclaw/diagnostics/bash-stderr-0f164770fd4f4189a70448861b299fae.log (1460 bytes)
- .mokioclaw/diagnostics/bash-stderr-6c7bfb481e1943dfb2f93dbb91210446.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-6e3ce3af9f764163994e5f60fbe5aee0.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-dd274b9c6cc04ec6a6e87ce8261adbf8.log (1460 bytes)
- .mokioclaw/diagnostics/bash-stderr-f96b444fe214459ea55a98b2a1681d3f.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-fc19caff84e24d19817c763d3d086765.log (0 bytes)
- .mokioclaw/diagnostics/bash-stdout-0304b9367a754dbda75f34ca00d7b6ba.log (321 bytes)
- .mokioclaw/diagnostics/bash-stdout-21016fee6d0844bebc68e7ff1344ca7d.log (486 bytes)
- .mokioclaw/diagnostics/bash-stdout-3bcfcdc1a94648368d23d1f7bc13f2ce.log (3420 bytes)
- .mokioclaw/diagnostics/bash-stdout-5d75472ccb034a7bbeed4d67475de139.log (1019 bytes)
- .mokioclaw/diagnostics/bash-stdout-a3c60801a7cf49b5a34f2f3bfa882e8e.log (871 bytes)
- .mokioclaw/diagnostics/bash-stdout-f6314fc8c98343c9a71716f73f5226a1.log (1195 bytes)
- .mokioclaw/diagnostics/model-stream-0578099cef2f44978e12ee2d5963c28b.log (2180 bytes)
- .mokioclaw/diagnostics/model-stream-0c65971af59c4ebabc90dd2cd704ead3.log (46 bytes)
- .mokioclaw/diagnostics/model-stream-19ac0d1f6b0e4e98879310190741de92.log (54 bytes)
- .mokioclaw/diagnostics/model-stream-229cadef00bc438fb50640135832d66b.log (2894 bytes)
- .mokioclaw/diagnostics/model-stream-416a324a61c44316bd2145f5dc545261.log (75 bytes)
- .mokioclaw/diagnostics/model-stream-485a1b94a125493694e56177ce4c8559.log (67 bytes)
- .mokioclaw/diagnostics/model-stream-4d80dd2d73f14a3caab71073adee06a8.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-51d0784fac2a4ae0857d0407d8000df7.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-583fc30649804e408e7fb0f9b9f9a197.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-85f9c438ccc24bfe9321c459fa0e5e18.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-9d2803cd65984b1ea159fbe36b0f6243.log (95 bytes)
- .mokioclaw/diagnostics/model-stream-9edab08c40164c40aa3bb20e9ef8a14d.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-b51328d4c4e046b2885c7fa3b41d6d1a.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-ba30e30cfab8494db53b6a53cc575a8a.log (73 bytes)
- .mokioclaw/diagnostics/model-stream-bffccc5d65c44c12a6b2e1a7c4f980d9.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-c264c51c28214dbcae1cff22d3af9576.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-c943a0ba82b2435d80214c8af3391845.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-d35cd5d1931a40e4bf52e971690546cc.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-ebc78d39cbb24193be73b65eb2189f96.log (79 bytes)
- .mokioclaw/diagnostics/model-stream-fb7961c2a9294086b9961acd44cc93f0.log (6030 bytes)
- .mokioclaw/inbox/local-dfa75fd3d3e04820bef95c2a93db5806.json (2 bytes)
- .mokioclaw/memory/repo-1857da014afb9fb14522e7a6.json (5129 bytes)
