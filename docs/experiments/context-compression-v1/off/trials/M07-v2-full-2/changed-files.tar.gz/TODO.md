# MokioClaw Todo

## Plan

Edits are in place (grep fixed_strings param + registry exposure). Remaining: run verification only.

## Todos

- [ ] **todo-1** `pending` Add fixed_strings=False to grep() in src/mokioclaw/tools/grep_tool.py (re.escape for Python path, -F for rg path).
- [ ] **todo-2** `pending` Expose fixed_strings: bool=False in GrepTool registry lambda and forward it.
- [-] **todo-3** `in_progress` Verify: run visible pytest suite plus ad-hoc checks for literal metacharacters, ignore_case, Chinese paths, head_limit, and rg-vs-python parity.

## Acceptance Criteria

- grep accepts fixed_strings and defaults to unchanged regex behavior.
- GrepTool schema exposes fixed_strings: bool = False and forwards it.
- Literal metacharacters match literally in both backends; composes with ignore_case, Chinese paths, ignore rules, head_limit.
- rg and Python backends return identical matches content and order.
- PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py passes.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
