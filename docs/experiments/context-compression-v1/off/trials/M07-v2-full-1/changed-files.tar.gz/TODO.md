# MokioClaw Todo

## Plan

Edits applied in grep_tool.py and registry.py; remaining work is verification only (code agent had no shell access).

## Todos

- [x] **todo-1** `completed` Add fixed_strings=False to grep() in src/mokioclaw/tools/grep_tool.py: escape pattern for Python backend (re.escape, keep IGNORECASE) and pass -F to rg backend; keep default regex behavior and result ordering/head_limit unchanged. — grep_tool.py and registry.py edits applied
- [x] **todo-2** `completed` Expose fixed_strings: bool=False on GrepTool in src/mokioclaw/tools/registry.py (_grep lambda + description) and pass through to grep().
- [-] **todo-3** `in_progress` Verify: run PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py plus ad-hoc checks for literal metacharacters, ignore_case, Chinese paths, ignore rules, head_limit, and rg/python parity.

## Acceptance Criteria

- grep(state, pattern, path='.', glob=None, head_limit=50, ignore_case=False, fixed_strings=False) accepts fixed_strings and matches metacharacters literally when True
- GrepTool schema exposes fixed_strings: bool = False and forwards it
- ignore_case, Chinese paths, ignore rules and head_limit still work with fixed_strings
- rg and Python backends produce identical matches content and order
- Default regex behavior unchanged; visible tests pass

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
