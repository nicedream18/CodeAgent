# MokioClaw Todo

## Plan

Done: take_batch rewritten with pre-mutation ValueError and slice/delete; visible tests pass and all edge cases verified.

## Todos

- [x] **todo-1** `completed` Rewrite take_batch in src/batch_queue.py: validate limit<0 with ValueError before any mutation, then slice off min(limit, len(items)) items via del items[:n] and return them. — Rewrote take_batch with pre-mutation ValueError and slice/delete.
- [x] **todo-2** `completed` Run PYTHONPATH=src:. python -m pytest -q plus inline edge-case checks (limit=0, limit<0 with non-empty and empty list, partial batch, order preservation). — pytest: 2 passed; all inline edge checks passed.

## Acceptance Criteria

- take_batch returns at most limit items in FIFO order and removes them from items
- Remaining items keep their original relative order
- limit=0 returns [] and does not consume any item
- limit<0 raises ValueError and leaves items unchanged, including when items is empty
- Empty queue and full drain behavior preserved
- PYTHONPATH=src:. python -m pytest -q passes
- Only src/batch_queue.py is modified

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
