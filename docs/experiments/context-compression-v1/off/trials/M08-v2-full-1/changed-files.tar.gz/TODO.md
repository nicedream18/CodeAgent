# MokioClaw Todo

## Plan

Implementation complete and verified by the code agent; visible suite green.

## Todos

- [ ] **todo-1** `pending` Add --since ISO8601 (Z/UTC offset required) option to `mokioclaw trace` in src/mokioclaw/cli/app.py with UTC-aware >= filtering and usage errors for invalid/naive input.
- [ ] **todo-2** `pending` Run visible checks plus ad-hoc CLI verification of --since boundary/invalid/no-timezone/follow behavior.

## Acceptance Criteria

- `mokioclaw trace --since <ISO8601 with Z or UTC offset>` filters records to timestamp >= boundary compared in UTC, including the exact boundary instant.
- Invalid or timezone-less --since values produce a CLI usage error (exit code 2) and start no run/reader.
- Records with missing or invalid timestamps are skipped when --since is given; output without --since is unchanged.
- follow composes with --since and other filters.
- Visible test suite passes and only src/mokioclaw/** is modified.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
