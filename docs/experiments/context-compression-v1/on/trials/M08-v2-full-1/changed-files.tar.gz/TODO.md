# MokioClaw Todo

## Plan

Implementation done in src/mokioclaw/cli/app.py; remaining work is verification and any small fix.

## Todos

- [ ] **todo-1** `pending` Add --since option to trace_command in src/mokioclaw/cli/app.py (done by code agent: _parse_since, _parse_record_timestamp, _record_at_or_after, filter inside follow loop).
- [-] **todo-2** `in_progress` Verify: run visible tests and ad-hoc CLI checks for --since boundary, invalid/naive rejection, offset equivalence, no---since parity, --follow composition. Fix any defect found.

## Acceptance Criteria

- trace --since accepts ISO8601 with Z or UTC offset and filters records by UTC timestamp >= since (inclusive)
- Invalid or timezone-less --since yields CLI usage error (non-zero exit, usage message) and starts no run
- Records with missing/invalid timestamps are skipped when --since is set; output unchanged when --since absent
- since composes with --follow and other filters
- Visible test suite passes

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
