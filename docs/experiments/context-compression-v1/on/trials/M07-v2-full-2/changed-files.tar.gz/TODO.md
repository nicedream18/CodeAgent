# MokioClaw Todo

## Plan

Implementation done (grep_tool.py re.escape/-F, registry.py fixed_strings param). Remaining: empirical rg-vs-python parity and edge-case verification.

## Todos

- [x] **todo-1** `completed` Add fixed_strings=False to grep() in src/mokioclaw/tools/grep_tool.py: escape pattern for Python backend, add -F to rg command; keep ignore_case/glob/head_limit/ignore rules and result shape unchanged. — grep() and registry updated
- [x] **todo-2** `completed` Expose fixed_strings: bool=False on GrepTool in src/mokioclaw/tools/registry.py and forward to grep(). — GrepTool lambda + description updated
- [-] **todo-3** `in_progress` Verify: visible pytest suite plus ad-hoc checks for literal metacharacters, ignore_case, Chinese paths, ignore rules, head_limit, and rg-vs-python parity.

## Acceptance Criteria

- grep() signature is grep(state, pattern, path='.', glob=None, head_limit=50, ignore_case=False, fixed_strings=False)
- GrepTool schema exposes fixed_strings: bool = False and forwards it
- With fixed_strings=True, '.', '(', ')', '[', ']' etc. match literally and invalid regexes do not raise
- fixed_strings composes with ignore_case, glob, head_limit, ignore rules and Chinese paths
- rg and Python backends return identical matches content and order
- Default (fixed_strings=False) regex behavior unchanged; visible tests pass

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
