def take_batch(items, limit):
    """Remove and return up to `limit` items from the front of `items` in FIFO order."""
    if limit < 0:
        raise ValueError("limit must be non-negative")
    count = min(limit, len(items))
    batch = items[:count]
    del items[:count]
    return batch
