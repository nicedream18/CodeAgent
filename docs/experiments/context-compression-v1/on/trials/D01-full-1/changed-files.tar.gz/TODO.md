# MokioClaw Todo

## Plan

Fix implemented in src/batch_queue.py (validate limit, then slice-and-delete at most limit items). Visible tests pass (2 passed) and boundary self-checks pass.

## Todos

- [x] **todo-1** `completed` Fix take_batch in src/batch_queue.py: validate limit<0 -> ValueError before touching items; limit=0 -> return [] without consuming; remove at most limit items FIFO via slice+del; preserve remaining order. — Implemented validate-then-slice-and-delete.
- [x] **todo-2** `completed` Run PYTHONPATH=src:. python -m pytest -q and self-check boundaries (limit=0, limit<0 with empty and non-empty list, partial batch, full drain, empty queue). — pytest: 2 passed; boundary self-checks OK.

## Acceptance Criteria

- take_batch removes at most limit items in FIFO order and returns them
- Remaining items keep their original order
- limit=0 returns [] and does not consume
- limit<0 raises ValueError and leaves items unchanged (including empty list)
- Full drain and empty queue behavior preserved
- Visible tests pass with PYTHONPATH=src:. python -m pytest -q
- Only src/batch_queue.py modified

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
