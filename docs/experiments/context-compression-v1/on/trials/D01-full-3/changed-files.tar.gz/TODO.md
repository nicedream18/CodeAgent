# MokioClaw Todo

## Plan

Completed: src/batch_queue.py take_batch rewritten with up-front negative-limit validation and bounded FIFO slice removal; visible tests and boundary self-checks pass.

## Todos

- [x] **todo-1** `completed` Fix take_batch in src/batch_queue.py: validate limit<0 with ValueError before any mutation, return [] without consuming when limit==0, and remove at most limit items FIFO (fix off-by-one <= loop).
- [x] **todo-2** `completed` Run PYTHONPATH=src:. python -m pytest -q and self-check boundaries (limit=0, limit<0 with non-empty and empty list, partial batch order, full drain, empty queue).

## Acceptance Criteria

- take_batch(items, limit) removes and returns at most `limit` items in FIFO order
- Remaining items keep their original relative order
- limit=0 returns [] and leaves items unchanged
- limit<0 raises ValueError and leaves items unchanged (including empty list)
- Full drain and empty-queue behavior preserved
- PYTHONPATH=src:. python -m pytest -q passes
- Only src/batch_queue.py modified

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
