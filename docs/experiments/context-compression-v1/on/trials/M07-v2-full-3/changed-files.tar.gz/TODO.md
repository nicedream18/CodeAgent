# MokioClaw Todo

## Plan

Implementation of fixed_strings is in place (grep_tool.py + registry.py). Remaining work is verification only.

## Todos

- [ ] **todo-1** `pending` Add fixed_strings=False to grep() in src/mokioclaw/tools/grep_tool.py (re.escape on Python backend, -F on rg backend).
- [ ] **todo-2** `pending` Expose fixed_strings: bool=False on GrepTool in src/mokioclaw/tools/registry.py and pass through to grep().
- [ ] **todo-3** `pending` Verify: run visible tests and an ad-hoc literal/ignore_case/head_limit/ignore-rule/rg-vs-python parity check; fix only if a check fails.

## Acceptance Criteria

- grep() accepts fixed_strings=False and GrepTool schema exposes fixed_strings: bool = False
- With fixed_strings=True, '.', '(', ')', '[', ']' match literally in both rg and Python backends
- ignore_case, Chinese paths, ignore rules, and head_limit still work with fixed_strings
- rg and Python backends return identical matches content and order
- Default (fixed_strings=False) regex behavior unchanged; visible tests pass

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
