# MokioClaw Todo

## Plan

Single-file fix in src/batch_queue.py: validate limit<0 with ValueError before any mutation, then take items[:limit] and del items[:limit] to preserve FIFO order and remaining order. Verify with visible pytest plus explicit boundary self-checks.

## Todos

- [x] **todo-1** `completed` Fix take_batch in src/batch_queue.py: raise ValueError for limit<0 before mutation, use slice take + del for FIFO with at most limit items, no-op for limit=0.
- [x] **todo-2** `completed` Run PYTHONPATH=src:. python -m pytest -q and boundary self-checks (limit=0, limit<0 with non-empty and empty list, partial drain, full drain, empty queue).

## Acceptance Criteria

- take_batch returns at most `limit` items in FIFO order and removes exactly those from items
- Remaining items keep their original relative order
- limit=0 returns [] and leaves items unchanged
- limit<0 raises ValueError and leaves items unchanged (including empty list)
- Full drain and empty-queue behavior preserved
- PYTHONPATH=src:. python -m pytest -q passes
- Only src/batch_queue.py modified

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
- `PYTHONPATH=src:. python -c "from batch_queue import take_batch; a=[1,2,3,4]; assert take_batch(a,2)==[1,2] and a==[3,4]; b=[1,2,3]; assert take_batch(b,0)==[] and b==[1,2,3]; assert take_batch([],0)==[]; c=[1,2];`
- `try:`
- `take_batch(c,-1); raise SystemExit('no ValueError')`
- `except ValueError: pass`
- `assert c==[1,2]`
- `d=[]`
- `try:`
- `take_batch(d,-1); raise SystemExit('no ValueError')`
- `except ValueError: pass`
- `assert d==[]`
- `e=[1,2,3]; assert take_batch(e,10)==[1,2,3] and e==[]; assert take_batch([],5)==[]; print('boundary checks OK')"`
