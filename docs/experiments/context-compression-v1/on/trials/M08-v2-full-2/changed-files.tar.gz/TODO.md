# MokioClaw Todo

## Plan

Implementation done; remaining work is targeted behavioral verification of --since.

## Todos

- [x] **todo-1** `completed` Add --since ISO8601 (Z/UTC offset required) option to trace command in src/mokioclaw/cli/app.py; validate before any run/read, raise typer.BadParameter on invalid/naive input; filter records inclusively by UTC, skipping missing/invalid timestamps only when --since given; keep --follow composition.
- [-] **todo-2** `in_progress` Run targeted behavioral checks for --since (boundary inclusive, UTC offset comparison, naive/invalid arg usage error exit 2, legacy/invalid record timestamps skipped only with --since, no --since unchanged, --follow combo) using a script file written via file tool (no shell redirects).

## Acceptance Criteria

- trace --since accepts ISO8601 with Z or UTC offset and compares in UTC, inclusive of boundary
- Invalid or timezone-less --since yields CLI usage error (exit code 2) and starts no run/read
- With --since, records with missing/invalid timestamps are skipped; without --since output unchanged
- follow composes with --since and other filters
- PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py passes

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
