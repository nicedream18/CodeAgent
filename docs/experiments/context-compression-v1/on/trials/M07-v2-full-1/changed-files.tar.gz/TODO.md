# MokioClaw Todo

## Plan

Implementation done (grep fixed_strings + GrepTool schema). Remaining: run visible tests and ad-hoc literal/parity checks.

## Todos

- [x] **todo-1** `completed` Add fixed_strings=False to grep() in src/mokioclaw/tools/grep_tool.py: literal Python matcher (re.escape) when enabled, '-F' flag for rg backend, keep regex default unchanged.
- [x] **todo-2** `completed` Expose fixed_strings: bool=False on GrepTool lambda in src/mokioclaw/tools/registry.py and forward to grep().
- [-] **todo-3** `in_progress` Verify: run visible pytest plus ad-hoc checks for literal metacharacters, ignore_case, Chinese paths, ignore rules, head_limit, and rg/Python parity.

## Acceptance Criteria

- grep(state, pattern, path='.', glob=None, head_limit=50, ignore_case=False, fixed_strings=False) accepts fixed_strings
- GrepTool tool schema exposes fixed_strings: bool = False
- With fixed_strings=True, '.', '(', '[', etc. match literally in both rg and Python backends
- fixed_strings composes with ignore_case, Chinese paths, ignore rules, and head_limit
- rg and Python backends return identical matches content and order
- Default regex behavior unchanged; visible tests pass

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
