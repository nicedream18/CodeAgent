# MokioClaw Todo

## Plan

Implementation complete and verified: --since added to trace command with tz-required ISO8601 parsing, UTC-inclusive filtering, and composition with --follow.

## Todos

- [x] **todo-1** `completed` Add --since ISO8601 (tz-required, UTC compare, inclusive boundary) filter to `mokioclaw trace` in src/mokioclaw/cli/app.py, with helper for parsing/validation; invalid or naive -> typer.BadParameter before any run/read; skip missing/invalid record timestamps only when --since set; compose with --follow and other filters.
- [x] **todo-2** `completed` Run visible tests (PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py) plus ad-hoc CLI checks for --since boundary/invalid/naive/follow behavior.

## Acceptance Criteria

- `mokioclaw trace --since <ISO8601 with Z or ±HH:MM>` filters records by UTC timestamp, inclusive of the boundary instant
- Invalid or timezone-naive --since yields a CLI usage error (exit code 2 / BadParameter) and starts no run or trace read
- Records with missing or unparsable timestamps are skipped when --since is given; output unchanged when --since is absent
- since composes with --follow and existing filters (run_id, layer, direction, raw)
- Visible test suite passes and only src/mokioclaw/** is modified

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
- `PYTHONPATH=src:. python -m mokioclaw trace --help`
- `PYTHONPATH=src:. python -m mokioclaw trace --since 2024-01-01T00:00:00 (expect usage error, exit 2)`
- `PYTHONPATH=src:. python -m mokioclaw trace --since not-a-date (expect usage error, exit 2)`
