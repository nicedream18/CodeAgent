import sys
from pathlib import Path

from typer.testing import CliRunner

from mokioclaw.cli.app import app
from mokioclaw.core.state import RuntimeState
from mokioclaw.tools.execution import execute_tool
from mokioclaw.tools.mcp_tools import build_mcp_tools
from mokioclaw.tools.registry import build_tools


def test_basic_file_read_and_search(tmp_path):
    (tmp_path / "example.txt").write_text("hello world\n", encoding="utf-8")
    runtime = RuntimeState(workspace=tmp_path, approval_mode="auto")
    tools = {t.name: t for t in build_tools(runtime)}
    assert tools["FileReadTool"].invoke({"file_path": "example.txt"})["ok"]
    assert tools["GrepTool"].invoke({"pattern": "hello"})["matches"]


def test_cli_help_needs_no_model():
    result = CliRunner().invoke(app, ["--help"])
    assert result.exit_code == 0


def test_stdio_fixture_is_present_and_callable(tmp_path):
    project = Path(__file__).resolve().parents[1]
    runtime = RuntimeState(workspace=tmp_path, approval_mode="auto")
    runtime.mcp_servers = [{"name": "example", "command": sys.executable,
        "args": [str(project / "examples/mcp/echo_server.py")], "cwd": str(project)}]
    echo = next(t for t in build_mcp_tools(runtime) if t.name == "MCP_example_echo")
    result = execute_tool(runtime, echo, {"text": "hello"})
    assert result["ok"] and result["content"] == ["echo: hello"]
