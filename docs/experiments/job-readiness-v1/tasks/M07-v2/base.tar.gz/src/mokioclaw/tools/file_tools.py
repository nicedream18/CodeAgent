from __future__ import annotations

import difflib
from pathlib import Path
from typing import Any

from mokioclaw.core.instructions import touch_instructions
from mokioclaw.core.state import RuntimeState

MAX_READ_LINES = 2000
TEXT_ENCODINGS = ("utf-8", "utf-8-sig", "gbk")


def _strip_workspace_prefix(file_path: str) -> str:
    normalized = file_path.replace("\\", "/").strip()
    while normalized in {"workspace", "./workspace"} or normalized.startswith(
        ("workspace/", "./workspace/")
    ):
        if normalized in {"workspace", "./workspace"}:
            normalized = "."
        elif normalized.startswith("./workspace/"):
            normalized = normalized[len("./workspace/") :]
        else:
            normalized = normalized[len("workspace/") :]
    return normalized


def read_text_lossy(path: Path) -> str:
    last_error: UnicodeDecodeError | None = None
    for encoding in TEXT_ENCODINGS:
        try:
            return path.read_text(encoding=encoding)
        except UnicodeDecodeError as exc:
            last_error = exc
    if last_error is not None:
        return path.read_text(encoding="utf-8", errors="replace")
    return path.read_text(encoding="utf-8")


def resolve_workspace_path(state: RuntimeState, file_path: str) -> Path:
    raw = Path(_strip_workspace_prefix(file_path)).expanduser()
    if not raw.is_absolute():
        raw = state.workspace / raw
    return state.assert_workspace_path(raw)


def display_path(state: RuntimeState, path: Path) -> str:
    try:
        return str(path.resolve().relative_to(state.workspace.resolve()))
    except ValueError:
        return str(path)


def read_file(
    state: RuntimeState,
    file_path: str,
    offset: int | str = 0,
    limit: int | str = MAX_READ_LINES,
    char_offset: int | None = None,
    char_limit: int = 8000,
) -> dict[str, Any]:
    try:
        path = resolve_workspace_path(state, file_path)
    except ValueError as exc:
        return {"ok": False, "error": str(exc)}
    touch_instructions(state, path)
    if not path.exists():
        return {
            "ok": False,
            "error": f"file does not exist: {display_path(state, path)}",
        }
    if not path.is_file():
        return {
            "ok": False,
            "error": f"path is not a file: {display_path(state, path)}",
        }
    try:
        offset_value = int(offset)
        limit_value = int(limit)
    except (TypeError, ValueError):
        return {"ok": False, "error": "offset and limit must be integers"}
    if offset_value < 0:
        return {"ok": False, "error": "offset must be >= 0"}
    if limit_value <= 0:
        return {"ok": False, "error": "limit must be > 0"}

    text = read_text_lossy(path)
    if char_offset is not None:
        if (
            not isinstance(char_offset, int)
            or char_offset < 0
            or not isinstance(char_limit, int)
            or char_limit < 1
        ):
            return {
                "ok": False,
                "error": "char_offset must be nonnegative and char_limit must be positive",
            }
        char_limit = min(char_limit, state.context_output_limit_chars)
        selected_text = text[char_offset : char_offset + char_limit]
        complete = char_offset == 0 and len(selected_text) == len(text)
        state.record_read(path, complete=complete)
        return {
            "ok": True,
            "path": display_path(state, path),
            "content": selected_text,
            "char_offset": char_offset,
            "total_characters": len(text),
            "complete": complete,
            "model_visible_complete": complete,
            "next_char_offset": char_offset + len(selected_text),
        }
    lines = text.splitlines()
    limit_value = min(limit_value, MAX_READ_LINES)
    selected = lines[offset_value : offset_value + limit_value]
    complete = offset_value == 0 and len(selected) == len(lines)
    state.record_read(path, complete=complete)

    numbered = "\n".join(f"{offset_value + idx + 1}: {line}" for idx, line in enumerate(selected))
    return {
        "ok": True,
        "path": display_path(state, path),
        "total_lines": len(lines),
        "offset": offset_value,
        "limit": limit_value,
        "complete": complete,
        "model_visible_complete": complete,
        "content": numbered,
    }


def write_file(state: RuntimeState, file_path: str, content: str) -> dict[str, Any]:
    try:
        path = resolve_workspace_path(state, file_path)
    except ValueError as exc:
        return {"ok": False, "error": str(exc)}
    changed = touch_instructions(state, path, writing=True)
    if changed:
        return changed
    existed = path.exists()

    if existed:
        snapshot = state.snapshot_for(path)
        if snapshot is None:
            return {
                "ok": False,
                "error": "file has not been read yet. Read it before overwriting.",
            }
        if path.stat().st_mtime_ns != snapshot.mtime_ns:
            return {
                "ok": False,
                "error": "file changed after it was read. Read it again before writing.",
            }
        original = read_text_lossy(path)
        if original == content:
            return {
                "ok": True,
                "type": "unchanged",
                "already_applied": True,
                "path": display_path(state, path),
                "lines": len(content.splitlines()),
                "diff": "",
            }
    else:
        original = ""

    from mokioclaw.core.changes import journal_write

    try:
        change_id = journal_write(state, path, content)
    except (OSError, ValueError) as exc:
        from mokioclaw.core.changes import JournalCommitError

        return {
            "ok": False,
            "error": str(exc),
            "error_type": "outcome_unknown"
            if isinstance(exc, JournalCommitError)
            else "tool_error",
            "retryable": False,
        }
    state.record_read(path, complete=True)

    diff = "\n".join(
        difflib.unified_diff(
            original.splitlines(),
            content.splitlines(),
            fromfile=f"a/{display_path(state, path)}",
            tofile=f"b/{display_path(state, path)}",
            lineterm="",
        )
    )
    return {
        "ok": True,
        "type": "update" if existed else "create",
        "change_id": change_id,
        "path": display_path(state, path),
        "lines": len(content.splitlines()),
        "diff": diff[:4000],
    }


def edit_file(state: RuntimeState, file_path: str, old_text: str, new_text: str) -> dict[str, Any]:
    try:
        path = resolve_workspace_path(state, file_path)
    except ValueError as exc:
        return {"ok": False, "error": str(exc)}
    changed = touch_instructions(state, path, writing=True)
    if changed:
        return changed
    if not path.exists():
        return {
            "ok": False,
            "error": f"file does not exist: {display_path(state, path)}",
        }

    snapshot = state.snapshot_for(path)
    if snapshot is None:
        return {
            "ok": False,
            "error": "file has not been read yet. Read it before editing.",
        }
    if path.stat().st_mtime_ns != snapshot.mtime_ns:
        return {
            "ok": False,
            "error": "file changed after it was read. Read it again before editing.",
        }
    if not old_text:
        return {"ok": False, "error": "old_text must not be empty"}

    original = read_text_lossy(path)
    count = original.count(old_text)
    if count == 0:
        return {"ok": False, "error": "old_text was not found"}
    if count > 1:
        return {
            "ok": False,
            "error": f"old_text matched {count} times. Provide a unique snippet.",
        }

    updated = original.replace(old_text, new_text, 1)
    from mokioclaw.core.changes import journal_write

    try:
        change_id = journal_write(state, path, updated)
    except (OSError, ValueError) as exc:
        from mokioclaw.core.changes import JournalCommitError

        return {
            "ok": False,
            "error": str(exc),
            "error_type": "outcome_unknown"
            if isinstance(exc, JournalCommitError)
            else "tool_error",
            "retryable": False,
        }
    state.record_read(path, complete=True)

    diff = "\n".join(
        difflib.unified_diff(
            original.splitlines(),
            updated.splitlines(),
            fromfile=f"a/{display_path(state, path)}",
            tofile=f"b/{display_path(state, path)}",
            lineterm="",
        )
    )
    return {
        "ok": True,
        "path": display_path(state, path),
        "replacements": 1,
        "change_id": change_id,
        "diff": diff[:4000],
    }
