"""Model provider helpers."""
