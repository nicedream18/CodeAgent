from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any

from langchain_core.messages import HumanMessage, SystemMessage, ToolMessage

from mokioclaw.core.run_control import RunInterrupted, check_run
from mokioclaw.core.tool_loop import ToolConversation
from mokioclaw.core.tool_output import bound_tool_result
from mokioclaw.graph.state import MokioGraphState
from mokioclaw.prompts.stage3 import SEARCH_AGENT_PROMPT
from mokioclaw.providers.model_policy import create_role_model
from mokioclaw.providers.openai_provider import create_model, invoke_streaming
from mokioclaw.tools.execution import (
    execute_tool,
    reserve_subagent_tool_call,
    tool_failure_result,
)
from mokioclaw.tools.registry import build_tool

Writer = Callable[[dict[str, Any]], None]


def run_search_agent(
    state: MokioGraphState,
    instruction: str,
    *,
    writer: Writer | None = None,
    max_loops: int = 4,
) -> dict[str, Any]:
    writer = writer or (lambda _: None)
    model = create_role_model(create_model, state["runtime"], "searchAgent")
    runtime = state["runtime"]
    search_tools = (
        [build_tool(runtime, "WebSearchTool")]
        if runtime.active_agent_tools is None or "WebSearchTool" in runtime.active_agent_tools
        else []
    )
    search_agent = model.bind_tools(search_tools)
    messages = [
        SystemMessage(content=SEARCH_AGENT_PROMPT),
        HumanMessage(
            content=(
                f"Task: {state['task']}\n\n"
                f"Planner instruction:\n{instruction}\n\n"
                f"Existing research notes:\n{state.get('research_notes', '')}\n\n"
                f"Existing sources:\n{json.dumps(state.get('sources', []), ensure_ascii=False)}\n\n"
                "Search as needed and finish with a concise research summary plus source URLs."
            )
        ),
    ]

    produced_messages: list[Any] = []
    queries: list[str] = []
    sources: list[dict[str, Any]] = []
    answers: list[str] = []
    tool_events: list[dict[str, Any]] = []

    budget_exhausted = False
    rounds = max_loops + (1 if state["runtime"].active_subagent_budget else 0)
    conversation = ToolConversation(
        messages,
        state=state,
        writer=writer,
        node="searchAgent",
        invoke=invoke_streaming,
        produced=produced_messages,
    )
    for response, tool_calls in conversation.rounds(rounds, lambda: search_agent):
        if not getattr(response, "tool_calls", None):
            break
        with conversation.batch(tool_calls) as pending_calls:
            for call in pending_calls:
                args = call.get("args") or {}
                query = str(args.get("query", ""))
                if query:
                    queries.append(query)
                writer(
                    {
                        "type": "tool_call",
                        "node": "searchAgent",
                        "name": call.get("name"),
                        "args": args,
                    }
                )
                tool_result = _execute_search_tool(call, state=state, on_retry=writer)
                event = _tool_result_event(tool_result)
                tool_events.append(event)
                writer(event)
                parsed = _parse_tool_content(tool_result.content)
                if isinstance(parsed, dict):
                    if parsed.get("answer"):
                        answers.append(str(parsed["answer"]))
                    for item in parsed.get("results", []) or []:
                        if isinstance(item, dict):
                            sources.append(item)
                    state["sources"] = _dedupe_sources(list(state.get("sources") or []) + sources)
                    if answers:
                        state["research_notes"] = "\n".join(answers)
                    writer(
                        {
                            "type": "search_results",
                            "query": parsed.get("query", query),
                            "answer": parsed.get("answer", ""),
                            "sources": parsed.get("results", []),
                        }
                    )
                conversation.append(tool_result)
                budget = state["runtime"].active_subagent_budget
                if budget is not None and budget.exhausted:
                    budget_exhausted = True
                    break
        if budget_exhausted:
            break

    summary = _last_ai_content(produced_messages) or "\n".join(answers)
    result = {
        "ok": not budget_exhausted,
        "summary": summary,
        "queries": queries,
        "sources": _dedupe_sources(sources),
        "messages": messages[2:],
        "tool_events": tool_events,
        "stop_reason": "tool_budget_exhausted" if budget_exhausted else None,
        "unresolved": (
            ["Subagent tool-call budget exhausted; research may be incomplete."]
            if budget_exhausted
            else []
        ),
    }
    writer(
        {
            "type": "search_summary",
            "summary": result["summary"],
            "queries": result["queries"],
            "sources": result["sources"],
        }
    )
    return result


def _execute_search_tool(
    call: dict[str, Any], *, state: MokioGraphState | None = None, on_retry=None
) -> ToolMessage:
    name = call.get("name", "")
    args = call.get("args") or {}
    runtime = state.get("runtime") if state else None
    check_run(runtime)
    tool = build_tool(runtime, name) if runtime is not None else None
    if name != "WebSearchTool" or tool is None:
        budget_failure = (
            reserve_subagent_tool_call(
                runtime,
                name,
                str(call.get("id") or f"{name}-call"),
                on_event=on_retry,
            )
            if runtime is not None
            else None
        )
        result = budget_failure or tool_failure_result(f"unknown tool: {name}", tool_name=name)
    else:
        try:
            result = execute_tool(
                runtime,
                tool,
                args,
                on_retry=on_retry,
                on_event=on_retry,
                tool_call_id=call.get("id"),
            )
        except RunInterrupted:
            raise
        except Exception as exc:  # noqa: BLE001 — fault boundary; control signals are handled separately
            result = tool_failure_result(exc, tool_name=name)
    return ToolMessage(
        content=json.dumps(
            bound_tool_result(result, runtime, tool_name=name, writer=on_retry)
            if runtime is not None
            else result,
            ensure_ascii=False,
        ),
        name=name,
        tool_call_id=call.get("id") or f"{name}-call",
    )


def _tool_result_event(tool_message: ToolMessage) -> dict[str, Any]:
    parsed = _parse_tool_content(tool_message.content)
    return {
        "type": "tool_result",
        "node": "searchAgent",
        "name": tool_message.name,
        "tool_call_id": tool_message.tool_call_id,
        "result": parsed,
    }


def _parse_tool_content(content: Any) -> Any:
    try:
        return json.loads(str(content))
    except json.JSONDecodeError:
        return content


def _dedupe_sources(sources: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[str] = set()
    deduped = []
    for source in sources:
        url = str(source.get("url", ""))
        if not url or url in seen:
            continue
        seen.add(url)
        deduped.append(source)
    return deduped


def _last_ai_content(messages: list[Any]) -> str:
    for message in reversed(messages):
        if isinstance(message, ToolMessage):
            continue
        content = getattr(message, "content", "")
        if content:
            return str(content)
    return ""
