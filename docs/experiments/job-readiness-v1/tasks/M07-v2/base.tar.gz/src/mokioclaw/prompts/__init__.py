"""Prompt loading helpers."""
