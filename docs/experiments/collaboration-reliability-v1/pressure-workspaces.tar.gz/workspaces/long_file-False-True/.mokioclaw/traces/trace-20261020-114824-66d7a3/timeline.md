# MokioClaw Trace Timeline

- trace_id: trace-20261020-114824-66d7a3
- status: failed
- duration_ms: 98
- workspace: /private/tmp/mokio-collaboration-0g8ut04r/accepted-experiments/pressure/workspaces/long_file-False-True
- events: 47

## Summary

- nodes: {}
- tool_calls: 4
- failed_tool_calls: 0
- approvals: 0
- checkpoints: 0
- final_status: 

## Timeline

- 0ms run_start
- 4ms permission_granted
- 7ms tool_output_truncated
- 8ms instructions_loaded
- 8ms context_budget
- 8ms llm_stream_start codeAgent
- 8ms llm_request codeAgent
- 8ms llm_stream_end codeAgent
- 8ms llm_response codeAgent
- 9ms model_usage
- 9ms tool_call codeAgent FileReadTool
- 10ms permission_granted
- 12ms tool_output_truncated
- 12ms tool_result codeAgent FileReadTool
- 13ms context_budget
- 13ms llm_stream_start codeAgent
- 13ms llm_request codeAgent
- 15ms llm_stream_end codeAgent
- 15ms llm_response codeAgent
- 15ms model_usage
- 15ms tool_call codeAgent FileReadTool
- 17ms permission_granted
- 19ms tool_output_truncated
- 19ms tool_result codeAgent FileReadTool
- 20ms context_budget
- 20ms llm_stream_start codeAgent
- 20ms llm_request codeAgent
- 20ms llm_stream_end codeAgent
- 20ms llm_response codeAgent
- 20ms model_usage
- 20ms tool_call codeAgent FileReadTool
- 22ms permission_granted
- 25ms tool_output_truncated
- 25ms tool_result codeAgent FileReadTool
- 25ms context_budget
- 26ms llm_stream_start codeAgent
- 26ms llm_request codeAgent
- 26ms llm_stream_end codeAgent
- 26ms llm_response codeAgent
- 26ms model_usage
- 26ms tool_call codeAgent FileReadTool
- 27ms permission_granted
- 29ms tool_output_truncated
- 30ms tool_result codeAgent FileReadTool
- 30ms context_compact_request
- 30ms context_budget_exceeded
- 98ms run_end
