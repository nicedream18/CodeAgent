# MokioClaw Trace Timeline

- trace_id: trace-20261020-114824-48a6b6
- status: failed
- duration_ms: 94
- workspace: /private/tmp/mokio-collaboration-0g8ut04r/accepted-experiments/pressure/workspaces/long_file-False-False
- events: 46

## Summary

- nodes: {}
- tool_calls: 4
- failed_tool_calls: 0
- approvals: 0
- checkpoints: 0
- final_status: 

## Timeline

- 0ms run_start
- 4ms permission_granted
- 7ms tool_output_truncated
- 8ms instructions_loaded
- 8ms context_budget
- 8ms llm_stream_start codeAgent
- 8ms llm_request codeAgent
- 8ms llm_stream_end codeAgent
- 8ms llm_response codeAgent
- 8ms model_usage
- 9ms tool_call codeAgent FileReadTool
- 10ms permission_granted
- 12ms tool_output_truncated
- 12ms tool_result codeAgent FileReadTool
- 12ms context_budget
- 12ms llm_stream_start codeAgent
- 13ms llm_request codeAgent
- 13ms llm_stream_end codeAgent
- 13ms llm_response codeAgent
- 13ms model_usage
- 13ms tool_call codeAgent FileReadTool
- 14ms permission_granted
- 16ms tool_output_truncated
- 16ms tool_result codeAgent FileReadTool
- 17ms context_budget
- 17ms llm_stream_start codeAgent
- 18ms llm_request codeAgent
- 18ms llm_stream_end codeAgent
- 18ms llm_response codeAgent
- 18ms model_usage
- 18ms tool_call codeAgent FileReadTool
- 19ms permission_granted
- 21ms tool_output_truncated
- 21ms tool_result codeAgent FileReadTool
- 22ms context_budget
- 22ms llm_stream_start codeAgent
- 22ms llm_request codeAgent
- 23ms llm_stream_end codeAgent
- 23ms llm_response codeAgent
- 23ms model_usage
- 23ms tool_call codeAgent FileReadTool
- 24ms permission_granted
- 26ms tool_output_truncated
- 26ms tool_result codeAgent FileReadTool
- 27ms context_budget_exceeded
- 94ms run_end
