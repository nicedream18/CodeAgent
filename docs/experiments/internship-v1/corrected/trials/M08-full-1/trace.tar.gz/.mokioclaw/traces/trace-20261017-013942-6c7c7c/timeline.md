# MokioClaw Trace Timeline

- trace_id: trace-20261017-013942-6c7c7c
- status: failed
- duration_ms: 427
- workspace: /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261017/trials/M08-full-1/workspace
- events: 13

## Summary

- nodes: {}
- tool_calls: 0
- failed_tool_calls: 0
- approvals: 0
- checkpoints: 2
- final_status: 

## Timeline

- 0ms run_start
- 152ms checkpoint_saved
- 152ms run_started
- 308ms instructions_loaded
- 354ms context_budget
- 354ms llm_stream_start intent_router
- 354ms llm_request intent_router
- 370ms llm_stream_end intent_router
- 370ms llm_response intent_router
- 371ms model_usage
- 371ms model_generation_stopped
- 426ms checkpoint_saved
- 427ms run_end
