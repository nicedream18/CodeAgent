# MokioClaw Todo

## Plan

Add optional literal (fixed-string) search to grep() and GrepTool, preserving default regex behavior and backend parity.

## Todos

- [ ] **todo-1** `pending` Explore src/mokioclaw grep implementation: grep() signature, backend selection (rg vs Python), match ordering, ignore rules, truncation, and GrepTool schema/wrapper.
- [ ] **todo-2** `pending` Implement fixed_strings support in grep() and expose fixed_strings: bool=False on GrepTool, keeping default regex behavior unchanged.
- [ ] **todo-3** `pending` Verify: run visible tests with PYTHONPATH=src:. python -m pytest; confirm rg/Python backend parity, ignore_case, Chinese paths, ignore rules, head_limit.

## Acceptance Criteria

- grep() accepts fixed_strings=False and treats pattern literally (dots, parens, brackets) when True.
- GrepTool exposes fixed_strings: bool=False and forwards it to grep().
- fixed_strings composes with ignore_case, Chinese paths, ignore rules, and head_limit.
- rg and Python backends produce identical matches content and order.
- Default (fixed_strings=False) regex behavior is unchanged.
- Only files under src/mokioclaw/** are modified; visible tests pass.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
