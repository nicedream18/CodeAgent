# MokioClaw Todo

## Plan

Explore the existing instruction/tool-loop code narrowly, then implement rule-change detection with decision invalidation and verify with visible tests.

## Todos

- [ ] **todo-1** `pending` Explore repo: locate instruction/rule loading, tool loop, file tools, and any decision/approval caching; read relevant tests.
- [ ] **todo-2** `pending` Design invalidation mechanism: detect first-encounter subdir AGENTS.md / rule change, refresh context, invalidate pending modification decisions.
- [ ] **todo-3** `pending` Implement in src/mokioclaw/** (FileWrite/FileEdit + batched tool loop must not reuse stale decisions; reads not permanently blocked).
- [ ] **todo-4** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and verify behavior.

## Acceptance Criteria

- First encounter of a subdirectory AGENTS.md (or a rule change) triggers a context refresh and invalidates not-yet-executed modification decisions.
- Direct FileWrite/FileEdit calls and subsequent modifications within a batched tool call do not reuse stale decisions after invalidation.
- A new model request may read the rules and continue; read operations are not permanently blocked.
- Only files under src/mokioclaw/** are modified; tests/deps/config untouched.
- Visible tests pass via PYTHONPATH=src:. python -m pytest.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
