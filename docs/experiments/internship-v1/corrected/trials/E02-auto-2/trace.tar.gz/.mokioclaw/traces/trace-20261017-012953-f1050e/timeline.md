# MokioClaw Trace Timeline

- trace_id: trace-20261017-012953-f1050e
- status: failed
- duration_ms: 1137
- workspace: /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261017/trials/E02-auto-2/workspace
- events: 13

## Summary

- nodes: {}
- tool_calls: 0
- failed_tool_calls: 0
- approvals: 0
- checkpoints: 2
- final_status: 

## Timeline

- 0ms run_start
- 287ms checkpoint_saved
- 287ms run_started
- 629ms instructions_loaded
- 765ms context_budget
- 766ms llm_stream_start intent_router
- 766ms llm_request intent_router
- 816ms llm_stream_end intent_router
- 817ms llm_response intent_router
- 821ms model_usage
- 823ms model_generation_stopped
- 1136ms checkpoint_saved
- 1136ms run_end
