# MokioClaw Todo

## Plan

Add optional literal (fixed-string) search to grep and expose it on GrepTool, keeping default regex behavior and cross-backend consistency intact.

## Todos

- [ ] **todo-1** `pending` Explore src/mokioclaw/tools/grep_tool.py and registry.py to confirm grep signature, backend selection (rg vs Python re), result dict construction, and GrepTool schema style.
- [ ] **todo-2** `pending` Implement fixed_strings support in grep_tool.py: literal escaping for Python backend, -F flag for rg backend, preserving ignore_case, ignore rules, head_limit, and identical match content/order across backends.
- [ ] **todo-3** `pending` Expose fixed_strings: bool=False on GrepTool in registry.py.
- [ ] **todo-4** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and confirm default regex behavior unchanged.

## Acceptance Criteria

- grep() accepts fixed_strings=False keyword and defaults to regex behavior unchanged.
- When fixed_strings=True, metacharacters (., (), [], etc.) match literally in both rg and Python backends.
- ignore_case, Chinese paths, ignore rules, and head_limit continue to work in literal mode.
- rg and Python backends produce identical matches content and ordering.
- GrepTool exposes fixed_strings: bool=False in its parameter schema.
- Visible tests pass via PYTHONPATH=src:. python -m pytest.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
- `PYTHONPATH=src:. python -c "from mokioclaw.tools.grep_tool import grep; print(grep(None, 'a.b', fixed_strings=True))"`
