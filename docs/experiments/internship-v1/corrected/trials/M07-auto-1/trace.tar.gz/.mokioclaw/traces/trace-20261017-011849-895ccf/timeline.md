# MokioClaw Trace Timeline

- trace_id: trace-20261017-011849-895ccf
- status: failed
- duration_ms: 5577
- workspace: /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261017/trials/M07-auto-1/workspace
- events: 44

## Summary

- nodes: {'intent_router': 1}
- tool_calls: 0
- failed_tool_calls: 0
- approvals: 0
- checkpoints: 3
- final_status: 

## Timeline

- 0ms run_start
- 143ms checkpoint_saved
- 144ms run_started
- 339ms instructions_loaded
- 390ms context_budget
- 390ms llm_stream_start intent_router
- 390ms llm_request intent_router
- 1669ms llm_stream_end intent_router
- 1669ms llm_response intent_router
- 1672ms model_usage
- 1672ms intent_decision
- 1674ms graph_update nodes=intent_router
- 1750ms checkpoint_saved
- 1758ms workflow_selected
- 1765ms context_budget
- 1766ms llm_stream_start repoAgent
- 1766ms llm_request repoAgent
- 2577ms llm_stream_end repoAgent
- 2578ms llm_response repoAgent
- 2579ms model_usage
- 2584ms permission_granted
- 2613ms tool_output_truncated
- 2613ms tool_result repoAgent FileGlobTool
- 2614ms permission_granted
- 2627ms tool_result repoAgent FileGlobTool
- 2628ms context_budget
- 2628ms llm_stream_start repoAgent
- 2629ms llm_request repoAgent
- 3474ms llm_stream_end repoAgent
- 3474ms llm_response repoAgent
- 3475ms model_usage
- 3477ms permission_granted
- 3481ms tool_result repoAgent FileReadTool
- 3482ms permission_granted
- 3498ms tool_result repoAgent FileGlobTool
- 3498ms context_budget
- 3499ms llm_stream_start repoAgent
- 3499ms llm_request repoAgent
- 5494ms llm_stream_end repoAgent
- 5495ms llm_response repoAgent
- 5496ms model_usage
- 5497ms model_generation_stopped
- 5576ms checkpoint_saved
- 5577ms run_end
