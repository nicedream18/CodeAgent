# MokioClaw Todo

## Plan

Explore the specific core/tools modules that hold instruction loading and modification-decision state, then implement a versioned instruction signal that invalidates pending modification decisions on first subdir AGENTS.md encounter or rule change, while keeping reads allowed.

## Todos

- [ ] **todo-1** `pending` Explore repo: instructions.py, tool_loop.py, approval*, file_tools.py, context_control/compaction, and tests to find where modification decisions are cached and where AGENTS.md rules are loaded.
- [ ] **todo-2** `pending` Design invalidation mechanism: instruction version/hash signal on first subdir AGENTS.md encounter or rule change; invalidate pending (not-yet-executed) modification decisions.
- [ ] **todo-3** `pending` Implement in src/mokioclaw/** only: refresh context, invalidate stale decisions for direct FileWrite/FileEdit and batched subsequent modifications; allow new model request to read rules and continue; reads not permanently blocked.
- [ ] **todo-4** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and verify no regressions.

## Acceptance Criteria

- First encounter of a subdirectory AGENTS.md (or a rule change) triggers a context refresh and invalidates not-yet-executed modification decisions.
- Direct FileWrite/FileEdit calls and subsequent modifications within the same tool batch do not reuse stale decisions after invalidation.
- A new model request may read the rules and continue; read operations are not permanently blocked.
- Only files under src/mokioclaw/** are modified; tests/deps/config untouched.
- Visible tests pass via PYTHONPATH=src:. python -m pytest.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
