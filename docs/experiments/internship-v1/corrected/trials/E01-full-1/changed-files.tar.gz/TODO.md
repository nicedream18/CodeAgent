# MokioClaw Todo

## Plan

Add a fail-fast validation in Blueprint.__init__ rejecting dots in the blueprint name, mirroring the existing endpoint-dot guard, then run the visible test suite.

## Todos

- [x] **todo-1** `completed` Confirm exact location of Blueprint.__init__ name handling and existing endpoint-dot guard in src/flask/blueprints.py — Blueprint.__init__ at line 171; self.name = name at line 191; name_prefix built at line 350; endpoint-dot assert at line 364.
- [x] **todo-2** `completed` Add error when blueprint name contains a dot in src/flask/blueprints.py — Added ValueError guard for dots in blueprint name right after super().__init__ and before self.name assignment.
- [-] **todo-3** `in_progress` Run visible tests with PYTHONPATH=src:. python -m pytest and confirm no regressions

## Acceptance Criteria

- Blueprint('a.b', __name__) raises ValueError with a clear message about dots in blueprint names
- Existing behavior for valid names (including nested blueprints via name_prefix) is unchanged
- Visible test suite passes with PYTHONPATH=src:. python -m pytest
- Only files under src/flask/** are modified

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
- `PYTHONPATH=src:. python -c "from flask import Blueprint; Blueprint('a.b', __name__)"`
