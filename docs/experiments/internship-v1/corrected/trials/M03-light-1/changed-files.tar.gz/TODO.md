# MokioClaw Todo

## Todos

- [-] **todo-1** `in_progress` 首次接触子目录 AGENTS.md 或规则变化时，刷新上下文并使尚未执行的旧修改决策失效。直接 FileWrite/FileEdit 和一批工具中的后续修改均不得沿用旧决策。新模型请求读取规则后允许继续；读操作不应被永久阻止。
允许修改范围：src/mokioclaw/**

评测环境：只修改允许的源代码，禁止修改测试、依赖和测试配置。隐藏测试在外部验收。可以新增源代码辅助文件；TODO.md/NOTEPAD.md/HISTORY_SUMMARY.md 为允许的过程记录。Bash 使用离线 Docker 和预装依赖，不要联网或装包；使用 PYTHONPATH=src:. python -m pytest 运行可见测试。不使用网页、MCP、自定义 hooks、持久授权或后台执行。最后如实说明实现与验证，最后一行用 AGENT_CLAIM: solved 或 AGENT_CLAIM: unsolved 标明自评。

## Acceptance Criteria

- 首次接触子目录 AGENTS.md 或规则变化时，刷新上下文并使尚未执行的旧修改决策失效。直接 FileWrite/FileEdit 和一批工具中的后续修改均不得沿用旧决策。新模型请求读取规则后允许继续；读操作不应被永久阻止。
允许修改范围：src/mokioclaw/**

评测环境：只修改允许的源代码，禁止修改测试、依赖和测试配置。隐藏测试在外部验收。可以新增源代码辅助文件；TODO.md/NOTEPAD.md/HISTORY_SUMMARY.md 为允许的过程记录。Bash 使用离线 Docker 和预装依赖，不要联网或装包；使用 PYTHONPATH=src:. python -m pytest 运行可见测试。不使用网页、MCP、自定义 hooks、持久授权或后台执行。最后如实说明实现与验证，最后一行用 AGENT_CLAIM: solved 或 AGENT_CLAIM: unsolved 标明自评。
