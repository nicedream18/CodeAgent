# MokioClaw Todo

## Plan

Add a `mode` parameter to flask.Config.from_file() so callers can open config files in binary mode (e.g. tomllib.load). Edit only src/flask/config.py, then run visible tests and a TOML smoke check.

## Todos

- [ ] **todo-1** `pending` Confirm exact current signature/body of Config.from_file in src/flask/config.py
- [ ] **todo-2** `pending` Add `mode: str = "t"` parameter to Config.from_file, open file as f"r{mode}", update docstring
- [ ] **todo-3** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest tests/test_config.py
- [ ] **todo-4** `pending` Verify binary-mode TOML loading works end-to-end (tomllib.load with mode='b')

## Acceptance Criteria

- Config.from_file accepts a `mode` parameter defaulting to "t"
- mode="b" opens the file in binary mode so tomllib.load works
- Default behavior unchanged: text mode, json.load still works
- Missing-file error message unchanged
- Visible tests pass with PYTHONPATH=src:. python -m pytest

## Verification Commands

- `PYTHONPATH=src:. python -m pytest tests/test_config.py -q`
- `PYTHONPATH=src:. python -c "import tomllib, tempfile, os; from flask import Flask; d=tempfile.mkdtemp(); open(os.path.join(d,'c.toml'),'wb').write(b'[a]\nb=1\n'); app=Flask(__name__); app.config.root_path=d; app.config.from_file('c.toml', tomllib.load, mode='b'); print(app.config['a'])"`
