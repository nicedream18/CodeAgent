# MokioClaw Todo

## Plan

Fix coupling between background Subagents and foreground cancellation: give explicit background tasks an independent RunControl, keep sync subagents on foreground control, and ensure private resources close properly.

## Todos

- [ ] **todo-1** `pending` Explore repo: locate RunControl, subagent task spawning, background vs sync distinction, Ctrl+C handling, resource lifecycle.
- [ ] **todo-2** `pending` Implement fix: explicit background subagent tasks get independent RunControl; sync subagents keep foreground control; private resources closed properly.
- [ ] **todo-3** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and verify no regressions.

## Acceptance Criteria

- Explicit background subagent tasks use an independent RunControl so parent Ctrl+C does not cancel them.
- Synchronous subagents still follow foreground RunControl cancellation.
- Private resources (locks/sessions/streams) opened for background tasks are closed on completion/cancellation.
- Only src/mokioclaw/** modified; tests/deps/config untouched.
- Visible tests pass via PYTHONPATH=src:. python -m pytest.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
