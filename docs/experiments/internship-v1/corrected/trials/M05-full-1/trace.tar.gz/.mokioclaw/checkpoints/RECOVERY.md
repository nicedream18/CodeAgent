# MokioClaw Recovery

- status: failed
- mode: light
- updated_at: 2026-10-16T17:42:54.664099+00:00
- latest_node: repoAgent
- next_node: 
- attempts: 0 / 3
- workspace: /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261017/trials/M05-full-1/workspace
- resume: `uv run mokioclaw --resume /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261017/trials/M05-full-1/workspace`

## Task
修复后台 Subagent 与前台取消信号耦合的问题。显式后台任务必须有独立 RunControl，父运行 Ctrl+C 不取消后台任务；同步 Subagent 仍遵循前台控制。私有资源必须正确关闭。
允许修改范围：src/mokioclaw/**

评测环境：只修改允许的源代码，禁止修改测试、依赖和测试配置。隐藏测试在外部验收。可以新增源代码辅助文件；TODO.md/NOTEPAD.md/HISTORY_SUMMARY.md 为允许的过程记录。Bash 使用离线 Docker 和预装依赖，不要联网或装包；使用 PYTHONPATH=src:. python -m pytest 运行可见测试。不使用网页、MCP、自定义 hooks、持久授权或后台执行。最后如实说明实现与验证，最后一行用 AGENT_CLAIM: solved 或 AGENT_CLAIM: unsolved 标明自评。

## Plan
Fix coupling between background Subagents and foreground cancellation: give explicit background tasks an independent RunControl, keep sync subagents on foreground control, and ensure private resources close properly.

## Todos
- [pending] Explore repo: locate RunControl, subagent task spawning, background vs sync distinction, Ctrl+C handling, resource lifecycle.
- [pending] Implement fix: explicit background subagent tasks get independent RunControl; sync subagents keep foreground control; private resources closed properly.
- [pending] Run visible tests with PYTHONPATH=src:. python -m pytest and verify no regressions.

## Acceptance Criteria
- Explicit background subagent tasks use an independent RunControl so parent Ctrl+C does not cancel them.
- Synchronous subagents still follow foreground RunControl cancellation.
- Private resources (locks/sessions/streams) opened for background tasks are closed on completion/cancellation.
- Only src/mokioclaw/** modified; tests/deps/config untouched.
- Visible tests pass via PYTHONPATH=src:. python -m pytest.

## Verification Commands
- PYTHONPATH=src:. python -m pytest -q

## Sources
- (none)

## Recent Summaries
- research: (none)
- codeAgent: (none)
- verifier: (none)
- last_error: (none)

## Recent Files
- .codegraph/.gitignore (173 bytes)
- .codegraph/daemon.pid (144 bytes)
- .gitignore (83 bytes)
- .mokioclaw/context/planner/current.json (50 bytes)
- .mokioclaw/context/planner/facts-149392af08da4d5e9e20420ed37c859a.json (2325 bytes)
- .mokioclaw/context/planner/facts-36e9d252ecf34681b42905b95f0cf06d.json (2325 bytes)
- .mokioclaw/context/planner/facts-7ca0de5f81b74326aecf49aaf4b9d817.json (2325 bytes)
- .mokioclaw/context/planner/facts-d3905137d17c47aba8d786e98f9123c1.json (1571 bytes)
- .mokioclaw/context/planner/version-11.json (3441 bytes)
- .mokioclaw/context/planner/version-4.json (2682 bytes)
- .mokioclaw/context/planner/version-7.json (3444 bytes)
- .mokioclaw/context/planner/version-8.json (3440 bytes)
- .mokioclaw/context/repoAgent-/current.json (48 bytes)
- .mokioclaw/context/repoAgent-/facts-7a26d8b964454891b2233a7dda50584c.json (994 bytes)
- .mokioclaw/context/repoAgent-/facts-891b94006ece4d2ea41151c2a3720954.json (994 bytes)
- .mokioclaw/context/repoAgent-/version-1.json (2108 bytes)
- .mokioclaw/context/repoAgent-/version-2.json (2112 bytes)
- .mokioclaw/context/repoAgent-49ecb403-194/current.json (50 bytes)
- .mokioclaw/context/repoAgent-49ecb403-194/facts-3dd96d1f5b6249848e4d810dea903847.json (994 bytes)
- .mokioclaw/context/repoAgent-49ecb403-194/facts-745336a3df8942e7be069ea84269670b.json (994 bytes)
- .mokioclaw/context/repoAgent-49ecb403-194/version-10.json (2125 bytes)
- .mokioclaw/context/repoAgent-49ecb403-194/version-9.json (2120 bytes)
- .mokioclaw/context/repoAgent-5412816c-d33/current.json (48 bytes)
- .mokioclaw/context/repoAgent-5412816c-d33/facts-b83a8dc8aa164795a447236b25348acd.json (994 bytes)
- .mokioclaw/context/repoAgent-5412816c-d33/version-3.json (2128 bytes)
- .mokioclaw/context/repoAgent-61941b4b-fa3/current.json (48 bytes)
- .mokioclaw/context/repoAgent-61941b4b-fa3/facts-8475710eb5a34033ab7dd538e26cc995.json (994 bytes)
- .mokioclaw/context/repoAgent-61941b4b-fa3/facts-f869acb0a6b848eea1b3a16d35460440.json (994 bytes)
- .mokioclaw/context/repoAgent-61941b4b-fa3/version-5.json (2120 bytes)
- .mokioclaw/context/repoAgent-61941b4b-fa3/version-6.json (2124 bytes)
- .mokioclaw/diagnostics/model-stream-0cd84c198a374ce4a7da4cfc003375f6.log (1278 bytes)
- .mokioclaw/diagnostics/model-stream-174949ecc2fd455cbdbe3c943b251f75.log (73 bytes)
- .mokioclaw/diagnostics/model-stream-36ab807586e34697b25e94a254fa744e.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-38cfd1cb7ec34491a79c39ec163dc2b0.log (98 bytes)
- .mokioclaw/diagnostics/model-stream-3ec325022235405486b44dafaba56cf5.log (76 bytes)
- .mokioclaw/diagnostics/model-stream-3ee15a89757b49779465eed0b1ee39eb.log (2363 bytes)
- .mokioclaw/diagnostics/model-stream-42e9eb418b174ebfa9266dd87c302e61.log (4834 bytes)
- .mokioclaw/diagnostics/model-stream-43e703896d234a27a869f7a355300c21.log (1338 bytes)
- .mokioclaw/diagnostics/model-stream-51481debe2b44c54b3588b197f0de5c9.log (1244 bytes)
- .mokioclaw/diagnostics/model-stream-5671f95e4dfb4c098e5f4b7257e76c98.log (5024 bytes)
