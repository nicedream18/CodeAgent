# MokioClaw Todo

## Plan

Add a `mode` parameter to flask.Config.from_file so binary loaders (tomllib.load) can be used, keeping text mode as the default.

## Todos

- [ ] **todo-1** `pending` Read exact current Config.from_file signature/body and related tests
- [ ] **todo-2** `pending` Add mode parameter to Config.from_file in src/flask/config.py
- [ ] **todo-3** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest

## Acceptance Criteria

- Config.from_file accepts a mode parameter (default 't') and opens the file with that mode
- mode='b' allows binary loaders such as tomllib.load to work
- Existing behavior (text mode default) is unchanged
- Visible tests pass with PYTHONPATH=src:. python -m pytest

## Verification Commands

- `PYTHONPATH=src:. python -m pytest tests/test_config.py -q`
