# MokioClaw Todo

## Plan

Add optional literal (fixed-string) search to grep and expose it on GrepTool. Recon the exact backend implementations first, then implement in grep_tool.py and registry.py, then verify with visible tests and a parity check.

## Todos

- [ ] **todo-1** `pending` Recon: read grep_tool.py fully, registry.py _grep wrapper + GrepTool registration, and locate visible grep tests.
- [ ] **todo-2** `pending` Implement fixed_strings in grep_tool.py (rg -F flag + Python re.escape/substring path) preserving ignore_case, glob/ignore rules, head_limit, ordering.
- [ ] **todo-3** `pending` Expose fixed_strings: bool=False on GrepTool/_grep StructuredTool in registry.py and forward it.
- [ ] **todo-4** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and verify rg/Python parity + default regex behavior unchanged.

## Acceptance Criteria

- grep() signature includes fixed_strings: bool=False and GrepTool exposes fixed_strings: bool=False.
- With fixed_strings=True, metacharacters (. ( ) [ ] etc.) match literally in both rg and Python backends.
- fixed_strings=True composes with ignore_case, Chinese paths, ignore rules, and head_limit/truncated.
- rg and Python backends return identical matches content and order for the same inputs.
- Default fixed_strings=False preserves existing regex behavior byte-for-byte.
- Visible tests pass via PYTHONPATH=src:. python -m pytest; no test/dependency/config files modified.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
- `PYTHONPATH=src:. python -c "from mokioclaw.tools.grep_tool import grep; import inspect; print(inspect.signature(grep))"`
