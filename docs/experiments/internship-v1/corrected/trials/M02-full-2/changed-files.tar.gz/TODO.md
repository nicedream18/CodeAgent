# MokioClaw Todo

## Plan

Handle truncated (length/max_tokens) model responses: invalidate ALL tool calls in that response, synthesize not-executed results for each, allow exactly one re-decision, safe-stop on second truncation, never execute raw half-JSON via SDK-completed values, preserve cancellation/correction/budget checks. Scope: src/mokioclaw/**.

## Todos

- [ ] **todo-1** `pending` Read exact bodies of providers/generation.py and providers/openai_provider.py (retry wrapper, tool-call enumeration, cancellation/correction/budget hooks).
- [ ] **todo-2** `pending` Inspect visible tests covering truncation/retry (test_reliability_extensions.py etc.) to learn expected contract.
- [ ] **todo-3** `pending` Implement: invalidate all tool calls on truncation, synthesize not-executed results, single re-decision, safe stop on second truncation, no SDK-completed execution.
- [ ] **todo-4** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and fix regressions.

## Acceptance Criteria

- On finish_reason length/max_tokens, every tool call in that response (including seemingly complete ones) is invalidated and receives a not-executed result.
- Exactly one re-decision is allowed; a second truncation triggers a safe stop (no further retry).
- Raw half-JSON tool arguments are never executed using SDK-completed/parsed values.
- Cancellation, correction, and budget checks remain enforced in the truncation path.
- Visible tests pass under PYTHONPATH=src:. python -m pytest.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
