# MokioClaw Todo

## Plan

Explore the truncation/tool-call handling path with a narrow-scope repo agent, then implement the invalidation + single-retry + safe-stop behavior in src/mokioclaw/**, preserving cancellation/correction/budget checks, and verify with visible tests.

## Todos

- [ ] **todo-1** `pending` Explore truncation handling: generation.py, openai_provider.py, tool_loop.py, protocol models, run_control/context_budget/tool_policy
- [ ] **todo-2** `pending` Implement: on length/max_tokens, invalidate ALL tool calls in that response, append not-executed results for each, allow exactly one re-decision, safe stop on second truncation, never execute raw partial JSON via SDK completion
- [ ] **todo-3** `pending` Preserve cancellation, correction, and budget checks around the retry path
- [ ] **todo-4** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and verify

## Acceptance Criteria

- When finish_reason is length/max_tokens, every tool call in that response (including seemingly complete ones) is invalidated and gets a not-executed tool result
- Exactly one re-decision (retry) is allowed; a second truncation results in a safe stop
- Raw partial/truncated JSON is never passed to the SDK for completion or execution
- Cancellation, correction, and budget checks remain intact around the retry path
- Visible tests pass with PYTHONPATH=src:. python -m pytest

## Verification Commands

- `PYTHONPATH=src:. python -m pytest`
