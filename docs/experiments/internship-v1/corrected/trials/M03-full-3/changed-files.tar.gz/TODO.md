# MokioClaw Todo

## Plan

Explore the mokioclaw core to locate AGENTS.md rule loading and modification-decision/approval state, then implement rule-change detection that refreshes context and invalidates stale pending modification decisions, while keeping reads allowed.

## Todos

- [ ] **todo-1** `pending` Explore repo: read instructions.py, context_control.py, tool_loop.py, file_tools.py, registry.py, approval*.py to find where AGENTS.md rules are loaded and where modification decisions are queued.
- [ ] **todo-2** `pending` Implement: detect first encounter of subdirectory AGENTS.md / rule change -> refresh context and invalidate pending unexecuted modification decisions (direct FileWrite/FileEdit and batch follow-ups).
- [ ] **todo-3** `pending` Ensure a new model request may read rules and continue; reads are not permanently blocked.
- [ ] **todo-4** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and verify no regressions.

## Acceptance Criteria

- First encounter of a subdirectory AGENTS.md (or a rule change) triggers a context refresh.
- Pending/unexecuted modification decisions (direct FileWrite/FileEdit and subsequent modifications within a batch of tools) are invalidated and not reused after the refresh.
- A new model request that reads the rules is allowed to continue; read operations are not permanently blocked.
- Only src/mokioclaw/** modified; tests/deps/config untouched.
- Visible tests pass with PYTHONPATH=src:. python -m pytest.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
