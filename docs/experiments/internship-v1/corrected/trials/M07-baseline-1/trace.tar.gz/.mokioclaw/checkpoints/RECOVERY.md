# MokioClaw Recovery

- status: failed
- mode: light
- updated_at: 2026-10-16T17:10:11.577082+00:00
- latest_node: context_compressor
- next_node: 
- attempts: 0 / 3
- workspace: /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261017/trials/M07-baseline-1/workspace
- resume: `uv run mokioclaw --resume /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261017/trials/M07-baseline-1/workspace`

## Task
为 grep(state, pattern, path='.', glob=None, head_limit=50, ignore_case=False, fixed_strings=False) 增加可选字面量搜索，GrepTool 暴露 fixed_strings: bool=False。开启时点、括号、方括号等按字面量匹配，兼容 ignore_case、中文路径、忽略规则、结果上限。rg 与 Python 后端的 matches 内容和顺序保持一致，旧正则默认行为不变。
允许修改范围：src/mokioclaw/**

评测环境：只修改允许的源代码，禁止修改测试、依赖和测试配置。隐藏测试在外部验收。可以新增源代码辅助文件；TODO.md/NOTEPAD.md/HISTORY_SUMMARY.md 为允许的过程记录。Bash 使用离线 Docker 和预装依赖，不要联网或装包；使用 PYTHONPATH=src:. python -m pytest 运行可见测试。不使用网页、MCP、自定义 hooks、持久授权或后台执行。最后如实说明实现与验证，最后一行用 AGENT_CLAIM: solved 或 AGENT_CLAIM: unsolved 标明自评。

## Plan
(none)

## Todos
- (none)

## Acceptance Criteria
- (none)

## Verification Commands
- (none)

## Sources
- (none)

## Recent Summaries
- research: (none)
- codeAgent: (none)
- verifier: (none)
- last_error: (none)

## Recent Files
- .codegraph/.gitignore (173 bytes)
- .codegraph/daemon.pid (144 bytes)
- .gitignore (83 bytes)
- .mokioclaw/context/codeAgent/current.json (50 bytes)
- .mokioclaw/context/codeAgent/facts-03d6313dc38647f38c467686fb9764e4.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-133f855b2a84478d8647ff3dd0101dcf.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-269786a9cee34f8f97dd8c4dc7216d10.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-3f4e0f6382f0496ab1b8bde373e71fa4.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-3f78ac0d8db24f00948b3bd7ada1aca1.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-463488a7f9eb4787bf35bd7d64299a45.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-4c8e629a48a6420980446432d2b7e581.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-67bdfd8584ff4da79598b03362cd8809.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-74b55cf2424049aa8dfa41e72585be4d.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-7510d46ace364520a24a59169c951c14.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-78d48604354e40a5b8a0e279289a35db.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-99413b47be0845bf9898a9fc35797d82.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-caded464ff98412b8246437f7c5e35b0.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-d61d0c7d157140e98d7bbcf9a9a07ae4.json (1175 bytes)
- .mokioclaw/context/codeAgent/version-1.json (2288 bytes)
- .mokioclaw/context/codeAgent/version-10.json (2291 bytes)
- .mokioclaw/context/codeAgent/version-11.json (2291 bytes)
- .mokioclaw/context/codeAgent/version-12.json (2291 bytes)
- .mokioclaw/context/codeAgent/version-13.json (2291 bytes)
- .mokioclaw/context/codeAgent/version-14.json (2291 bytes)
- .mokioclaw/context/codeAgent/version-2.json (2290 bytes)
- .mokioclaw/context/codeAgent/version-3.json (2288 bytes)
- .mokioclaw/context/codeAgent/version-4.json (2288 bytes)
- .mokioclaw/context/codeAgent/version-5.json (2290 bytes)
- .mokioclaw/context/codeAgent/version-6.json (2288 bytes)
- .mokioclaw/context/codeAgent/version-7.json (2290 bytes)
- .mokioclaw/context/codeAgent/version-8.json (2292 bytes)
- .mokioclaw/context/codeAgent/version-9.json (2290 bytes)
- .mokioclaw/diagnostics/bash-stderr-5ca57c6cc9164aa8bc2ee34a6944cd17.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-8bbdea4adf2d4311a9a053d63db13757.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-9bdf24ff2cc64e44aa35ce08091f51a8.log (0 bytes)
- .mokioclaw/diagnostics/bash-stdout-21757dde568e423a8d2bb227cd929baf.log (1189 bytes)
- .mokioclaw/diagnostics/bash-stdout-44f6c0f3da00457ea13de90da286ed32.log (2726 bytes)
- .mokioclaw/diagnostics/bash-stdout-fdaefd247372408aa6b119c5cd91e89d.log (291 bytes)
- .mokioclaw/diagnostics/model-stream-18f9ba8909a24857bec8acce74544b07.log (1058 bytes)
- .mokioclaw/diagnostics/model-stream-2eaa91657b0e4787808f626ccfad72b4.log (0 bytes)
