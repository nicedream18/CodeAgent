# MokioClaw Todo

## Plan

Fix requests so streaming decode_unicode=True yields str for JSON responses lacking a charset, matching r.text. Confirm code paths, implement minimal change in requests/**, then run visible tests and a local reproduction.

## Todos

- [ ] **todo-1** `pending` Confirm exact code paths: Response.iter_content, Response.text, stream_decode_response_unicode, get_encoding_from_headers, and existing tests covering decode_unicode.
- [ ] **todo-2** `pending` Implement fix in requests/** so iter_content(decode_unicode=True) yields str for application/json (align with r.text).
- [ ] **todo-3** `pending` Run visible tests via PYTHONPATH=src:. python -m pytest and verify behavior with a local reproduction.

## Acceptance Criteria

- iter_content(chunk_size, decode_unicode=True) yields str (unicode) for an application/json response without charset, matching r.text behavior.
- Existing visible tests still pass under PYTHONPATH=src:. python -m pytest.
- Only files under requests/** are modified (plus allowed process notes).

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
- `PYTHONPATH=src:. python -c "import requests, io; from requests.models import Response; r=Response(); r.status_code=200; r.headers['Content-Type']='application/json'; r.raw=io.BytesIO('{\"a\":1}'.encode()); r._content=False; print(type(next(r.iter_content(16*1024, decode_unicode=True))))"`
