# MokioClaw Todo

## Plan

Extend grep with an optional literal (fixed-strings) mode: add fixed_strings=False to grep() in src/mokioclaw/tools/grep_tool.py, map it to rg's -F flag and to literal matching in the Python fallback, and expose fixed_strings: bool=False on the GrepTool StructuredTool in src/mokioclaw/tools/registry.py. Keep default regex behavior, ignore_case, ignore rules, Chinese paths, head_limit, and rg/Python parity intact.

## Todos

- [ ] **todo-1** `pending` Confirm grep_tool.py backend structure (rg argv + Python fallback) and registry.py GrepTool lambda/schema.
- [ ] **todo-2** `pending` Add fixed_strings=False to grep() and thread through rg (-F) and Python fallback (literal matching), preserving ignore_case, ignore rules, Chinese paths, head_limit, and identical match content/order.
- [ ] **todo-3** `pending` Expose fixed_strings: bool=False on GrepTool in registry.py (lambda signature + forward).
- [ ] **todo-4** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and sanity-check literal vs regex behavior on both backends.

## Acceptance Criteria

- grep() signature includes fixed_strings=False and GrepTool exposes fixed_strings: bool=False.
- With fixed_strings=True, characters like '.', '(', ')', '[', ']' match literally in both rg and Python backends.
- fixed_strings composes with ignore_case, Chinese paths, ignore rules, and head_limit truncation.
- rg and Python backends return identical matches content and order for the same inputs.
- Default (fixed_strings=False) regex behavior is unchanged.
- Only files under src/mokioclaw/** are modified; tests/deps/config untouched.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
- `PYTHONPATH=src:. python -c "from mokioclaw.tools.grep_tool import grep; import inspect; print(inspect.signature(grep))"`
