# MokioClaw Todo

## Plan

Explore the existing instruction/policy/tool-loop implementation, then implement rule-change detection that refreshes context and invalidates stale modification decisions across direct FileWrite/FileEdit and batched tool calls, while keeping reads unblocked.

## Todos

- [ ] **todo-1** `pending` Explore existing implementation: instructions.py, tool_policy.py, tool_loop.py, file_tools.py, registry.py, approval*.py, context_*.py, run_control.py, tool_context.py
- [ ] **todo-2** `pending` Design mechanism: detect first-encounter subdirectory AGENTS.md / rule change -> refresh context + invalidate pending modification decisions
- [ ] **todo-3** `pending` Implement in src/mokioclaw/** (FileWrite/FileEdit + batched tool calls must not reuse stale decisions; reads not permanently blocked)
- [ ] **todo-4** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and verify no regressions
- [ ] **todo-5** `pending` Verify acceptance criteria against hidden-test expectations

## Acceptance Criteria

- When a subdirectory AGENTS.md is first encountered or rules change, context is refreshed and previously-made-but-not-yet-executed modification decisions are invalidated.
- Direct FileWrite/FileEdit calls do not reuse stale decisions after a rule change.
- Subsequent modifications within a batch of tool calls do not reuse stale decisions.
- A new model request that reads the rules is allowed to continue; read operations are not permanently blocked.
- All changes confined to src/mokioclaw/**; tests/deps/config untouched.
- Visible tests pass via PYTHONPATH=src:. python -m pytest.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
