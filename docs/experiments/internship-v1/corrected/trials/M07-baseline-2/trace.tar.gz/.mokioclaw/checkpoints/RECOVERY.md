# MokioClaw Recovery

- status: failed
- mode: light
- updated_at: 2026-10-16T17:09:10.451050+00:00
- latest_node: codeAgent
- next_node: 
- attempts: 0 / 3
- workspace: /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261017/trials/M07-baseline-2/workspace
- resume: `uv run mokioclaw --resume /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261017/trials/M07-baseline-2/workspace`

## Task
为 grep(state, pattern, path='.', glob=None, head_limit=50, ignore_case=False, fixed_strings=False) 增加可选字面量搜索，GrepTool 暴露 fixed_strings: bool=False。开启时点、括号、方括号等按字面量匹配，兼容 ignore_case、中文路径、忽略规则、结果上限。rg 与 Python 后端的 matches 内容和顺序保持一致，旧正则默认行为不变。
允许修改范围：src/mokioclaw/**

评测环境：只修改允许的源代码，禁止修改测试、依赖和测试配置。隐藏测试在外部验收。可以新增源代码辅助文件；TODO.md/NOTEPAD.md/HISTORY_SUMMARY.md 为允许的过程记录。Bash 使用离线 Docker 和预装依赖，不要联网或装包；使用 PYTHONPATH=src:. python -m pytest 运行可见测试。不使用网页、MCP、自定义 hooks、持久授权或后台执行。最后如实说明实现与验证，最后一行用 AGENT_CLAIM: solved 或 AGENT_CLAIM: unsolved 标明自评。

## Plan
(none)

## Todos
- (none)

## Acceptance Criteria
- (none)

## Verification Commands
- (none)

## Sources
- (none)

## Recent Summaries
- research: (none)
- codeAgent: (none)
- verifier: (none)
- last_error: (none)

## Recent Files
- .codegraph/.gitignore (173 bytes)
- .codegraph/daemon.pid (144 bytes)
- .gitignore (83 bytes)
- .mokioclaw/context/codeAgent/current.json (50 bytes)
- .mokioclaw/context/codeAgent/facts-017907c4d50047139ab7348ec936d09c.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-2ae4dfd67551452cb43c5ea1e368d942.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-3dd580b279cb4fb293f3cfb21af2670a.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-416cdce75cc8444eb88dcb712b2be0bd.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-61e19527aac34b4aa9ed7ee68d4a6a68.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-653e52e0ae4946478a334f304b3e8773.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-672a26afa45c46169fa340616e0fa1be.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-6cfa1208d9874f02990ffe5f49f5267a.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-6d83550622374b449890020e21556c38.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-89a2a42c8f9f47289d79a11f82a33994.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-8a27736de09d420e8a6061a062120bbe.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-9466b52696fd423c9b7446af70ea02aa.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-b0f021cca07d47fd8039276fe127e8e2.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-c7fc5ec415744efcb9cc78847fe27299.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-efaa200d521a49a3989f4b7a46541c83.json (1175 bytes)
- .mokioclaw/context/codeAgent/version-1.json (2290 bytes)
- .mokioclaw/context/codeAgent/version-10.json (2291 bytes)
- .mokioclaw/context/codeAgent/version-11.json (2293 bytes)
- .mokioclaw/context/codeAgent/version-12.json (2291 bytes)
- .mokioclaw/context/codeAgent/version-13.json (2289 bytes)
- .mokioclaw/context/codeAgent/version-14.json (2291 bytes)
- .mokioclaw/context/codeAgent/version-15.json (2291 bytes)
- .mokioclaw/context/codeAgent/version-2.json (2290 bytes)
- .mokioclaw/context/codeAgent/version-3.json (2290 bytes)
- .mokioclaw/context/codeAgent/version-4.json (2290 bytes)
- .mokioclaw/context/codeAgent/version-5.json (2276 bytes)
- .mokioclaw/context/codeAgent/version-6.json (2288 bytes)
- .mokioclaw/context/codeAgent/version-7.json (2290 bytes)
- .mokioclaw/context/codeAgent/version-8.json (2290 bytes)
- .mokioclaw/context/codeAgent/version-9.json (2290 bytes)
- .mokioclaw/diagnostics/bash-stderr-34626eb770ec4fe881fd05568f1949a8.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-35724bfbc4bd45a09de1e38743813fad.log (0 bytes)
- .mokioclaw/diagnostics/bash-stdout-8ac17edc811a49e89e098775d5f9d0e5.log (1731 bytes)
- .mokioclaw/diagnostics/bash-stdout-e86ba522b26d46538843b574fa1c8589.log (1105 bytes)
- .mokioclaw/diagnostics/model-stream-0190c37451534907a3fd1250acba86dc.log (1382 bytes)
- .mokioclaw/diagnostics/model-stream-05da010e402e4ba4ae63a61773548c67.log (0 bytes)
