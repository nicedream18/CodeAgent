# MokioClaw Todo

## Plan

Add optional literal (fixed-string) search to grep() and GrepTool. First obtain real repository evidence for grep_tool.py and registry.py, then implement escaping-based literal mode for both rg and Python backends, then run visible tests.

## Todos

- [ ] **todo-1** `pending` Explore src/mokioclaw grep implementation: grep() signature, rg vs Python backend, match ordering, truncation, ignore rules, GrepTool registration.
- [ ] **todo-2** `pending` Implement fixed_strings support in grep() and expose fixed_strings: bool=False on GrepTool.
- [ ] **todo-3** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and verify behavior.

## Acceptance Criteria

- grep() accepts fixed_strings=False keyword and GrepTool exposes fixed_strings: bool=False parameter wired through to grep().
- With fixed_strings=True, regex metacharacters (., (, ), [, ]) match literally.
- fixed_strings=True composes with ignore_case, Chinese paths, ignore rules, and head_limit truncation.
- rg and Python backends return identical matches content and ordering for the same inputs.
- Default (fixed_strings=False) regex behavior is unchanged.
- Only files under src/mokioclaw/** are modified; tests/deps/config untouched.
- Visible test suite passes via PYTHONPATH=src:. python -m pytest.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
- `PYTHONPATH=src:. python -c "from mokioclaw.tools.grep_tool import grep; import inspect; print(inspect.signature(grep))"`
