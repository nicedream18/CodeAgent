# MokioClaw Todo

## Plan

Explore the existing model/tool loop and provider finish_reason plumbing, then implement a truncation policy that invalidates all tool calls from a length/max_tokens response, backfills unexecuted results, allows one re-decision, and safely stops on a second truncation, without executing SDK-completed truncated JSON.

## Todos

- [ ] **todo-1** `pending` Repo exploration: locate finish_reason/length/max_tokens handling, tool-call parsing/execution, and the model/tool round loop in src/mokioclaw/**
- [ ] **todo-2** `pending` Design truncation policy: invalidate ALL tool calls on length/max_tokens, backfill unexecuted results, allow exactly one re-decision, safe stop on second truncation, never execute SDK-completed truncated JSON
- [ ] **todo-3** `pending` Implement the truncation policy in src/mokioclaw/**
- [ ] **todo-4** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and fix regressions
- [ ] **todo-5** `pending` Verify acceptance criteria and report honestly

## Acceptance Criteria

- When a model response has finish_reason in {length, max_tokens}, every tool call in that response is invalidated (including apparently complete ones) and unexecuted tool results are backfilled into the conversation.
- Exactly one re-decision is permitted after a truncation; a second truncation stops safely without executing further tool calls.
- Raw truncated/partial JSON tool arguments are never executed using SDK-completed values.
- Cancellation, correction, and budget checks remain intact.
- Visible tests pass via PYTHONPATH=src:. python -m pytest; only src/mokioclaw/** modified.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
