# MokioClaw Trace Timeline

- trace_id: trace-20261017-012011-017374
- status: failed
- duration_ms: 6872
- workspace: /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261017/trials/M02-auto-3/workspace
- events: 23

## Summary

- nodes: {'intent_router': 1}
- tool_calls: 0
- failed_tool_calls: 0
- approvals: 0
- checkpoints: 3
- final_status: 

## Timeline

- 0ms run_start
- 170ms checkpoint_saved
- 170ms run_started
- 419ms instructions_loaded
- 479ms context_budget
- 479ms llm_stream_start intent_router
- 479ms llm_request intent_router
- 1665ms llm_stream_end intent_router
- 1666ms llm_response intent_router
- 1668ms model_usage
- 1669ms intent_decision
- 1671ms graph_update nodes=intent_router
- 1754ms checkpoint_saved
- 1762ms workflow_selected
- 1768ms context_budget
- 1769ms llm_stream_start repoAgent
- 1769ms llm_request repoAgent
- 6777ms llm_stream_end repoAgent
- 6778ms llm_response repoAgent
- 6778ms model_usage
- 6779ms model_generation_stopped
- 6872ms checkpoint_saved
- 6872ms run_end
