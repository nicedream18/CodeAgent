# MokioClaw Todo

## Plan

Add a dot-in-name assertion to Blueprint.__init__ in src/flask/blueprints.py, matching the existing assert-based convention used for endpoint names, then run the visible test suite.

## Todos

- [x] **todo-1** `completed` Confirm exact location of Blueprint.__init__ name assignment in src/flask/blueprints.py
- [-] **todo-2** `in_progress` Add assertion in Blueprint.__init__ rejecting dots in blueprint name
- [ ] **todo-3** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and confirm no regressions

## Acceptance Criteria

- Blueprint('a.b', __name__) raises AssertionError with a clear message
- Blueprint('ab', __name__) still works and existing tests pass
- Only files under src/flask/** are modified

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
- `PYTHONPATH=src:. python -c "from flask import Blueprint; Blueprint('a.b', __name__)"`
