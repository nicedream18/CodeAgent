# MokioClaw Todo

## Plan

Explore the instruction/rule and tool-execution code paths with tightly bounded reads, then implement context refresh + stale-decision invalidation under src/mokioclaw/**, and verify with the visible test suite.

## Todos

- [ ] **todo-1** `pending` Explore src/mokioclaw to locate instruction/rule handling, FileWrite/FileEdit, and batch tool loop code paths.
- [ ] **todo-2** `pending` Identify visible tests asserting context refresh / decision invalidation / read-not-blocked behavior.
- [ ] **todo-3** `pending` Implement refresh + stale-decision invalidation in src/mokioclaw/** only.
- [ ] **todo-4** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and fix failures.
- [ ] **todo-5** `pending` Verify acceptance criteria and report honestly.

## Acceptance Criteria

- First encounter of a subdirectory AGENTS.md (or a rule change) triggers a context refresh and invalidates not-yet-executed stale modification decisions.
- Direct FileWrite/FileEdit calls and later modifications within the same tool batch do not reuse stale decisions after a rule change.
- A new model request may read the rules and continue; read operations are not permanently blocked.
- Only files under src/mokioclaw/** are modified; tests/deps/config untouched.
- Visible tests pass via PYTHONPATH=src:. python -m pytest.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
