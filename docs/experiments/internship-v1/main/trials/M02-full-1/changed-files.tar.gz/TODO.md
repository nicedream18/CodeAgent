# MokioClaw Todo

## Plan

Fix truncated-response tool-call handling in src/mokioclaw/providers: invalidate all calls, append placeholder results, single re-decision, safe stop, no SDK-completed execution, preserve cancellation/correction/budget checks.

## Todos

- [ ] **todo-1** `pending` Read generation.py + openai_provider.py truncation/retry paths in full (targeted, small scope).
- [ ] **todo-2** `pending` Identify where tool calls from a truncated response are executed and where placeholder results are appended.
- [ ] **todo-3** `pending` Implement: invalidate ALL tool calls on truncation, append 'not executed' results, allow exactly one re-decision, safe stop on second truncation, never execute SDK-completed half-JSON.
- [ ] **todo-4** `pending` Preserve cancellation, correction, and budget checks around the retry loop.
- [ ] **todo-5** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and confirm no regressions.

## Acceptance Criteria

- On finish_reason length/max_tokens, every tool call in that response (including seemingly complete ones) is invalidated and receives a placeholder 'not executed' result.
- Exactly one re-decision is allowed after truncation; a second truncation stops safely without executing tools.
- Raw truncated/half-JSON tool arguments are never executed using SDK-completed values.
- Cancellation, correction, and budget checks remain in effect around the retry loop.
- Visible test suite passes with PYTHONPATH=src:. python -m pytest.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
