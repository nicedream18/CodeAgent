# MokioClaw Recovery

- status: failed
- mode: light
- updated_at: 2026-10-16T14:37:16.991586+00:00
- latest_node: repoAgent
- next_node: 
- attempts: 0 / 3
- workspace: /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261016/trials/M02-full-1/workspace
- resume: `uv run mokioclaw --resume /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261016/trials/M02-full-1/workspace`

## Task
模型返回 length/max_tokens 时，该响应的所有工具调用（包括看似完整的调用）都必须作废并补齐未执行结果；只允许重新决策一次，再次截断安全停止。原始半截 JSON 不得用 SDK 补全值执行。保留取消、纠正和预算检查。
允许修改范围：src/mokioclaw/**

评测环境：只修改允许的源代码，禁止修改测试、依赖和测试配置。隐藏测试在外部验收。可以新增源代码辅助文件；TODO.md/NOTEPAD.md/HISTORY_SUMMARY.md 为允许的过程记录。Bash 使用离线 Docker 和预装依赖，不要联网或装包；使用 PYTHONPATH=src:. python -m pytest 运行可见测试。不使用网页、MCP、自定义 hooks、持久授权或后台执行。最后如实说明实现与验证，最后一行用 AGENT_CLAIM: solved 或 AGENT_CLAIM: unsolved 标明自评。

## Plan
Fix truncated-response tool-call handling in src/mokioclaw/providers: invalidate all calls, append placeholder results, single re-decision, safe stop, no SDK-completed execution, preserve cancellation/correction/budget checks.

## Todos
- [pending] Read generation.py + openai_provider.py truncation/retry paths in full (targeted, small scope).
- [pending] Identify where tool calls from a truncated response are executed and where placeholder results are appended.
- [pending] Implement: invalidate ALL tool calls on truncation, append 'not executed' results, allow exactly one re-decision, safe stop on second truncation, never execute SDK-completed half-JSON.
- [pending] Preserve cancellation, correction, and budget checks around the retry loop.
- [pending] Run visible tests with PYTHONPATH=src:. python -m pytest and confirm no regressions.

## Acceptance Criteria
- On finish_reason length/max_tokens, every tool call in that response (including seemingly complete ones) is invalidated and receives a placeholder 'not executed' result.
- Exactly one re-decision is allowed after truncation; a second truncation stops safely without executing tools.
- Raw truncated/half-JSON tool arguments are never executed using SDK-completed values.
- Cancellation, correction, and budget checks remain in effect around the retry loop.
- Visible test suite passes with PYTHONPATH=src:. python -m pytest.

## Verification Commands
- PYTHONPATH=src:. python -m pytest -q

## Sources
- (none)

## Recent Summaries
- research: (none)
- codeAgent: (none)
- verifier: (none)
- last_error: (none)

## Recent Files
- .codegraph/.gitignore (173 bytes)
- .codegraph/daemon.pid (144 bytes)
- .gitignore (83 bytes)
- .mokioclaw/context/planner/current.json (48 bytes)
- .mokioclaw/context/planner/facts-96cc1fd612244c9887457d7493b3bc64.json (1637 bytes)
- .mokioclaw/context/planner/facts-d78c5a424d9b4be39ad866692190e983.json (2832 bytes)
- .mokioclaw/context/planner/version-5.json (2752 bytes)
- .mokioclaw/context/planner/version-9.json (3945 bytes)
- .mokioclaw/context/repoAgent-/current.json (48 bytes)
- .mokioclaw/context/repoAgent-/facts-0448d4dfec164f83afaa6f0dd9f95202.json (1060 bytes)
- .mokioclaw/context/repoAgent-/version-1.json (2174 bytes)
- .mokioclaw/context/repoAgent-3f16cacb-479/current.json (48 bytes)
- .mokioclaw/context/repoAgent-3f16cacb-479/facts-6026a1d71d0a46e59faa97149b36d1fc.json (1060 bytes)
- .mokioclaw/context/repoAgent-3f16cacb-479/facts-e9b202ebe4cb4b4b945a58c6c2a19db2.json (1060 bytes)
- .mokioclaw/context/repoAgent-3f16cacb-479/version-2.json (2186 bytes)
- .mokioclaw/context/repoAgent-3f16cacb-479/version-3.json (2189 bytes)
- .mokioclaw/context/repoAgent-b03f9d0e-868/current.json (50 bytes)
- .mokioclaw/context/repoAgent-b03f9d0e-868/facts-eb137f99b0ea49b98d068029b1719c1c.json (1060 bytes)
- .mokioclaw/context/repoAgent-b03f9d0e-868/version-10.json (2156 bytes)
- .mokioclaw/context/repoAgent-b9ff1c0c-cd0/current.json (48 bytes)
- .mokioclaw/context/repoAgent-b9ff1c0c-cd0/facts-2ee113bb64f84ad99fa1089a0fac84f5.json (1060 bytes)
- .mokioclaw/context/repoAgent-b9ff1c0c-cd0/facts-9cb30dd6ebbb41c58985c243a52ce08e.json (1060 bytes)
- .mokioclaw/context/repoAgent-b9ff1c0c-cd0/facts-ce108c111ce64e9ca24eb6d8b0f087d6.json (1060 bytes)
- .mokioclaw/context/repoAgent-b9ff1c0c-cd0/version-6.json (4941 bytes)
- .mokioclaw/context/repoAgent-b9ff1c0c-cd0/version-7.json (2188 bytes)
- .mokioclaw/context/repoAgent-b9ff1c0c-cd0/version-8.json (2188 bytes)
- .mokioclaw/context/repoAgent-db8f6558-56f/current.json (48 bytes)
- .mokioclaw/context/repoAgent-db8f6558-56f/facts-73dc2e0248c04a0ba0d726e74110daf9.json (1060 bytes)
- .mokioclaw/context/repoAgent-db8f6558-56f/version-4.json (2195 bytes)
- .mokioclaw/diagnostics/model-stream-02cb14cbd9c546ed9d52a161699949a0.log (39 bytes)
- .mokioclaw/diagnostics/model-stream-097572b75b2e4e248c350f8e45e5068a.log (10669 bytes)
- .mokioclaw/diagnostics/model-stream-0b27127516b04a16afa3eacea7aa1f2b.log (79 bytes)
- .mokioclaw/diagnostics/model-stream-20d426ca33c2471eb25c406462c893dc.log (1535 bytes)
- .mokioclaw/diagnostics/model-stream-2214e84821b14e4d89afb73fd77fe296.log (78 bytes)
- .mokioclaw/diagnostics/model-stream-2964efdda8134c659ccd3905fdc41901.log (1310 bytes)
- .mokioclaw/diagnostics/model-stream-2976a766b2324f78b61fd1d7ce4e31f7.log (1160 bytes)
- .mokioclaw/diagnostics/model-stream-3113f14985a6433dbe3a38f483045980.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-472f48363ef84035bbb0b2c9fdc8b290.log (82 bytes)
- .mokioclaw/diagnostics/model-stream-499a6b00072343f1abbe40598e583e67.log (86 bytes)
- .mokioclaw/diagnostics/model-stream-503e4c429f684e70880116c112a473c5.log (107 bytes)
