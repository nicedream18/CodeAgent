# MokioClaw Todo

## Plan

Explore exact APIs, design a rule-epoch/refresh invalidation mechanism, implement within src/mokioclaw/**, then run visible tests and verify acceptance criteria.

## Todos

- [ ] **todo-1** `pending` Explore repo: exact APIs in core/instructions.py, core/context_control.py, tools/file_tools.py, core/tool_loop.py, tools/registry.py, core/tool_context.py; find existing epoch/generation concepts and relevant visible tests.
- [ ] **todo-2** `pending` Design rule-epoch/refresh mechanism: detect first encounter of subdirectory AGENTS.md or rule content change; bump epoch; invalidate pending modification decisions.
- [ ] **todo-3** `pending` Implement in src/mokioclaw/**: refresh+invalidation in instructions/context_control; FileWrite/FileEdit and batched tool-loop modifications re-check epoch; reads not permanently blocked.
- [ ] **todo-4** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and confirm no regressions.
- [ ] **todo-5** `pending` Verify behavior against acceptance criteria; fix gaps if verifier fails.

## Acceptance Criteria

- First encounter of a subdirectory AGENTS.md (or a rule content change) triggers a context refresh and invalidates not-yet-executed old modification decisions.
- Direct FileWrite/FileEdit calls do not apply using stale pre-refresh decisions.
- Subsequent modifications within the same batch of tool calls do not reuse stale decisions.
- A new model request to read rules after refresh is allowed to proceed; read operations are not permanently blocked.
- Only src/mokioclaw/** modified; tests/deps/config untouched.
- Visible tests pass via PYTHONPATH=src:. python -m pytest.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
