# MokioClaw Todo

## Plan

Add a validated --since ISO8601 (UTC-required) filter to the mokioclaw trace command, applied in UTC with inclusive boundary, skipping timestamp-less/invalid records only when the flag is present, and composable with --follow. Explore narrowly first, then implement in src/mokioclaw/** and verify with the visible test suite.

## Todos

- [ ] **todo-1** `pending` Explore repo: locate trace CLI command, record model/timestamp field, --follow loop, existing tests, Typer error conventions.
- [ ] **todo-2** `pending` Implement --since option: strict ISO8601 with Z/UTC offset validation, usage error before any run starts.
- [ ] **todo-3** `pending` Implement UTC-inclusive filtering: skip missing/invalid timestamps only when --since given; unchanged output otherwise; compose with --follow.
- [ ] **todo-4** `pending` Run visible tests via PYTHONPATH=src:. python -m pytest and verify behavior.

## Acceptance Criteria

- `trace` command accepts `--since` ISO8601 value requiring 'Z' or explicit UTC offset; naive/invalid values raise a CLI usage error (non-zero exit, no run/trace source started).
- With --since, records are compared in UTC and the boundary instant is included (>= since).
- With --since, records with missing or unparseable timestamps are skipped; without --since, output is byte-for-byte unchanged from before.
- since composes with --follow and other existing filters.
- Only files under src/mokioclaw/** are modified; tests/deps/config untouched.
- Visible test suite passes with PYTHONPATH=src:. python -m pytest.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
- `PYTHONPATH=src:. python -m mokioclaw trace --help`
