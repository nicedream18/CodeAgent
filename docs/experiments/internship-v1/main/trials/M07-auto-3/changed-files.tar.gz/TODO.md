# MokioClaw Todo

## Plan

Ground the change with a read-only repo trace, then implement fixed_strings in grep() and GrepTool (rg + Python backends), then verify with visible tests and targeted literal-mode checks.

## Todos

- [ ] **todo-1** `pending` Explore src/mokioclaw grep implementation: grep_tool.py, tools/registry.py GrepTool schema, backend selection (rg vs Python), ignore rules, ordering, head_limit semantics, and existing tests.
- [ ] **todo-2** `pending` Implement fixed_strings support in grep() and thread it to both rg (--fixed-strings) and Python backends; expose fixed_strings: bool=False on GrepTool and its registry lambda.
- [ ] **todo-3** `pending` Verify: run visible tests with PYTHONPATH=src:. python -m pytest, plus targeted checks that literal mode matches dots/parens/brackets, honors ignore_case, Chinese paths, ignore rules, head_limit, and that rg/Python backends agree in content and order while regex default is unchanged.

## Acceptance Criteria

- grep() accepts fixed_strings: bool=False and treats pattern literally when True (dots, parens, brackets matched literally).
- GrepTool exposes fixed_strings: bool=False and forwards it to grep().
- Literal mode composes with ignore_case, Chinese paths, ignore rules, and head_limit.
- rg and Python backends produce identical matches content and order for both literal and regex modes.
- Default regex behavior unchanged; visible tests pass via PYTHONPATH=src:. python -m pytest.
- Only files under src/mokioclaw/** are modified.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
- `PYTHONPATH=src:. python -c "from mokioclaw.tools.grep_tool import grep; print('import ok')"`
