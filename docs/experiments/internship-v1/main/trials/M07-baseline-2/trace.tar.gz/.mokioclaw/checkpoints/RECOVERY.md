# MokioClaw Recovery

- status: failed
- mode: light
- updated_at: 2026-10-16T14:30:58.833741+00:00
- latest_node: codeAgent
- next_node: 
- attempts: 0 / 3
- workspace: /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261016/trials/M07-baseline-2/workspace
- resume: `uv run mokioclaw --resume /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261016/trials/M07-baseline-2/workspace`

## Task
为 grep(state, pattern, path='.', glob=None, head_limit=50, ignore_case=False, fixed_strings=False) 增加可选字面量搜索，GrepTool 暴露 fixed_strings: bool=False。开启时点、括号、方括号等按字面量匹配，兼容 ignore_case、中文路径、忽略规则、结果上限。rg 与 Python 后端的 matches 内容和顺序保持一致，旧正则默认行为不变。
允许修改范围：src/mokioclaw/**

评测环境：只修改允许的源代码，禁止修改测试、依赖和测试配置。隐藏测试在外部验收。可以新增源代码辅助文件；TODO.md/NOTEPAD.md/HISTORY_SUMMARY.md 为允许的过程记录。Bash 使用离线 Docker 和预装依赖，不要联网或装包；使用 PYTHONPATH=src:. python -m pytest 运行可见测试。不使用网页、MCP、自定义 hooks、持久授权或后台执行。最后如实说明实现与验证，最后一行用 AGENT_CLAIM: solved 或 AGENT_CLAIM: unsolved 标明自评。

## Plan
(none)

## Todos
- (none)

## Acceptance Criteria
- (none)

## Verification Commands
- (none)

## Sources
- (none)

## Recent Summaries
- research: (none)
- codeAgent: (none)
- verifier: (none)
- last_error: (none)

## Recent Files
- .codegraph/.gitignore (173 bytes)
- .codegraph/daemon.pid (144 bytes)
- .gitignore (83 bytes)
- .mokioclaw/context/codeAgent/current.json (50 bytes)
- .mokioclaw/context/codeAgent/facts-035b4bd75b3b4faeacbeebaa27372b2e.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-1038260b2622435ba0d0fb54e994e5d8.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-17b1f4d73858412da52fade02e5f1758.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-308bd4ebe457464f8dbc562daf3ca501.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-362b48e57a2f4ed68751303853308b65.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-380ba9475e1f4b788ef694ed8a655a30.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-3ab1ec3eb7aa4d3f821aa400266d9ecb.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-785bca2f79d74fd69043f5dd1b34cd8a.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-af739e4685404aa2ad19a289607125b5.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-c9b0982dbdd747878a5bac4e6aefda24.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-cd5a3cef062f4bc39f1fbfbb23123789.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-ddc39d8984464a6fb82e0eff35bbe778.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-eb1c8855a0de4f17a0f4534525cd42be.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-ee28cc0d90ad4127ade58542f09c7447.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-ee527cfa3daa42148474cafde06efe89.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-fc6b13b725a141e09d27a825e5a2be2e.json (1175 bytes)
- .mokioclaw/context/codeAgent/version-1.json (2288 bytes)
- .mokioclaw/context/codeAgent/version-10.json (2291 bytes)
- .mokioclaw/context/codeAgent/version-11.json (2291 bytes)
- .mokioclaw/context/codeAgent/version-12.json (2293 bytes)
- .mokioclaw/context/codeAgent/version-13.json (2293 bytes)
- .mokioclaw/context/codeAgent/version-14.json (2293 bytes)
- .mokioclaw/context/codeAgent/version-15.json (2293 bytes)
- .mokioclaw/context/codeAgent/version-16.json (2293 bytes)
- .mokioclaw/context/codeAgent/version-2.json (2288 bytes)
- .mokioclaw/context/codeAgent/version-3.json (2290 bytes)
- .mokioclaw/context/codeAgent/version-4.json (2290 bytes)
- .mokioclaw/context/codeAgent/version-5.json (2290 bytes)
- .mokioclaw/context/codeAgent/version-6.json (2288 bytes)
- .mokioclaw/context/codeAgent/version-7.json (2288 bytes)
- .mokioclaw/context/codeAgent/version-8.json (2291 bytes)
- .mokioclaw/context/codeAgent/version-9.json (2290 bytes)
- .mokioclaw/diagnostics/bash-stderr-15ddaed383944daab69c18fdb77803ea.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-36faf87ed58f4b6e96e28babb6e2e04e.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-5dc56568975c4044867fb663a68f1005.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-89dd75c79e0f451290ad47058e0af3e4.log (0 bytes)
