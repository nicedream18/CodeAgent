# MokioClaw Recovery

- status: failed
- mode: light
- updated_at: 2026-10-16T15:05:38.953724+00:00
- latest_node: intent_router
- next_node: 
- attempts: 0 / 3
- workspace: /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261016/trials/M05-full-1/workspace
- resume: `uv run mokioclaw --resume /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261016/trials/M05-full-1/workspace`

## Task
修复后台 Subagent 与前台取消信号耦合的问题。显式后台任务必须有独立 RunControl，父运行 Ctrl+C 不取消后台任务；同步 Subagent 仍遵循前台控制。私有资源必须正确关闭。
允许修改范围：src/mokioclaw/**

评测环境：只修改允许的源代码，禁止修改测试、依赖和测试配置。隐藏测试在外部验收。可以新增源代码辅助文件；TODO.md/NOTEPAD.md/HISTORY_SUMMARY.md 为允许的过程记录。Bash 使用离线 Docker 和预装依赖，不要联网或装包；使用 PYTHONPATH=src:. python -m pytest 运行可见测试。不使用网页、MCP、自定义 hooks、持久授权或后台执行。最后如实说明实现与验证，最后一行用 AGENT_CLAIM: solved 或 AGENT_CLAIM: unsolved 标明自评。

## Plan
(none)

## Todos
- (none)

## Acceptance Criteria
- (none)

## Verification Commands
- (none)

## Sources
- (none)

## Recent Summaries
- research: (none)
- codeAgent: (none)
- verifier: (none)
- last_error: (none)

## Recent Files
- .codegraph/.gitignore (173 bytes)
- .codegraph/daemon.pid (144 bytes)
- .gitignore (83 bytes)
- .mokioclaw/diagnostics/model-stream-ce080b0b8603432c9a0b0b51112f3020.log (0 bytes)
- .mokioclaw/inbox/local-d033205a70cd473d895e3d2d281437e3.json (2 bytes)
- .mokioclaw/session/writer.lock (62 bytes)
- .mokioclaw/traces/trace-20261016-230537-0075aa/events.jsonl (8945 bytes)
- .python-version (5 bytes)
- Makefile (346 bytes)
- README.md (77 bytes)
- assets/logo-no-words.png (154708 bytes)
- evolution.excalidraw (305777 bytes)
- logo with no words.png (154708 bytes)
- logo.png (295419 bytes)
- main.py (73 bytes)
- pyproject.toml (1418 bytes)
- scripts/gen_protocol_doc.py (2006 bytes)
- src/mokioclaw/__init__.py (100 bytes)
- src/mokioclaw/__main__.py (72 bytes)
- src/mokioclaw/agents/__init__.py (164 bytes)
- src/mokioclaw/agents/code_agent.py (11975 bytes)
- src/mokioclaw/agents/registry.py (19308 bytes)
- src/mokioclaw/agents/repo_agent.py (4301 bytes)
- src/mokioclaw/agents/search_agent.py (7895 bytes)
- src/mokioclaw/cli/__init__.py (30 bytes)
- src/mokioclaw/cli/app.py (17801 bytes)
- src/mokioclaw/cli/event_summary.py (18557 bytes)
- src/mokioclaw/cli/formatter.py (22212 bytes)
- src/mokioclaw/cli/tui/__init__.py (100 bytes)
- src/mokioclaw/cli/tui/app.py (45616 bytes)
- src/mokioclaw/cli/tui/approval.py (4566 bytes)
- src/mokioclaw/cli/tui/input.py (3156 bytes)
- src/mokioclaw/cli/tui/logo.py (3712 bytes)
- src/mokioclaw/core/__init__.py (41 bytes)
- src/mokioclaw/core/agent.py (12487 bytes)
- src/mokioclaw/core/agent_profiles.py (4019 bytes)
- src/mokioclaw/core/approval.py (2605 bytes)
- src/mokioclaw/core/approval_rules.py (9591 bytes)
- src/mokioclaw/core/artifacts.py (2764 bytes)
- src/mokioclaw/core/changes.py (9873 bytes)
