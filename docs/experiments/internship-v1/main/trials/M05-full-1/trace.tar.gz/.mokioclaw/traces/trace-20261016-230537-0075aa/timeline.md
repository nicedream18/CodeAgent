# MokioClaw Trace Timeline

- trace_id: trace-20261016-230537-0075aa
- status: failed
- duration_ms: 1116
- workspace: /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261016/trials/M05-full-1/workspace
- events: 13

## Summary

- nodes: {}
- tool_calls: 0
- failed_tool_calls: 0
- approvals: 0
- checkpoints: 2
- final_status: 

## Timeline

- 1ms run_start
- 308ms checkpoint_saved
- 308ms run_started
- 717ms instructions_loaded
- 868ms context_budget
- 869ms llm_stream_start intent_router
- 870ms llm_request intent_router
- 922ms llm_stream_end intent_router
- 922ms llm_response intent_router
- 925ms model_usage
- 927ms model_generation_stopped
- 1116ms checkpoint_saved
- 1116ms run_end
