# MokioClaw Recovery

- status: failed
- mode: light
- updated_at: 2026-10-16T14:32:07.798919+00:00
- latest_node: codeAgent
- next_node: 
- attempts: 0 / 3
- workspace: /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261016/trials/M07-baseline-1/workspace
- resume: `uv run mokioclaw --resume /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261016/trials/M07-baseline-1/workspace`

## Task
为 grep(state, pattern, path='.', glob=None, head_limit=50, ignore_case=False, fixed_strings=False) 增加可选字面量搜索，GrepTool 暴露 fixed_strings: bool=False。开启时点、括号、方括号等按字面量匹配，兼容 ignore_case、中文路径、忽略规则、结果上限。rg 与 Python 后端的 matches 内容和顺序保持一致，旧正则默认行为不变。
允许修改范围：src/mokioclaw/**

评测环境：只修改允许的源代码，禁止修改测试、依赖和测试配置。隐藏测试在外部验收。可以新增源代码辅助文件；TODO.md/NOTEPAD.md/HISTORY_SUMMARY.md 为允许的过程记录。Bash 使用离线 Docker 和预装依赖，不要联网或装包；使用 PYTHONPATH=src:. python -m pytest 运行可见测试。不使用网页、MCP、自定义 hooks、持久授权或后台执行。最后如实说明实现与验证，最后一行用 AGENT_CLAIM: solved 或 AGENT_CLAIM: unsolved 标明自评。

## Plan
(none)

## Todos
- (none)

## Acceptance Criteria
- (none)

## Verification Commands
- (none)

## Sources
- (none)

## Recent Summaries
- research: (none)
- codeAgent: (none)
- verifier: (none)
- last_error: (none)

## Recent Files
- .codegraph/.gitignore (173 bytes)
- .codegraph/daemon.pid (144 bytes)
- .gitignore (83 bytes)
- .mokioclaw/context/codeAgent/current.json (50 bytes)
- .mokioclaw/context/codeAgent/facts-14ced30581894ae5842e5ba013b51321.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-529c4124325a4369b8ccf2150b8b8591.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-5accc71e967b4ebe9fd8185bb3d2f674.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-70ca38a028e44675bcfad851d312a5e2.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-8e7c572de72b40659965904c5e4518a2.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-9576db033197458ab3d6dd3e39c9ae7a.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-cd26d196e0f84336b216fc189a379e65.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-d399636c3eaa44fe96ca99df8de396c1.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-d592677a091f40009d1fecb2353d4f94.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-d5e320c4aed246ef89e6748a51a45d5d.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-d734eccd2aa24a199bc6e601ab681a2b.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-d946c6fc27a1428e8ef9adbdd578578b.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-d9d257e313fa49ae9b83f3042f4f630f.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-f3f73e2ff807434699709ccf083956f6.json (1175 bytes)
- .mokioclaw/context/codeAgent/facts-fcc6cc2b06ab4775844738bc289c8c92.json (1175 bytes)
- .mokioclaw/context/codeAgent/version-1.json (2288 bytes)
- .mokioclaw/context/codeAgent/version-10.json (2291 bytes)
- .mokioclaw/context/codeAgent/version-11.json (2291 bytes)
- .mokioclaw/context/codeAgent/version-12.json (2291 bytes)
- .mokioclaw/context/codeAgent/version-13.json (2291 bytes)
- .mokioclaw/context/codeAgent/version-14.json (2291 bytes)
- .mokioclaw/context/codeAgent/version-15.json (2291 bytes)
- .mokioclaw/context/codeAgent/version-2.json (2288 bytes)
- .mokioclaw/context/codeAgent/version-3.json (2268 bytes)
- .mokioclaw/context/codeAgent/version-4.json (2288 bytes)
- .mokioclaw/context/codeAgent/version-5.json (2288 bytes)
- .mokioclaw/context/codeAgent/version-6.json (2292 bytes)
- .mokioclaw/context/codeAgent/version-7.json (2290 bytes)
- .mokioclaw/context/codeAgent/version-8.json (2290 bytes)
- .mokioclaw/context/codeAgent/version-9.json (2288 bytes)
- .mokioclaw/diagnostics/bash-stderr-14e924edb90b4911a44c334dd6d26ace.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-7f7d497709684ab18f101224bcb22aa8.log (0 bytes)
- .mokioclaw/diagnostics/bash-stdout-1439df52f2e6439d9e486cc13da0469e.log (1731 bytes)
- .mokioclaw/diagnostics/bash-stdout-97350f4f153a4480b3eaf9544e660541.log (1105 bytes)
- .mokioclaw/diagnostics/model-stream-005e1d2918ba47e397cd7bfa45c20d2e.log (70 bytes)
- .mokioclaw/diagnostics/model-stream-057e3c1be3a643a78ead9882582ef608.log (1389 bytes)
