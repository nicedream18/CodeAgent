# MokioClaw Todo

## Plan

Add optional literal (fixed-string) search to grep: extend grep() signature with fixed_strings=False, wire rg -F and Python literal fallback, expose fixed_strings in GrepTool schema, keep both backends consistent and default regex behavior unchanged.

## Todos

- [ ] **todo-1** `pending` Explore grep_tool.py, registry.py, execution.py and tests to confirm exact rg invocation, Python fallback, result dict keys, and GrepTool schema.
- [ ] **todo-2** `pending` Implement fixed_strings support in grep_tool.grep (rg -F flag + Python fallback literal matching) preserving ignore_case, glob, ignore rules, head_limit, ordering.
- [ ] **todo-3** `pending` Expose fixed_strings: bool=False in GrepTool schema/registry.
- [ ] **todo-4** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and confirm no regressions.

## Acceptance Criteria

- grep() accepts fixed_strings: bool=False and GrepTool exposes fixed_strings: bool=False
- When fixed_strings=True, regex metacharacters (. ( ) [ ] etc.) match literally in both rg and Python backends
- ignore_case, glob, ignore rules, head_limit, and Chinese paths still work with fixed_strings
- rg and Python backends produce identical matches content and order
- Default regex behavior unchanged when fixed_strings=False
- Visible tests pass via PYTHONPATH=src:. python -m pytest

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
