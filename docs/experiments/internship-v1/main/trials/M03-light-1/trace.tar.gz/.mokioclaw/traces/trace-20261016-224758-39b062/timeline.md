# MokioClaw Trace Timeline

- trace_id: trace-20261016-224758-39b062
- status: failed
- duration_ms: 683
- workspace: /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261016/trials/M03-light-1/workspace
- events: 13

## Summary

- nodes: {}
- tool_calls: 0
- failed_tool_calls: 0
- approvals: 0
- checkpoints: 2
- final_status: 

## Timeline

- 0ms run_start
- 243ms checkpoint_saved
- 244ms run_started
- 488ms instructions_loaded
- 561ms context_budget
- 562ms llm_stream_start intent_router
- 562ms llm_request intent_router
- 585ms llm_stream_end intent_router
- 586ms llm_response intent_router
- 587ms model_usage
- 588ms model_generation_stopped
- 682ms checkpoint_saved
- 683ms run_end
