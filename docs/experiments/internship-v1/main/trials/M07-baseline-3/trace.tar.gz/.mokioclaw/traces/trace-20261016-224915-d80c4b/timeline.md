# MokioClaw Trace Timeline

- trace_id: trace-20261016-224915-d80c4b
- status: failed
- duration_ms: 10773
- workspace: /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261016/trials/M07-baseline-3/workspace
- events: 58

## Summary

- nodes: {}
- tool_calls: 6
- failed_tool_calls: 1
- approvals: 0
- checkpoints: 3
- final_status: 

## Timeline

- 0ms run_start
- 139ms checkpoint_saved
- 140ms run_started
- 143ms memory_snapshot codeAgent
- 336ms plan_snapshot codeAgent
- 336ms instructions_loaded
- 385ms context_budget
- 386ms llm_stream_start codeAgent
- 386ms llm_request codeAgent
- 1354ms llm_stream_end codeAgent
- 1356ms llm_response codeAgent
- 1356ms model_usage
- 1359ms tool_call codeAgent Bash
- 1360ms tool_result codeAgent Bash
- 1438ms checkpoint_saved
- 1439ms tool_call codeAgent GrepTool
- 1439ms permission_granted
- 1439ms tool_result codeAgent GrepTool
- 1439ms context_budget
- 1439ms llm_stream_start codeAgent
- 1440ms llm_request codeAgent
- 2528ms llm_stream_end codeAgent
- 2529ms llm_response codeAgent
- 2530ms model_usage
- 2532ms tool_call codeAgent FileReadTool
- 2532ms permission_granted
- 2533ms tool_result codeAgent FileReadTool
- 2534ms tool_call codeAgent FileGlobTool
- 2535ms permission_granted
- 2556ms tool_result codeAgent FileGlobTool
- 2557ms context_budget
- 2559ms llm_stream_start context_compressor
- 2559ms llm_request context_compressor
- 4510ms llm_stream_end context_compressor
- 4511ms llm_response context_compressor
- 4512ms model_usage
- 4513ms context_compression
- 4516ms context_budget
- 4516ms llm_stream_start codeAgent
- 4517ms llm_request codeAgent
- 5562ms llm_stream_end codeAgent
- 5563ms llm_response codeAgent
- 5564ms model_usage
- 5566ms tool_call codeAgent FileReadTool
- 5566ms permission_granted
- 5567ms tool_result codeAgent FileReadTool
- 5569ms tool_call codeAgent FileGlobTool
- 5569ms permission_granted
- 5589ms tool_result codeAgent FileGlobTool
- 5592ms context_budget
- 5592ms llm_stream_start context_compressor
- 5593ms llm_request context_compressor
- 10598ms llm_stream_end context_compressor
- 10599ms llm_response context_compressor
- 10599ms model_usage
- 10600ms model_generation_stopped
- 10773ms checkpoint_saved
- 10773ms run_end
