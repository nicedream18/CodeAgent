# MokioClaw Recovery

- status: failed
- mode: light
- updated_at: 2026-10-16T14:49:27.663732+00:00
- latest_node: context_compressor
- next_node: 
- attempts: 0 / 3
- workspace: /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261016/trials/M07-baseline-3/workspace
- resume: `uv run mokioclaw --resume /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261016/trials/M07-baseline-3/workspace`

## Task
为 grep(state, pattern, path='.', glob=None, head_limit=50, ignore_case=False, fixed_strings=False) 增加可选字面量搜索，GrepTool 暴露 fixed_strings: bool=False。开启时点、括号、方括号等按字面量匹配，兼容 ignore_case、中文路径、忽略规则、结果上限。rg 与 Python 后端的 matches 内容和顺序保持一致，旧正则默认行为不变。
允许修改范围：src/mokioclaw/**

评测环境：只修改允许的源代码，禁止修改测试、依赖和测试配置。隐藏测试在外部验收。可以新增源代码辅助文件；TODO.md/NOTEPAD.md/HISTORY_SUMMARY.md 为允许的过程记录。Bash 使用离线 Docker 和预装依赖，不要联网或装包；使用 PYTHONPATH=src:. python -m pytest 运行可见测试。不使用网页、MCP、自定义 hooks、持久授权或后台执行。最后如实说明实现与验证，最后一行用 AGENT_CLAIM: solved 或 AGENT_CLAIM: unsolved 标明自评。

## Plan
(none)

## Todos
- (none)

## Acceptance Criteria
- (none)

## Verification Commands
- (none)

## Sources
- (none)

## Recent Summaries
- research: (none)
- codeAgent: (none)
- verifier: (none)
- last_error: (none)

## Recent Files
- .codegraph/.gitignore (173 bytes)
- .codegraph/daemon.pid (144 bytes)
- .gitignore (83 bytes)
- .mokioclaw/context/codeAgent/current.json (48 bytes)
- .mokioclaw/context/codeAgent/facts-290762010932457a97f1dfe53f63e7fb.json (1175 bytes)
- .mokioclaw/context/codeAgent/version-1.json (2292 bytes)
- .mokioclaw/diagnostics/model-stream-1389e26ad5f34a22aa342088fa7c4c12.log (70 bytes)
- .mokioclaw/diagnostics/model-stream-6f0e82418e0146a29782424228a33234.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-770713cbb03d428b8b0445891718fc8d.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-9fd71ce150ee495dac2efde124c08021.log (75 bytes)
- .mokioclaw/diagnostics/model-stream-b9f0b7f830c34354a26b31adc3f4c408.log (1053 bytes)
- .mokioclaw/inbox/local-af9ba00d4f8847efb15e7f5a0e9d4f91.json (2 bytes)
- .mokioclaw/session/writer.lock (62 bytes)
- .mokioclaw/traces/trace-20261016-224915-d80c4b/events.jsonl (56188 bytes)
- .python-version (5 bytes)
- HISTORY_SUMMARY.md (2354 bytes)
- Makefile (346 bytes)
- README.md (77 bytes)
- assets/logo-no-words.png (154708 bytes)
- evolution.excalidraw (305777 bytes)
- logo with no words.png (154708 bytes)
- logo.png (295419 bytes)
- main.py (73 bytes)
- pyproject.toml (1418 bytes)
- scripts/gen_protocol_doc.py (2006 bytes)
- src/mokioclaw/__init__.py (100 bytes)
- src/mokioclaw/__main__.py (72 bytes)
- src/mokioclaw/agents/__init__.py (164 bytes)
- src/mokioclaw/agents/code_agent.py (11975 bytes)
- src/mokioclaw/agents/registry.py (19308 bytes)
- src/mokioclaw/agents/repo_agent.py (4301 bytes)
- src/mokioclaw/agents/search_agent.py (7895 bytes)
- src/mokioclaw/cli/__init__.py (30 bytes)
- src/mokioclaw/cli/app.py (17801 bytes)
- src/mokioclaw/cli/event_summary.py (18557 bytes)
- src/mokioclaw/cli/formatter.py (22212 bytes)
- src/mokioclaw/cli/tui/__init__.py (100 bytes)
- src/mokioclaw/cli/tui/app.py (45616 bytes)
- src/mokioclaw/cli/tui/approval.py (4566 bytes)
- src/mokioclaw/cli/tui/input.py (3156 bytes)
