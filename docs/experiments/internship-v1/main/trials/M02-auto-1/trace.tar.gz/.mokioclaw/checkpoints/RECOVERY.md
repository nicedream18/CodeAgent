# MokioClaw Recovery

- status: failed
- mode: light
- updated_at: 2026-10-16T14:13:13.757128+00:00
- latest_node: repoAgent
- next_node: 
- attempts: 0 / 3
- workspace: /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261016/trials/M02-auto-1/workspace
- resume: `uv run mokioclaw --resume /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261016/trials/M02-auto-1/workspace`

## Task
模型返回 length/max_tokens 时，该响应的所有工具调用（包括看似完整的调用）都必须作废并补齐未执行结果；只允许重新决策一次，再次截断安全停止。原始半截 JSON 不得用 SDK 补全值执行。保留取消、纠正和预算检查。
允许修改范围：src/mokioclaw/**

评测环境：只修改允许的源代码，禁止修改测试、依赖和测试配置。隐藏测试在外部验收。可以新增源代码辅助文件；TODO.md/NOTEPAD.md/HISTORY_SUMMARY.md 为允许的过程记录。Bash 使用离线 Docker 和预装依赖，不要联网或装包；使用 PYTHONPATH=src:. python -m pytest 运行可见测试。不使用网页、MCP、自定义 hooks、持久授权或后台执行。最后如实说明实现与验证，最后一行用 AGENT_CLAIM: solved 或 AGENT_CLAIM: unsolved 标明自评。

## Plan
Fix truncation (finish_reason length/max_tokens) handling so that ALL tool calls in a truncated response are voided and get placeholder 'not executed' results, only one re-decision is allowed, a second truncation stops safely, raw half-JSON is never executed via SDK-completed values, and cancellation/correction/budget checks are preserved. Scope: src/mokioclaw/** only.

## Todos
- [pending] Read truncation-relevant code in full: providers/generation.py, providers/openai_provider.py (retry wrapper), core/tool_loop.py, core/run_control.py, core/context_budget.py, core/protocol/__init__.py, tools/execution.py.
- [pending] Identify visible tests covering truncation/retry/cancellation/budget and record exact assertions.
- [pending] Implement: void ALL tool calls of a truncated response, append placeholder results for every call id, single re-decision, safe stop on second truncation, never execute SDK-completed raw JSON, preserve cancel/correction/budget checks.
- [pending] Run visible tests with PYTHONPATH=src:. python -m pytest and fix regressions.
- [pending] Verify acceptance criteria against implementation evidence and report honestly.

## Acceptance Criteria
- When a model response has finish_reason length/max_tokens, every tool call in that response (including ones that look complete) is discarded and never executed.
- A placeholder 'not executed / truncated' tool result is appended for each discarded tool call id so the conversation stays well-formed.
- Exactly one re-decision is permitted after a truncation; a second truncation stops safely (no infinite loop, no execution).
- Raw truncated/half JSON arguments are never executed using SDK auto-completed values.
- Cancellation, correction, and context-budget checks remain in effect on the truncation/retry path.
- Visible test suite passes: PYTHONPATH=src:. python -m pytest.
- Only files under src/mokioclaw/** are modified (plus allowed process notes).

## Verification Commands
- PYTHONPATH=src:. python -m pytest -q
- PYTHONPATH=src:. python -m pytest tests/test_reliability_extensions.py tests/test_run_cancellation.py tests/test_context_governance.py tests/test_protocol_contracts.py -q

## Sources
- (none)

## Recent Summaries
- research: (none)
- codeAgent: (none)
- verifier: (none)
- last_error: (none)

## Recent Files
- .codegraph/.gitignore (173 bytes)
- .codegraph/daemon.pid (144 bytes)
- .gitignore (83 bytes)
- .mokioclaw/context/planner/current.json (50 bytes)
- .mokioclaw/context/planner/facts-0b48b4ebe1944970bdbbcd645035834a.json (3545 bytes)
- .mokioclaw/context/planner/facts-0da2d933d85e4f41a1a1fd677b95dea4.json (3549 bytes)
- .mokioclaw/context/planner/facts-7068ac312fc1497a9e3d91f522ff8eaa.json (1637 bytes)
- .mokioclaw/context/planner/facts-c1ab4c1f58ae434e8ff2af5d6f08ce9c.json (3545 bytes)
- .mokioclaw/context/planner/version-10.json (4661 bytes)
- .mokioclaw/context/planner/version-11.json (4657 bytes)
- .mokioclaw/context/planner/version-4.json (2528 bytes)
- .mokioclaw/context/planner/version-5.json (4661 bytes)
- .mokioclaw/context/repoAgent-/current.json (48 bytes)
- .mokioclaw/context/repoAgent-/facts-42fb7fd30e2347e2844ffa2134918d6d.json (1060 bytes)
- .mokioclaw/context/repoAgent-/version-1.json (2174 bytes)
- .mokioclaw/context/repoAgent-25ec6d1e-349/current.json (48 bytes)
- .mokioclaw/context/repoAgent-25ec6d1e-349/facts-0b9a821164da4916a24ffe1a106d957a.json (1060 bytes)
- .mokioclaw/context/repoAgent-25ec6d1e-349/facts-0e1f099807544709a10a5971a2f63821.json (1060 bytes)
- .mokioclaw/context/repoAgent-25ec6d1e-349/facts-b052ae27585143fb839b096c49fc5d1d.json (1060 bytes)
- .mokioclaw/context/repoAgent-25ec6d1e-349/facts-eafe8205d004451c9898f0699c681e8a.json (1060 bytes)
- .mokioclaw/context/repoAgent-25ec6d1e-349/version-6.json (1936 bytes)
- .mokioclaw/context/repoAgent-25ec6d1e-349/version-7.json (2188 bytes)
- .mokioclaw/context/repoAgent-25ec6d1e-349/version-8.json (2189 bytes)
- .mokioclaw/context/repoAgent-25ec6d1e-349/version-9.json (2189 bytes)
- .mokioclaw/context/repoAgent-32acaf55-71e/current.json (48 bytes)
- .mokioclaw/context/repoAgent-32acaf55-71e/facts-6a5f70fea2b041f1ae9693024c3d5575.json (1060 bytes)
- .mokioclaw/context/repoAgent-32acaf55-71e/facts-9669a543052f41629979ae521f94403f.json (1060 bytes)
- .mokioclaw/context/repoAgent-32acaf55-71e/version-2.json (2188 bytes)
- .mokioclaw/context/repoAgent-32acaf55-71e/version-3.json (2189 bytes)
- .mokioclaw/context/repoAgent-da11fd79-439/current.json (50 bytes)
- .mokioclaw/context/repoAgent-da11fd79-439/facts-a21f83be8cb24fd6b75bb9b40bd99780.json (1060 bytes)
- .mokioclaw/context/repoAgent-da11fd79-439/facts-c471032d77e14974b8259b71d1f13fff.json (1060 bytes)
- .mokioclaw/context/repoAgent-da11fd79-439/version-12.json (2201 bytes)
- .mokioclaw/context/repoAgent-da11fd79-439/version-13.json (2192 bytes)
- .mokioclaw/diagnostics/model-stream-09c9a94a782242fd8ed716394b8332f5.log (3322 bytes)
- .mokioclaw/diagnostics/model-stream-0d8958f6486644c09529284f51d16a77.log (53 bytes)
- .mokioclaw/diagnostics/model-stream-16500cbb232f4740bfe17c77e5f0bb4b.log (2154 bytes)
- .mokioclaw/diagnostics/model-stream-220440781ad249ee8ec4344b683c497f.log (50 bytes)
- .mokioclaw/diagnostics/model-stream-2ac4b4507d8f4a46bdc50fc3462a7b08.log (50 bytes)
- .mokioclaw/diagnostics/model-stream-43b8595ba40a4eeaafc8c5853c79d7ad.log (81 bytes)
