# MokioClaw Todo

## Plan

Fix truncation (finish_reason length/max_tokens) handling so that ALL tool calls in a truncated response are voided and get placeholder 'not executed' results, only one re-decision is allowed, a second truncation stops safely, raw half-JSON is never executed via SDK-completed values, and cancellation/correction/budget checks are preserved. Scope: src/mokioclaw/** only.

## Todos

- [ ] **todo-1** `pending` Read truncation-relevant code in full: providers/generation.py, providers/openai_provider.py (retry wrapper), core/tool_loop.py, core/run_control.py, core/context_budget.py, core/protocol/__init__.py, tools/execution.py.
- [ ] **todo-2** `pending` Identify visible tests covering truncation/retry/cancellation/budget and record exact assertions.
- [ ] **todo-3** `pending` Implement: void ALL tool calls of a truncated response, append placeholder results for every call id, single re-decision, safe stop on second truncation, never execute SDK-completed raw JSON, preserve cancel/correction/budget checks.
- [ ] **todo-4** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and fix regressions.
- [ ] **todo-5** `pending` Verify acceptance criteria against implementation evidence and report honestly.

## Acceptance Criteria

- When a model response has finish_reason length/max_tokens, every tool call in that response (including ones that look complete) is discarded and never executed.
- A placeholder 'not executed / truncated' tool result is appended for each discarded tool call id so the conversation stays well-formed.
- Exactly one re-decision is permitted after a truncation; a second truncation stops safely (no infinite loop, no execution).
- Raw truncated/half JSON arguments are never executed using SDK auto-completed values.
- Cancellation, correction, and context-budget checks remain in effect on the truncation/retry path.
- Visible test suite passes: PYTHONPATH=src:. python -m pytest.
- Only files under src/mokioclaw/** are modified (plus allowed process notes).

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
- `PYTHONPATH=src:. python -m pytest tests/test_reliability_extensions.py tests/test_run_cancellation.py tests/test_context_governance.py tests/test_protocol_contracts.py -q`
