# MokioClaw Trace Timeline

- trace_id: trace-20261016-221644-3cc81a
- status: failed
- duration_ms: 863
- workspace: /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261016/trials/E02-baseline-3/workspace
- events: 15

## Summary

- nodes: {}
- tool_calls: 0
- failed_tool_calls: 0
- approvals: 0
- checkpoints: 2
- final_status: 

## Timeline

- 0ms run_start
- 527ms checkpoint_saved
- 527ms run_started
- 531ms memory_snapshot codeAgent
- 704ms plan_snapshot codeAgent
- 704ms instructions_loaded
- 750ms context_budget
- 751ms llm_stream_start codeAgent
- 755ms llm_request codeAgent
- 767ms llm_stream_end codeAgent
- 767ms llm_response codeAgent
- 767ms model_usage
- 768ms model_generation_stopped
- 863ms checkpoint_saved
- 863ms run_end
