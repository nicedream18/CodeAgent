# MokioClaw Todo

## Plan

Add optional literal (fixed-string) search to grep() and GrepTool. First re-run focused repo exploration (previous attempt hit tool budget), then implement in src/mokioclaw/**, then verify with visible tests and backend-parity checks.

## Todos

- [ ] **todo-1** `pending` Explore src/mokioclaw grep implementation: grep() signature, rg backend, Python fallback, ignore rules, head_limit, GrepTool schema/registry wiring, and existing tests.
- [ ] **todo-2** `pending` Implement fixed_strings support in grep() and GrepTool (rg --fixed-strings + Python re.escape), keeping regex default unchanged and rg/Python parity.
- [ ] **todo-3** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and verify literal matching, ignore_case, Chinese paths, ignore rules, head_limit, backend parity.

## Acceptance Criteria

- grep() accepts fixed_strings: bool=False and GrepTool exposes fixed_strings: bool=False in its parameter schema.
- With fixed_strings=True, regex metacharacters (., (, ), [, ]) match literally; with fixed_strings=False behavior is unchanged from before.
- fixed_strings composes correctly with ignore_case, glob, head_limit, ignore rules, and Chinese paths.
- rg backend and Python fallback return identical matches content and ordering for the same inputs.
- Visible tests pass via PYTHONPATH=src:. python -m pytest; no test/dependency/config files modified.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
- `PYTHONPATH=src:. python -c "from mokioclaw.tools.grep_tool import grep; import inspect; print(inspect.signature(grep))"`
