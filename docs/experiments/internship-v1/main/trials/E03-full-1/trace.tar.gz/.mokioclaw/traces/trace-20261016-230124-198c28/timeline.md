# MokioClaw Trace Timeline

- trace_id: trace-20261016-230124-198c28
- status: failed
- duration_ms: 5584
- workspace: /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261016/trials/E03-full-1/workspace
- events: 13

## Summary

- nodes: {}
- tool_calls: 0
- failed_tool_calls: 0
- approvals: 0
- checkpoints: 2
- final_status: 

## Timeline

- 0ms run_start
- 196ms checkpoint_saved
- 196ms run_started
- 387ms instructions_loaded
- 435ms context_budget
- 436ms llm_stream_start intent_router
- 436ms llm_request intent_router
- 5463ms llm_stream_end intent_router
- 5464ms llm_response intent_router
- 5468ms model_usage
- 5469ms model_generation_stopped
- 5584ms checkpoint_saved
- 5584ms run_end
