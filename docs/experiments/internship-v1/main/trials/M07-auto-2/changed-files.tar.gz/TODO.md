# MokioClaw Todo

## Plan

Add optional literal (fixed-string) search to grep() and GrepTool. First confirm the existing implementation shape via a narrow repo read, then implement fixed_strings in both rg and Python backends, then run visible tests and verify literal-mode parity.

## Todos

- [ ] **todo-1** `pending` Explore src/mokioclaw/tools/grep_tool.py and registry to confirm grep() signature, GrepTool schema, rg vs Python backend selection, ignore rules, head_limit semantics, and existing tests.
- [ ] **todo-2** `pending` Implement fixed_strings support in grep() and GrepTool: literal matching for rg (--fixed-strings) and Python backend (re.escape), preserving ignore_case, Chinese paths, ignore rules, head_limit, and identical match content/order across backends.
- [ ] **todo-3** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and confirm no regressions; verify literal-mode behavior manually.
- [ ] **todo-4** `pending` Verify final diff against acceptance criteria and report honestly.

## Acceptance Criteria

- grep() accepts fixed_strings: bool=False and GrepTool exposes fixed_strings: bool=False in its schema.
- With fixed_strings=True, regex metacharacters (., (, ), [, ]) are matched literally in both rg and Python backends.
- fixed_strings composes with ignore_case, Chinese paths, ignore rules, and head_limit/truncation.
- rg and Python backends return identical matches content and order for the same inputs.
- Default (fixed_strings=False) regex behavior is unchanged.
- Only files under src/mokioclaw/** are modified; tests/deps/config untouched.
- Visible test suite passes via PYTHONPATH=src:. python -m pytest.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
- `PYTHONPATH=src:. python -c "import asyncio; from mokioclaw.tools.grep_tool import grep; print(asyncio.run(grep(None, 'a.b', fixed_strings=True)))"`
