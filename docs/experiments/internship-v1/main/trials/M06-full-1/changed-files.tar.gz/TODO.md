# MokioClaw Todo

## Plan

Fix checkpoint rollback so it never overwrites user edits made after an Agent modification. Explore the checkpoint module and visible tests first (repoAgent budget is exhausted, so use codeAgent for exploration), then implement conflict detection via after_hash comparison, reverse-order restore for same-file edits, content-match-only deletion of new files, while preserving backups, locking, and per-item results.

## Todos

- [-] **todo-1** `in_progress` Explore src/mokioclaw checkpoint/rollback code and visible tests to ground the plan.
- [ ] **todo-2** `pending` Implement conflict-safe rollback: compare current file vs recorded after_hash before restore; on conflict leave file untouched.
- [ ] **todo-3** `pending` Implement reverse-order restore for consecutive same-file edits and content-match-only deletion of newly created files.
- [ ] **todo-4** `pending` Preserve backup integrity, locking, and per-item result reporting.
- [ ] **todo-5** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and verify.

## Acceptance Criteria

- Rollback compares current file content against recorded after_hash before restoring; on mismatch the file is left unchanged and reported as a conflict.
- Consecutive edits to the same file are restored in reverse order.
- Newly created files are deleted only when current content matches the recorded after_hash.
- Backup integrity, locking, and per-item result structures are preserved.
- Visible tests pass via PYTHONPATH=src:. python -m pytest; no tests/deps/test-config modified.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
