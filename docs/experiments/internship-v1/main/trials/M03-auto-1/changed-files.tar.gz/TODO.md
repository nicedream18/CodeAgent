# MokioClaw Todo

## Plan

Explore the mokioclaw codebase to find where project instructions (AGENTS.md) are loaded, where modification decisions are made/executed (tool loop, file tools, approval), then implement refresh+invalidation semantics and verify with visible tests.

## Todos

- [ ] **todo-1** `pending` Explore repo: locate AGENTS.md handling, instruction refresh, tool loop, file tools, approval/decision state, and relevant tests.
- [ ] **todo-2** `pending` Define exact semantics: first-encounter subdirectory AGENTS.md / rule change triggers context refresh + invalidation of pending (unexecuted) modification decisions.
- [ ] **todo-3** `pending` Implement in src/mokioclaw/** (refresh + invalidation, batched tool calls re-evaluate, reads not permanently blocked).
- [ ] **todo-4** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and fix regressions.
- [ ] **todo-5** `pending` Verify acceptance criteria and report honestly.

## Acceptance Criteria

- First encounter of a subdirectory AGENTS.md (or a rule change) triggers a context refresh.
- Pending/unexecuted modification decisions are invalidated on refresh; direct FileWrite/FileEdit and subsequent modifications in a batch do not reuse stale decisions.
- A new model request may read the rules and continue; read operations are not permanently blocked.
- Only src/mokioclaw/** is modified; tests/deps/config untouched.
- Visible tests pass via PYTHONPATH=src:. python -m pytest.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
