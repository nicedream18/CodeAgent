# MokioClaw Todo

## Plan

Recon the tool-loop/provider/runner truncation path, implement all-tool-call invalidation + backfill + single re-decision + safe stop, preserve cancellation/correction/budget checks, then run visible tests.

## Todos

- [ ] **todo-1** `pending` Recon: read core/tool_loop.py, providers/generation.py, providers/openai_provider.py, core/runner/*, core/agent.py to locate finish_reason handling, tool-call batch execution, retry/re-decision loop, cancellation/correction/budget checks.
- [ ] **todo-2** `pending` Recon: read visible tests (test_protocol_contracts.py, test_reliability_extensions.py, test_optimization_workflows.py, test_run_cancellation.py, test_context_governance.py) to infer expected truncation semantics.
- [ ] **todo-3** `pending` Implement truncation handling: detect finish_reason in {length, max_tokens}; invalidate ALL tool calls in that response; backfill synthetic not-executed results; never execute raw half-JSON via SDK-completed args.
- [ ] **todo-4** `pending` Implement single re-decision: allow exactly one retry after truncation; on second truncation stop safely without executing tools.
- [ ] **todo-5** `pending` Preserve cancellation, correction, and budget checks around the new truncation path.
- [ ] **todo-6** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and fix regressions.

## Acceptance Criteria

- A truncated response (finish_reason length/max_tokens) executes zero tool calls, including complete-looking ones.
- Every tool call in a truncated response gets a synthetic not-executed result so the conversation stays well-formed.
- Exactly one re-decision is permitted after truncation; a second truncation stops safely with no tool execution.
- Raw truncated JSON arguments are never executed using SDK auto-completed values.
- Cancellation, correction, and budget checks still function on the truncation path.
- Only files under src/mokioclaw/** are modified; tests/deps/config untouched.
- Visible test suite passes via PYTHONPATH=src:. python -m pytest.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
- `PYTHONPATH=src:. python -m pytest tests/test_protocol_contracts.py tests/test_reliability_extensions.py -q`
