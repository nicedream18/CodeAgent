# MokioClaw Recovery

- status: failed
- mode: light
- updated_at: 2026-10-16T14:35:30.435714+00:00
- latest_node: repoAgent
- next_node: 
- attempts: 0 / 3
- workspace: /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261016/trials/M02-auto-2/workspace
- resume: `uv run mokioclaw --resume /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261016/trials/M02-auto-2/workspace`

## Task
模型返回 length/max_tokens 时，该响应的所有工具调用（包括看似完整的调用）都必须作废并补齐未执行结果；只允许重新决策一次，再次截断安全停止。原始半截 JSON 不得用 SDK 补全值执行。保留取消、纠正和预算检查。
允许修改范围：src/mokioclaw/**

评测环境：只修改允许的源代码，禁止修改测试、依赖和测试配置。隐藏测试在外部验收。可以新增源代码辅助文件；TODO.md/NOTEPAD.md/HISTORY_SUMMARY.md 为允许的过程记录。Bash 使用离线 Docker 和预装依赖，不要联网或装包；使用 PYTHONPATH=src:. python -m pytest 运行可见测试。不使用网页、MCP、自定义 hooks、持久授权或后台执行。最后如实说明实现与验证，最后一行用 AGENT_CLAIM: solved 或 AGENT_CLAIM: unsolved 标明自评。

## Plan
Recon the tool-loop/provider/runner truncation path, implement all-tool-call invalidation + backfill + single re-decision + safe stop, preserve cancellation/correction/budget checks, then run visible tests.

## Todos
- [pending] Recon: read core/tool_loop.py, providers/generation.py, providers/openai_provider.py, core/runner/*, core/agent.py to locate finish_reason handling, tool-call batch execution, retry/re-decision loop, cancellation/correction/budget checks.
- [pending] Recon: read visible tests (test_protocol_contracts.py, test_reliability_extensions.py, test_optimization_workflows.py, test_run_cancellation.py, test_context_governance.py) to infer expected truncation semantics.
- [pending] Implement truncation handling: detect finish_reason in {length, max_tokens}; invalidate ALL tool calls in that response; backfill synthetic not-executed results; never execute raw half-JSON via SDK-completed args.
- [pending] Implement single re-decision: allow exactly one retry after truncation; on second truncation stop safely without executing tools.
- [pending] Preserve cancellation, correction, and budget checks around the new truncation path.
- [pending] Run visible tests with PYTHONPATH=src:. python -m pytest and fix regressions.

## Acceptance Criteria
- A truncated response (finish_reason length/max_tokens) executes zero tool calls, including complete-looking ones.
- Every tool call in a truncated response gets a synthetic not-executed result so the conversation stays well-formed.
- Exactly one re-decision is permitted after truncation; a second truncation stops safely with no tool execution.
- Raw truncated JSON arguments are never executed using SDK auto-completed values.
- Cancellation, correction, and budget checks still function on the truncation path.
- Only files under src/mokioclaw/** are modified; tests/deps/config untouched.
- Visible test suite passes via PYTHONPATH=src:. python -m pytest.

## Verification Commands
- PYTHONPATH=src:. python -m pytest -q
- PYTHONPATH=src:. python -m pytest tests/test_protocol_contracts.py tests/test_reliability_extensions.py -q

## Sources
- (none)

## Recent Summaries
- research: (none)
- codeAgent: (none)
- verifier: (none)
- last_error: (none)

## Recent Files
- .codegraph/.gitignore (173 bytes)
- .codegraph/daemon.pid (144 bytes)
- .gitignore (83 bytes)
- .mokioclaw/context/planner/current.json (50 bytes)
- .mokioclaw/context/planner/facts-0aa8b46b4da346b6a1f88dae9bdbe30a.json (1637 bytes)
- .mokioclaw/context/planner/facts-0fbcf04fc76d4ffbb5a8e7122dee25f7.json (1637 bytes)
- .mokioclaw/context/planner/facts-3ee874a985e34d33b84d388d755eb1e1.json (1637 bytes)
- .mokioclaw/context/planner/version-10.json (2751 bytes)
- .mokioclaw/context/planner/version-4.json (2605 bytes)
- .mokioclaw/context/planner/version-7.json (2748 bytes)
- .mokioclaw/context/repoAgent-/current.json (48 bytes)
- .mokioclaw/context/repoAgent-/facts-c84e1cead9464a4b828731e5d72c370b.json (1060 bytes)
- .mokioclaw/context/repoAgent-/version-1.json (2174 bytes)
- .mokioclaw/context/repoAgent-2b309b4f-2c1/current.json (48 bytes)
- .mokioclaw/context/repoAgent-2b309b4f-2c1/facts-55e648acb6604bf19a017c94da6d3b07.json (1060 bytes)
- .mokioclaw/context/repoAgent-2b309b4f-2c1/facts-9daab1d06703489da61fa064580ced12.json (1060 bytes)
- .mokioclaw/context/repoAgent-2b309b4f-2c1/version-8.json (2194 bytes)
- .mokioclaw/context/repoAgent-2b309b4f-2c1/version-9.json (2188 bytes)
- .mokioclaw/context/repoAgent-2c76022a-870/current.json (48 bytes)
- .mokioclaw/context/repoAgent-2c76022a-870/facts-04f9a60487e9447da62f9645ae5d2fa0.json (1060 bytes)
- .mokioclaw/context/repoAgent-2c76022a-870/facts-1572a5457e614f69a954525cdc0801ee.json (1060 bytes)
- .mokioclaw/context/repoAgent-2c76022a-870/version-2.json (2188 bytes)
- .mokioclaw/context/repoAgent-2c76022a-870/version-3.json (2189 bytes)
- .mokioclaw/context/repoAgent-b8cfd6fa-439/current.json (48 bytes)
- .mokioclaw/context/repoAgent-b8cfd6fa-439/facts-6c80953189904c16ba89dcb611e6a870.json (1060 bytes)
- .mokioclaw/context/repoAgent-b8cfd6fa-439/facts-97dc82e7aca94e10b2dc6eeba717a5df.json (1060 bytes)
- .mokioclaw/context/repoAgent-b8cfd6fa-439/version-5.json (2192 bytes)
- .mokioclaw/context/repoAgent-b8cfd6fa-439/version-6.json (2189 bytes)
- .mokioclaw/diagnostics/model-stream-047b582245694f63adb7c97c7c476331.log (3231 bytes)
- .mokioclaw/diagnostics/model-stream-04e7ecb3fd6c4f8faf19f33ec893c211.log (2461 bytes)
- .mokioclaw/diagnostics/model-stream-158dc834f8ba4801bf4a2ded1a7f6e40.log (140 bytes)
- .mokioclaw/diagnostics/model-stream-1b0c637dd258447fb0e9d86df7a32bc3.log (64 bytes)
- .mokioclaw/diagnostics/model-stream-1ead8b6414d64a5e861292f2b6090b23.log (75 bytes)
- .mokioclaw/diagnostics/model-stream-34c2a161fd2e43eea7193f4190c32f12.log (772 bytes)
- .mokioclaw/diagnostics/model-stream-3aa4f3aee4da4a71a55e76c377e64d51.log (53 bytes)
- .mokioclaw/diagnostics/model-stream-3d4317ad72364738820c7518a26ad6ff.log (52 bytes)
- .mokioclaw/diagnostics/model-stream-3f878775b94c481d99d67f8c60fe2b4b.log (33 bytes)
- .mokioclaw/diagnostics/model-stream-4649539b7d8b4cbe904537a4ff968243.log (65 bytes)
- .mokioclaw/diagnostics/model-stream-551d78c8aa7f4053b3e9572510805572.log (89 bytes)
- .mokioclaw/diagnostics/model-stream-5b995244500f47309265f2ecc6f58bdf.log (1281 bytes)
