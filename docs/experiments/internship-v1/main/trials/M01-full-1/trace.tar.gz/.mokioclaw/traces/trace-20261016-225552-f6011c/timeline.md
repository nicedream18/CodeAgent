# MokioClaw Trace Timeline

- trace_id: trace-20261016-225552-f6011c
- status: failed
- duration_ms: 781
- workspace: /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261016/trials/M01-full-1/workspace
- events: 13

## Summary

- nodes: {}
- tool_calls: 0
- failed_tool_calls: 0
- approvals: 0
- checkpoints: 2
- final_status: 

## Timeline

- 0ms run_start
- 295ms checkpoint_saved
- 295ms run_started
- 578ms instructions_loaded
- 660ms context_budget
- 661ms llm_stream_start intent_router
- 661ms llm_request intent_router
- 690ms llm_stream_end intent_router
- 690ms llm_response intent_router
- 692ms model_usage
- 693ms model_generation_stopped
- 781ms checkpoint_saved
- 781ms run_end
