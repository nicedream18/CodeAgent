# MokioClaw Todo

## Plan

Add optional literal (fixed-strings) search to grep and GrepTool: new fixed_strings kwarg/schema field, rg -F on the ripgrep backend, literal matching on the Python fallback, preserving ignore_case, glob, ignore rules, head_limit and default regex behavior.

## Todos

- [ ] **todo-1** `pending` Recon: read src/mokioclaw/tools/grep_tool.py fully (grep signature, rg invocation, Python fallback, ignore rules, glob, head_limit/truncated), locate GrepTool schema and registry wiring, and find grep-related visible tests.
- [ ] **todo-2** `pending` Implement fixed_strings: add kwarg to grep(), rg -F flag, Python re.escape/str.find literal matching, preserve ignore_case/glob/ignore rules/head_limit, keep default regex behavior unchanged.
- [ ] **todo-3** `pending` Expose fixed_strings: bool=False on GrepTool schema/parameter definition.
- [ ] **todo-4** `pending` Verify: run PYTHONPATH=src:. python -m pytest, plus targeted checks that rg and Python backends agree on matches content/order in fixed_strings mode and that default regex behavior is unchanged.

## Acceptance Criteria

- grep() accepts fixed_strings: bool=False and GrepTool schema exposes fixed_strings: bool=False.
- With fixed_strings=True, regex metacharacters (., (), [], etc.) match literally in both rg and Python backends.
- fixed_strings=True composes correctly with ignore_case, Chinese paths, ignore rules, and head_limit/truncated semantics.
- rg and Python backends produce identical matches content and order in fixed_strings mode.
- Default (fixed_strings=False) regex behavior is unchanged.
- Only files under src/mokioclaw/** are modified; tests/deps/config untouched.
- PYTHONPATH=src:. python -m pytest passes.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest`
- `PYTHONPATH=src:. python -c "from mokioclaw.tools.grep_tool import grep; import inspect; print(inspect.signature(grep))"`
