# MokioClaw Todo

## Plan

Add a `mode` parameter to `flask.Config.from_file()` so callers can open files in binary mode (enabling tomllib.load), keeping text mode as the default for backward compatibility.

## Todos

- [ ] **todo-1** `pending` Confirm exact current signature/body of Config.from_file in src/flask/config.py and existing tests.
- [ ] **todo-2** `pending` Add mode parameter to Config.from_file (default text mode), update docstring with versionadded note.
- [ ] **todo-3** `pending` Run visible tests (tests/test_config.py) and a TOML smoke check to verify.

## Acceptance Criteria

- Config.from_file accepts a mode parameter defaulting to text mode, preserving backward compatibility.
- Calling from_file with mode="b" opens the file in binary mode so tomllib.load works.
- Missing-file behavior and error message unchanged (IOError with quoted filename; silent=True returns falsy).
- Visible tests pass via PYTHONPATH=src:. python -m pytest.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest tests/test_config.py -q`
- `PYTHONPATH=src:. python -c "import tomllib, tempfile, os; from flask import Flask; d=tempfile.mkdtemp(); open(os.path.join(d,'config.toml'),'wb').write(b'FOO = 1\n'); app=Flask(__name__); app.config.root_path=d; app.config.from_file('config.toml', tomllib.load, mode='b'); print(app.config['FOO'])"`
