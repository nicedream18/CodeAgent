# MokioClaw Trace Timeline

- trace_id: trace-20261016-221647-156e9e
- status: failed
- duration_ms: 391
- workspace: /Users/nicedream/.cache/mokioclaw/eval/internship-v1/experiments/internship-v1-20261016/trials/M03-full-1/workspace
- events: 13

## Summary

- nodes: {}
- tool_calls: 0
- failed_tool_calls: 0
- approvals: 0
- checkpoints: 2
- final_status: 

## Timeline

- 0ms run_start
- 143ms checkpoint_saved
- 143ms run_started
- 263ms instructions_loaded
- 309ms context_budget
- 310ms llm_stream_start intent_router
- 310ms llm_request intent_router
- 326ms llm_stream_end intent_router
- 326ms llm_response intent_router
- 327ms model_usage
- 327ms model_generation_stopped
- 391ms checkpoint_saved
- 391ms run_end
