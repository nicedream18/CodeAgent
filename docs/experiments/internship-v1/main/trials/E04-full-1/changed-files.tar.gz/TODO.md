# MokioClaw Todo

## Plan

Confirm exact implementation of iter_content/text/stream_decode_response_unicode, then apply a minimal fix so decode_unicode=True decodes using resolved encoding (with apparent_encoding/JSON fallback), preserving bytes when decode_unicode=False.

## Todos

- [ ] **todo-1** `pending` Explore requests/ source: read iter_content, text, content, stream_decode_response_unicode, guess_json_utf, and relevant tests.
- [ ] **todo-2** `pending` Determine root cause: why iter_content(decode_unicode=True) yields bytes for application/json while r.text yields unicode.
- [ ] **todo-3** `pending` Implement minimal fix in requests/** so decode_unicode=True yields str when encoding is resolvable (incl. JSON/apparent_encoding fallback), preserving bytes behavior when decode_unicode=False.
- [ ] **todo-4** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and confirm no regressions.
- [ ] **todo-5** `pending` Verify fix against acceptance criteria and report honestly.

## Acceptance Criteria

- iter_content(chunk_size, decode_unicode=True) yields str (unicode) for an application/json response where r.text is unicode, including when r.encoding is None but apparent_encoding/guess_json_utf resolves an encoding.
- iter_content(decode_unicode=False) continues to yield bytes unchanged.
- Existing visible tests pass under PYTHONPATH=src:. python -m pytest.
- Only files under requests/** are modified; no tests/deps/config changed.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
- `PYTHONPATH=src:. python -c "import requests, requests.utils as u; print(u.stream_decode_response_unicode.__doc__)"`
