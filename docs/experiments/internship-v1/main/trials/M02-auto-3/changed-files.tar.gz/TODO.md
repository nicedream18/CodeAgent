# MokioClaw Todo

## Plan

Read the truncation-handling code paths, then implement full invalidation of truncated-response tool calls with single re-decision and safe stop, preserving cancellation/correction/budget checks, and verify with the visible test suite.

## Todos

- [ ] **todo-1** `pending` Read full bodies of providers/generation.py, providers/openai_provider.py, core/tool_loop.py, and relevant tests to understand current truncation handling.
- [ ] **todo-2** `pending` Implement: on length/max_tokens, invalidate ALL tool calls in that response (even seemingly complete), append not-executed results for every call id, allow exactly one re-decision, safe stop on second truncation, never execute raw half-JSON via SDK-completed values.
- [ ] **todo-3** `pending` Preserve cancellation, correction, and budget checks in the retry path.
- [ ] **todo-4** `pending` Run visible tests with PYTHONPATH=src:. python -m pytest and confirm no regressions.

## Acceptance Criteria

- On finish_reason length/max_tokens, every tool call in that response is discarded (including complete-looking ones) and a not-executed tool result is appended for each discarded call id.
- Exactly one re-decision is permitted; a second truncation stops safely without further retries.
- Raw truncated/half-JSON tool arguments are never executed using SDK-completed values.
- Cancellation, correction, and budget checks remain enforced in the retry path.
- Visible test suite passes with PYTHONPATH=src:. python -m pytest.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q`
