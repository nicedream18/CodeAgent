# MokioClaw Todo

## Plan

Add a `mode` parameter to flask.Config.from_file() so binary readers like tomllib.load work, keeping default text mode for backward compatibility.

## Todos

- [-] **todo-1** `in_progress` Add `mode: str = "r"` parameter to Config.from_file in src/flask/config.py, pass it to open(), update docstring with tomllib example and versionchanged note.
- [ ] **todo-2** `pending` Run visible tests (tests/test_config.py) with PYTHONPATH=src:. python -m pytest to confirm no regressions.
- [ ] **todo-3** `pending` Verify binary-mode TOML loading works end-to-end and default text mode unchanged.

## Acceptance Criteria

- Config.from_file accepts a `mode` parameter defaulting to "r" and passes it to open().
- Calling from_file(path, tomllib.load, mode="b") loads TOML successfully.
- Default behavior (text mode) unchanged; existing tests pass.
- Only src/flask/** modified.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest tests/test_config.py -q`
- `PYTHONPATH=src:. python -c "import tomllib, tempfile, os; from flask import Flask; d=tempfile.mkdtemp(); open(os.path.join(d,'c.toml'),'w').write('FOO=1\n'); a=Flask(__name__); a.config.root_path=d; a.config.from_file('c.toml', tomllib.load, mode='b'); print(a.config['FOO'])"`
