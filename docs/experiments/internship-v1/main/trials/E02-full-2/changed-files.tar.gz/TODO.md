# MokioClaw Todo

## Plan

Add a `mode` parameter (default \"r\") to flask.Config.from_file(), forward it to open(), document it, then verify with visible tests and a tomllib binary-mode smoke test.

## Todos

- [-] **todo-1** `in_progress` Add `mode: str = "r"` parameter to Config.from_file() in src/flask/config.py, pass it to open(), and document it.
- [ ] **todo-2** `pending` Run visible tests (PYTHONPATH=src:. python -m pytest tests/test_config.py) to confirm no regressions.
- [ ] **todo-3** `pending` Verify binary-mode loading works (tomllib.load with mode="b") and default text mode unchanged.

## Acceptance Criteria

- Config.from_file() accepts a `mode` parameter defaulting to "r" and forwards it to open().
- Existing behavior (text mode, silent, error handling) is unchanged.
- Binary loaders such as tomllib.load work via mode="b"/"rb".
- Visible tests pass with PYTHONPATH=src:. python -m pytest.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest tests/test_config.py -q`
- `PYTHONPATH=src:. python -c "import tomllib, tempfile, os; from flask import Flask; d=tempfile.mkdtemp(); open(os.path.join(d,'c.toml'),'wb').write(b'X = 1'); a=Flask(__name__); a.config.root_path=d; print(a.config.from_file('c.toml', tomllib.load, mode='b'), a.config['X'])"`
