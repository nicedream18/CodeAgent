# MokioClaw Todo

## Plan

Implementation done in grep_tool.py and registry.py; remaining work is verification and any defect fix.

## Todos

- [ ] **todo-1** `pending` Add fixed_strings=False to grep() in src/mokioclaw/tools/grep_tool.py (done: re.escape matcher + rg --fixed-strings).
- [ ] **todo-2** `pending` Expose fixed_strings: bool=False on GrepTool in src/mokioclaw/tools/registry.py and forward it to grep() (done).
- [ ] **todo-3** `pending` Verify: run visible pytest and ad-hoc checks for literal metacharacters, ignore_case, Chinese paths, head_limit, and rg/python parity; fix any defect found.

## Acceptance Criteria

- grep() accepts fixed_strings=False and GrepTool exposes fixed_strings: bool=False
- fixed_strings=True matches '.', '(', '[', etc. literally in both rg and Python backends
- ignore_case, Chinese paths, ignore rules, head_limit still work with fixed_strings
- rg and Python backends produce identical matches content and order
- Default regex behavior unchanged; visible tests pass

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
