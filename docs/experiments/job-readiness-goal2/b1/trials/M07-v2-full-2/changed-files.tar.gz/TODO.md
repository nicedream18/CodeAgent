# MokioClaw Todo

## Plan

Extend grep tool with optional literal (fixed-string) search across both rg and Python backends, exposed via GrepTool.

## Todos

- [ ] **todo-1** `pending` Add fixed_strings=False to grep() in src/mokioclaw/tools/grep_tool.py (Python backend re.escape + rg -F).
- [ ] **todo-2** `pending` Expose fixed_strings: bool=False on GrepTool in src/mokioclaw/tools/registry.py.
- [ ] **todo-3** `pending` Verify behavior: run visible pytest plus an ad-hoc script (import RuntimeState from mokioclaw.core.state) checking literal metacharacters, ignore_case+fixed_strings, head_limit, ignore rules, Chinese paths, rg vs Python backend parity, and that GrepTool schema exposes fixed_strings.

## Acceptance Criteria

- grep() accepts fixed_strings=False and GrepTool schema exposes fixed_strings: bool=False
- With fixed_strings=True, '.', '(', '[', etc. match literally; ignore_case still applies
- rg and Python backends produce identical matches content and order
- Default regex behavior unchanged; visible tests pass

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
