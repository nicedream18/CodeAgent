# MokioClaw Todo

## Plan

Repository evidence already locates the trace command (src/mokioclaw/cli/app.py:434-470) and TraceReader (src/mokioclaw/core/transport_trace.py:114). Delegate a single implementation-and-check task to codeAgent, then verify.

## Todos

- [-] **todo-1** `in_progress` Add --since ISO8601 (Z/UTC offset required) option to trace command in src/mokioclaw/cli/app.py: parse with datetime.fromisoformat (Z->+00:00), reject invalid/naive with typer.BadParameter before any reader/run starts; filter records by UTC comparison >= since (boundary inclusive), skipping missing/invalid/naive timestamps only when --since given; keep behavior unchanged without --since; ensure --follow composes with filters.
- [ ] **todo-2** `pending` Run visible check PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py plus ad-hoc CLI checks for --since boundary, invalid/naive rejection, legacy records, and --follow combination.

## Acceptance Criteria

- trace --since accepts ISO8601 with Z or UTC offset and compares in UTC, including the boundary instant
- Invalid or timezone-naive --since yields a CLI usage error (exit code 2) and starts no run
- Records with missing/invalid timestamps are skipped only when --since is provided; output unchanged without --since
- follow composes with --since and other filters
- Visible test suite passes and only src/mokioclaw/** is modified

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
