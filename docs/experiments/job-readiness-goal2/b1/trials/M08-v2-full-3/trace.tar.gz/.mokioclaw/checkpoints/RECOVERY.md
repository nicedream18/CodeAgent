# MokioClaw Recovery

- status: failed
- mode: light
- updated_at: 2026-10-17T07:33:15.954530+00:00
- latest_node: verifier
- next_node: verifier
- attempts: 0 / 3
- workspace: /Users/nicedream/.cache/mokioclaw/eval/job-readiness-v1/experiments/job-readiness-goal2-20261017-b1/trials/M08-v2-full-3/workspace
- resume: `uv run mokioclaw --resume /Users/nicedream/.cache/mokioclaw/eval/job-readiness-v1/experiments/job-readiness-goal2-20261017-b1/trials/M08-v2-full-3/workspace`

## Task
为 mokioclaw trace 增加 --since ISO8601 时间过滤，要求带 Z 或 UTC 偏移、包含边界时刻并按 UTC 比较。不合法或没有时区的参数返回 CLI 用法错误，不能启动任何运行。旧记录无时间戳或时间戳无效时，在有 --since 条件下跳过；无该参数时仍保持原输出。--follow 与其他筛选可组合。

本工作区是固定工程任务切片，不是原仓库的完整测试环境。可见基础检查命令：PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py。该检查验证基础读写/搜索、CLI 帮助和本地 stdio fixture；目标边界请自行验证。隐藏目标及固定回归由外部评分器在全新离线容器重建。只修改 src/mokioclaw 下实现，保留测试和示例 fixture。
允许修改范围：src/mokioclaw/**

评测环境：只修改允许的源代码，禁止修改测试、依赖和测试配置。隐藏测试在外部验收。可以新增源代码辅助文件；TODO.md/NOTEPAD.md/HISTORY_SUMMARY.md 为允许的过程记录。Bash 使用离线 Docker 和预装依赖，不要联网或装包；使用 PYTHONPATH=src:. python -m pytest 运行可见测试。不使用网页、MCP、自定义 hooks、持久授权或后台执行。最后如实说明实现与验证，最后一行用 AGENT_CLAIM: solved 或 AGENT_CLAIM: unsolved 标明自评。

## Plan
Repository evidence already locates the trace command (src/mokioclaw/cli/app.py:434-470) and TraceReader (src/mokioclaw/core/transport_trace.py:114). Delegate a single implementation-and-check task to codeAgent, then verify.

## Todos
- [in_progress] Add --since ISO8601 (Z/UTC offset required) option to trace command in src/mokioclaw/cli/app.py: parse with datetime.fromisoformat (Z->+00:00), reject invalid/naive with typer.BadParameter before any reader/run starts; filter records by UTC comparison >= since (boundary inclusive), skipping missing/invalid/naive timestamps only when --since given; keep behavior unchanged without --since; ensure --follow composes with filters.
- [pending] Run visible check PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py plus ad-hoc CLI checks for --since boundary, invalid/naive rejection, legacy records, and --follow combination.

## Acceptance Criteria
- trace --since accepts ISO8601 with Z or UTC offset and compares in UTC, including the boundary instant
- Invalid or timezone-naive --since yields a CLI usage error (exit code 2) and starts no run
- Records with missing/invalid timestamps are skipped only when --since is provided; output unchanged without --since
- follow composes with --since and other filters
- Visible test suite passes and only src/mokioclaw/** is modified

## Verification Commands
- PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py

## Sources
- (none)

## Recent Summaries
- research: (none)
- codeAgent: ## Completed changes

**`src/mokioclaw/cli/app.py`**
- Line 4: added `from datetime import datetime` (module-level import).
- Lines ~434-472: added three small module-level helpers:
  - `_parse_iso_utc(value)` — strips whitespace, replaces trailing `Z`/`z` with `+00:00`, calls `datetime.fromisoformat`, and raises `ValueError` if parsing fails or `tzinfo`/`utcoffset()` is missing (naive).
  - `_parse_since(value)` — returns `None` for `None`; otherwise returns the parsed datetime converted to UTC, or raises `typer.BadParameter(..., param_hint="--since")` on invalid/naive input.
  - `_record_at_or_after(record, since_utc)` — reads `record["timestamp"]` (the key the writer emits in `transport_trace.py`), returns `False` for missing/non-string/empty/unparsable/naive values, otherwise compares `parsed.astimezone(UTC) >= since_utc` (boundary inclusive).
- `trace_command`: added `since: str | None = None` parameter; `since_utc = _parse_since(since)` is called **before** `TraceReader()` is constructed and before any run/daemon interaction. The filter `if since_utc is not None and not _record_at_or_after(record, since_utc): continue` is placed alongside the existing `run_id`/`layer`/`direction` filters inside the read loop, so it applies to both the initial dump and `--follow` iterations. With `since is None`, no filtering occurs (output unchanged).

No other files were modified.

## Checks run and observed outcomes

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py` → **3 passed**.
- `python -m mokioclaw.cli.app trace --help | grep -i since` → **no output** (g...
- verifier: (none)
- last_error: (none)

## Recent Files
- .codegraph/.gitignore (173 bytes)
- .codegraph/daemon.pid (144 bytes)
- .gitignore (83 bytes)
- .mokioclaw/changes/job-readiness-goal2-20261017-b1-M08-v2-full-3/7056b765661d482d8643505a02244c0c.bin (19391 bytes)
- .mokioclaw/changes/job-readiness-goal2-20261017-b1-M08-v2-full-3/f0a9e1c89e734c7c949414d6d60b3d32.bin (17801 bytes)
- .mokioclaw/changes/job-readiness-goal2-20261017-b1-M08-v2-full-3/manifest.json (894 bytes)
- .mokioclaw/diagnostics/bash-stderr-0795233a0a1b46758ab3980a298c3ee0.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-08c6a180b3b84ee7adba05fe29ebbb18.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-0ac59b24df82432f8cb9dcecfa1ee747.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-3f350422b0804262ae14fe43ad94b3d4.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-7bac7dc08b0a47968d0388041e4f2ef8.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-9760d21596a14da981f245d9fa5204fc.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-bc3cef31f6834c7da5e385cff0984b50.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-bf9e8fd9994a4a17a36438898f93f13f.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-dda81d84f88e4e13bf62a4ff00be17dc.log (0 bytes)
- .mokioclaw/diagnostics/bash-stdout-04e9ff1cb47748899fde26ed701d8d46.log (172 bytes)
- .mokioclaw/diagnostics/bash-stdout-1203897517c148adb4dc2dd37ee86301.log (103 bytes)
- .mokioclaw/diagnostics/bash-stdout-46cd180d5ebe4894a67fc0e73674e919.log (4566 bytes)
- .mokioclaw/diagnostics/bash-stdout-564adbd0dc124195a39210975d8f0f74.log (276 bytes)
- .mokioclaw/diagnostics/bash-stdout-57a9a1c402b34dd18f7090c555dcb5a2.log (3079 bytes)
- .mokioclaw/diagnostics/bash-stdout-7db4cc9713d54353a1608d4f1129927e.log (7 bytes)
- .mokioclaw/diagnostics/bash-stdout-a8d3dc131c2648fab34761c70b38fcf6.log (79 bytes)
- .mokioclaw/diagnostics/bash-stdout-ad2fedba44b3484e871d635064a6a3ec.log (1683 bytes)
- .mokioclaw/diagnostics/bash-stdout-f1d4d5f1551444eea310ea58acc7e74a.log (5156 bytes)
- .mokioclaw/diagnostics/model-stream-092aaad1aabb4adfa04112484d0f69f2.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-32f4db602aed44a7a8c77e780b6ab274.log (118 bytes)
- .mokioclaw/diagnostics/model-stream-3301173460364ca398e0b7f3d9f39614.log (105 bytes)
- .mokioclaw/diagnostics/model-stream-419161f370ac41469f9180036961e42f.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-44be5b1478bd494e9fb42837663f90f1.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-46b689c76b9448b58a432643306b5a3d.log (101 bytes)
- .mokioclaw/diagnostics/model-stream-4b2a9812472149cea3a6cc50f96f8d89.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-5003d4a467444db58e97116e6a485803.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-569284a79cbf435884cf84a9ee478066.log (2777 bytes)
- .mokioclaw/diagnostics/model-stream-7d275a76319d4840901f3b6876167a0d.log (54 bytes)
- .mokioclaw/diagnostics/model-stream-a1bbe44ddbd6410ca866c97a35c2e0c1.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-b089a31453f343b980486eb6a6823780.log (25 bytes)
- .mokioclaw/diagnostics/model-stream-ec5875a80c344338a69692605a20e05c.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-f6933dc9ee27455d8639c102d42a0352.log (92 bytes)
- .mokioclaw/inbox/local-063f360e2b2643b789c1ebe89fb41f46.json (2 bytes)
- .mokioclaw/memory/repo-dddef867da79d2668cbc8bf6.json (6089 bytes)
