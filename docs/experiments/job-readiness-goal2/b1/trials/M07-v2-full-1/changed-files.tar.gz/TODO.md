# MokioClaw Todo

## Plan

Implementation done (grep_tool.py + registry.py). Remaining: run verification only.

## Todos

- [x] **todo-1** `completed` Add fixed_strings=False to grep() in src/mokioclaw/tools/grep_tool.py: escape pattern for Python backend (re.escape + IGNORECASE when ignore_case) and pass --fixed-strings to rg backend; keep default regex behavior unchanged.
- [x] **todo-2** `completed` Expose fixed_strings: bool=False on GrepTool in src/mokioclaw/tools/registry.py (lambda signature + forward to grep, update description).
- [-] **todo-3** `in_progress` Verify: run visible pytest, plus ad-hoc checks for literal metachars, ignore_case, Chinese paths, ignore rules, head_limit, and rg/python matches parity.

## Acceptance Criteria

- grep(state, pattern, path='.', glob=None, head_limit=50, ignore_case=False, fixed_strings=False) accepts fixed_strings
- GrepTool tool schema exposes fixed_strings: bool = False and forwards it
- With fixed_strings=True, '.', '(', '[', '*' etc. match literally; no re.error
- fixed_strings composes with ignore_case, Chinese paths, ignore rules, head_limit
- rg and Python backends produce identical matches content and order
- Default (fixed_strings=False) regex behavior unchanged; visible tests pass

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
