# MokioClaw Todo

## Plan

Enable the disabled truncation guard in providers/generation.py so length/max_tokens responses invalidate all tool calls, then confirm the provider retry/not_executed and lifecycle stop paths behave per spec.

## Todos

- [x] **todo-1** `completed` Enable truncation guard in providers/generation.py: finish reason length/max_tokens -> ModelGenerationStopped('model_output_truncated') before any tool-arg validation/execution; ensure SDK-completed partial args are never executable.
- [-] **todo-2** `in_progress` Verify openai_provider.invoke_streaming: single re-decision, all declared calls (incl. complete-looking) invalidated with not_executed results, second truncation re-raises; lifecycle surfaces stop_reason without executing pending calls.
- [ ] **todo-3** `pending` Run visible tests plus targeted truncation checks.

## Acceptance Criteria

- Truncated (length/max_tokens) responses raise ModelGenerationStopped('model_output_truncated') before any tool execution, regardless of whether tool calls look complete.
- All declared tool calls from a truncated response get not_executed tool results (no execution, no SDK-completed partial args used).
- Exactly one re-decision is allowed; a second truncation stops safely with stop_reason surfaced.
- Cancellation, correction and budget checks remain intact.
- PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py passes.

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
