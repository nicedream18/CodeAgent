# MokioClaw Recovery

- status: failed
- mode: light
- updated_at: 2026-10-17T07:20:21.214142+00:00
- latest_node: verifier
- next_node: verifier
- attempts: 0 / 3
- workspace: /Users/nicedream/.cache/mokioclaw/eval/job-readiness-v1/experiments/job-readiness-goal2-20261017-b1/trials/M02-v2-full-3/workspace
- resume: `uv run mokioclaw --resume /Users/nicedream/.cache/mokioclaw/eval/job-readiness-v1/experiments/job-readiness-goal2-20261017-b1/trials/M02-v2-full-3/workspace`

## Task
模型返回 length/max_tokens 时，该响应的所有工具调用（包括看似完整的调用）都必须作废并补齐未执行结果；只允许重新决策一次，再次截断安全停止。原始半截 JSON 不得用 SDK 补全值执行。保留取消、纠正和预算检查。

本工作区是固定工程任务切片，不是原仓库的完整测试环境。可见基础检查命令：PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py。该检查验证基础读写/搜索、CLI 帮助和本地 stdio fixture；目标边界请自行验证。隐藏目标及固定回归由外部评分器在全新离线容器重建。只修改 src/mokioclaw 下实现，保留测试和示例 fixture。
允许修改范围：src/mokioclaw/**

评测环境：只修改允许的源代码，禁止修改测试、依赖和测试配置。隐藏测试在外部验收。可以新增源代码辅助文件；TODO.md/NOTEPAD.md/HISTORY_SUMMARY.md 为允许的过程记录。Bash 使用离线 Docker 和预装依赖，不要联网或装包；使用 PYTHONPATH=src:. python -m pytest 运行可见测试。不使用网页、MCP、自定义 hooks、持久授权或后台执行。最后如实说明实现与验证，最后一行用 AGENT_CLAIM: solved 或 AGENT_CLAIM: unsolved 标明自评。

## Plan
Enable the disabled truncation guard in providers/generation.py so length/max_tokens responses invalidate all tool calls, then confirm the provider retry/not_executed and lifecycle stop paths behave per spec.

## Todos
- [completed] Enable truncation guard in providers/generation.py: finish reason length/max_tokens -> ModelGenerationStopped('model_output_truncated') before any tool-arg validation/execution; ensure SDK-completed partial args are never executable.
- [in_progress] Verify openai_provider.invoke_streaming: single re-decision, all declared calls (incl. complete-looking) invalidated with not_executed results, second truncation re-raises; lifecycle surfaces stop_reason without executing pending calls.
- [pending] Run visible tests plus targeted truncation checks.

## Acceptance Criteria
- Truncated (length/max_tokens) responses raise ModelGenerationStopped('model_output_truncated') before any tool execution, regardless of whether tool calls look complete.
- All declared tool calls from a truncated response get not_executed tool results (no execution, no SDK-completed partial args used).
- Exactly one re-decision is allowed; a second truncation stops safely with stop_reason surfaced.
- Cancellation, correction and budget checks remain intact.
- PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py passes.

## Verification Commands
- PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py

## Sources
- (none)

## Recent Summaries
- research: (none)
- codeAgent: ## Completed changes

**`src/mokioclaw/providers/generation.py` (lines 66–79)** — replaced the disabled `if False:` truncation guard in `validate_generation()` with a real check:

```python
result = outcome(message)
if result.reason == "output_limit":
    raise ModelGenerationStopped("model_output_truncated", message)
```

- `outcome()` already maps `finish_reason`/`stop_reason` of `length`/`max_tokens` → `output_limit`, so both raw reasons are covered.
- The check runs **before** any tool-argument validation (`tool_call_chunks`, `additional_kwargs.tool_calls`, `invalid_tool_calls`) and before the provider returns the message, so no declared call — including one whose args look complete — is ever treated as executable, and SDK-completed partial JSON is never used as executable args.
- `blocked`/`unknown` handling and the invalid-args path are unchanged.

No changes were needed in `openai_provider.py` or `lifecycle.py` (verified by reading the source):
- `invoke_streaming` (lines 88–122): `for attempt in range(2)` → exactly one re-decision. On the first `model_output_truncated` it appends a synthetic `AIMessage` whose tool_calls use **empty args** for every `declared_calls(exc.message)` entry, a `"Not executed: output was truncated…"` `ToolMessage` per call, and a corrective `HumanMessage`; on the second truncation (`attempt` truthy) it re-raises.
- `_invoke_once` (lines 294–311): on `ModelGenerationStopped` it emits a `tool_result` event with `status: "not_executed"` and `error_type: exc.reason` for every `declared_calls(assembled)` — complete-looking calls included. Can...
- verifier: (none)
- last_error: (none)

## Recent Files
- .codegraph/.gitignore (173 bytes)
- .codegraph/daemon.pid (144 bytes)
- .gitignore (83 bytes)
- .mokioclaw/changes/job-readiness-goal2-20261017-b1-M02-v2-full-3/992515cb54494578bbc87e44f8118647.bin (3590 bytes)
- .mokioclaw/changes/job-readiness-goal2-20261017-b1-M02-v2-full-3/manifest.json (519 bytes)
- .mokioclaw/diagnostics/bash-stderr-1544f62a38544c28bc804d51aa324c06.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-2d5e69ad6b4d451d8a8d1d6f24edd427.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-3f9c72c3ed914b41a8cc43d988444952.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-45c6ca9820e44c3091baf2ae84c24e2c.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-47904ba99cdd4804ae0832e6175fa9b8.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-5de2c7baf7ad4db5b5115b98b8a32ce6.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-8ddbc3b2fc1a40d49e5ecf5df0b66d54.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-dc9e36f0b5334ee9926dc9abeed2527d.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-f336c09d957c48c183ed64c39e6e90c7.log (0 bytes)
- .mokioclaw/diagnostics/bash-stdout-111b53eb089b4eb1bbf3da94c4c58ed4.log (247 bytes)
- .mokioclaw/diagnostics/bash-stdout-178b80db62d24e03af0a067a9a3a27de.log (98 bytes)
- .mokioclaw/diagnostics/bash-stdout-1d2b45f584f540419146cd86148d2ed1.log (595 bytes)
- .mokioclaw/diagnostics/bash-stdout-30d82088120d410688d08fc79eac84d5.log (5632 bytes)
- .mokioclaw/diagnostics/bash-stdout-3c036d67e90243758550e72d00e93bb4.log (4188 bytes)
- .mokioclaw/diagnostics/bash-stdout-76daabc26b934d13894dc3fdf5a4948a.log (350 bytes)
- .mokioclaw/diagnostics/bash-stdout-a912453af08f4581906a6c57f713367d.log (10939 bytes)
- .mokioclaw/diagnostics/bash-stdout-aa25d27d46a3495ca45715a9e55351a7.log (6870 bytes)
- .mokioclaw/diagnostics/bash-stdout-fdc589502f4248a0924206f3b0451123.log (317 bytes)
- .mokioclaw/diagnostics/model-stream-0ad34c941d934214b1216e550f29a8a9.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-0b3a33da0ef6472eaa14cef242f60502.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-0e28e48040014e788d602f74746ec5cb.log (48 bytes)
- .mokioclaw/diagnostics/model-stream-1c87db24985448c1ac92d630029e07eb.log (2824 bytes)
- .mokioclaw/diagnostics/model-stream-582d074fe6a24456990cc4f0db459ddd.log (59 bytes)
- .mokioclaw/diagnostics/model-stream-803e4293a1d74451a3a84b6bcbca379b.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-91477ccf43244dc49cea55240509a87b.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-9c921d66dd5547a790d5f5cc1b4e61c1.log (45 bytes)
- .mokioclaw/diagnostics/model-stream-b050aa8edfd74b1b90648563d56396a4.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-c4731c706c3a457db8c3c0a223787f32.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-d0166f0ab68b4739aaae330cfeeee36a.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-e01c4deb9ba64ac6b0eea9c6d0b2b9be.log (24 bytes)
- .mokioclaw/diagnostics/model-stream-ed07470ea0de4fa4bfa56fca654b1fe2.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-fc615bc4eaf84354a3706a370a798f0b.log (0 bytes)
- .mokioclaw/inbox/local-6caa9fe04a8a42fbab3d61e7c466d1a8.json (2 bytes)
- .mokioclaw/memory/repo-2a9478a0b928cd15dc0a2b33.json (4805 bytes)
- .mokioclaw/session/writer.lock (62 bytes)
