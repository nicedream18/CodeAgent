# MokioClaw Todo

## Plan

Implementation is in place; remaining work is verification and any small fix it reveals.

## Todos

- [ ] **todo-1** `pending` Add --since ISO8601 filter to `mokioclaw trace` (parse_since/record_at_or_after helpers in core/transport_trace.py, typer.BadParameter before any run, inclusive UTC compare, skip missing/invalid timestamps only when --since given, composable with --follow).
- [-] **todo-2** `in_progress` Verify: run visible basics test, `trace --help` shows --since, and ad-hoc checks (invalid/naive --since -> exit 2 usage error with no run; Z vs +08:00 equivalence; inclusive boundary; missing-timestamp skip only with --since; --follow composition). Fix any defect found.

## Acceptance Criteria

- `mokioclaw trace --since <ISO8601 with Z or UTC offset>` filters records by UTC timestamp, inclusive of the boundary instant
- Invalid or timezone-less --since yields a CLI usage error (non-zero exit, usage message) and starts no run
- Records with missing/invalid timestamps are skipped only when --since is provided; without --since output is unchanged
- since composes with run_id/layer/direction filters and --follow
- PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py passes; only src/mokioclaw/** modified

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
- `PYTHONPATH=src:. python -m mokioclaw.cli.app trace --help`
