# MokioClaw Todo

## Plan

generation.py truncation gate enabled (output_limit -> ModelGenerationStopped('model_output_truncated') before JSON checks, declared calls carried with empty args). Remaining: verify openai_provider retry-once/not_executed behavior and run tests.

## Todos

- [ ] **todo-1** `pending` generation.py: truncation gate enabled, declared calls carried with empty args (done)
- [ ] **todo-2** `pending` Verify openai_provider.py: not_executed emitted for every declared call incl. complete-looking ones, synthetic AIMessage args empty, corrective message once, retry-once then safe stop; fix only if broken. Also guard outcome(None) in the ModelGenerationStopped handler.
- [ ] **todo-3** `pending` Run PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py and a throwaway /tmp truncation script (length/max_tokens -> no execution, not_executed for all calls, one retry, second truncation safe stop).

## Acceptance Criteria

- finish_reason length/max_tokens invalidates ALL tool calls of that response, including complete-looking ones, before execution
- not_executed tool_result events emitted for every declared call on truncation
- Exactly one re-decision allowed; a second truncation stops safely without executing anything
- No SDK-completed/partial JSON args are ever executed
- Cancellation, redirect/correction and budget checks preserved
- Visible test suite passes

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
