# MokioClaw Recovery

- status: failed
- mode: light
- updated_at: 2026-10-17T07:30:37.307335+00:00
- latest_node: verifier
- next_node: verifier
- attempts: 0 / 3
- workspace: /Users/nicedream/.cache/mokioclaw/eval/job-readiness-v1/experiments/job-readiness-goal2-20261017-b1/trials/M02-v2-full-1/workspace
- resume: `uv run mokioclaw --resume /Users/nicedream/.cache/mokioclaw/eval/job-readiness-v1/experiments/job-readiness-goal2-20261017-b1/trials/M02-v2-full-1/workspace`

## Task
模型返回 length/max_tokens 时，该响应的所有工具调用（包括看似完整的调用）都必须作废并补齐未执行结果；只允许重新决策一次，再次截断安全停止。原始半截 JSON 不得用 SDK 补全值执行。保留取消、纠正和预算检查。

本工作区是固定工程任务切片，不是原仓库的完整测试环境。可见基础检查命令：PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py。该检查验证基础读写/搜索、CLI 帮助和本地 stdio fixture；目标边界请自行验证。隐藏目标及固定回归由外部评分器在全新离线容器重建。只修改 src/mokioclaw 下实现，保留测试和示例 fixture。
允许修改范围：src/mokioclaw/**

评测环境：只修改允许的源代码，禁止修改测试、依赖和测试配置。隐藏测试在外部验收。可以新增源代码辅助文件；TODO.md/NOTEPAD.md/HISTORY_SUMMARY.md 为允许的过程记录。Bash 使用离线 Docker 和预装依赖，不要联网或装包；使用 PYTHONPATH=src:. python -m pytest 运行可见测试。不使用网页、MCP、自定义 hooks、持久授权或后台执行。最后如实说明实现与验证，最后一行用 AGENT_CLAIM: solved 或 AGENT_CLAIM: unsolved 标明自评。

## Plan
generation.py truncation gate enabled (output_limit -> ModelGenerationStopped('model_output_truncated') before JSON checks, declared calls carried with empty args). Remaining: verify openai_provider retry-once/not_executed behavior and run tests.

## Todos
- [pending] generation.py: truncation gate enabled, declared calls carried with empty args (done)
- [pending] Verify openai_provider.py: not_executed emitted for every declared call incl. complete-looking ones, synthetic AIMessage args empty, corrective message once, retry-once then safe stop; fix only if broken. Also guard outcome(None) in the ModelGenerationStopped handler.
- [pending] Run PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py and a throwaway /tmp truncation script (length/max_tokens -> no execution, not_executed for all calls, one retry, second truncation safe stop).

## Acceptance Criteria
- finish_reason length/max_tokens invalidates ALL tool calls of that response, including complete-looking ones, before execution
- not_executed tool_result events emitted for every declared call on truncation
- Exactly one re-decision allowed; a second truncation stops safely without executing anything
- No SDK-completed/partial JSON args are ever executed
- Cancellation, redirect/correction and budget checks preserved
- Visible test suite passes

## Verification Commands
- PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py

## Sources
- (none)

## Recent Summaries
- research: (none)
- codeAgent: ## Report (verification pass — no new edits made)

### State of the code as read

**`src/mokioclaw/providers/generation.py`** (122 lines, read in full) — the prior edits are coherent and syntactically consistent:
- `ModelGenerationStopped.__init__` (lines 16–35) accepts keyword-only `declared` / `raw_reason`; `self.declared` defaults to `declared_calls(message)`; `reason`, `message`, `stream_id`, `state` preserved.
- `declared_calls` (lines 60–81) returns `[]` for `None`, skips non-dicts, dedupes `tool_call_chunks` by id/index, and always sets `args: {}` — no SDK-completed/partial JSON is carried.
- `validate_generation` (lines 84–95) raises `ModelGenerationStopped("model_output_truncated", message, declared=..., raw_reason=...)` when `outcome(message).reason == "output_limit"` (i.e. `length`/`max_tokens`), **before** the JSON-validity checks at lines 103–117. Blocked/unknown handling and `model_tool_arguments_invalid` path unchanged.

**`src/mokioclaw/providers/openai_provider.py`** (lines 50–312 read):
- `invoke_streaming` (80–122): `for attempt in range(2)`; re-raises unless `exc.reason == "model_output_truncated"` and `attempt == 0` → exactly one re-decision, second truncation re-raises (safe stop). Synthetic `AIMessage` tool_calls use `args: {}` (line 106); one `ToolMessage` per declared call; exactly one corrective `HumanMessage` appended per retry.
- `_invoke_once` (125–311): `check_run`, `check_redirect`, `control.check()`, `begin_request`/`finish_request`, budget binding all intact. `validate_generation(assembled)` at line 274 runs before any return. The `except...
- verifier: (none)
- last_error: (none)

## Recent Files
- .codegraph/.gitignore (173 bytes)
- .codegraph/daemon.pid (144 bytes)
- .gitignore (83 bytes)
- .mokioclaw/changes/job-readiness-goal2-20261017-b1-M02-v2-full-1/890f8ab0035e41209d52d95bfd3aa327.bin (4444 bytes)
- .mokioclaw/changes/job-readiness-goal2-20261017-b1-M02-v2-full-1/e01b492222ad481e80305560a0f3847b.bin (3590 bytes)
- .mokioclaw/changes/job-readiness-goal2-20261017-b1-M02-v2-full-1/ef389569bc8c43b28038435ad2c83f96.bin (3973 bytes)
- .mokioclaw/changes/job-readiness-goal2-20261017-b1-M02-v2-full-1/manifest.json (1322 bytes)
- .mokioclaw/diagnostics/bash-stderr-2cd448edef304253ab0e524b054b0253.log (0 bytes)
- .mokioclaw/diagnostics/bash-stdout-d7a309a321d44e6d97a5b883da284cf5.log (98 bytes)
- .mokioclaw/diagnostics/model-stream-1d3145895a494201a92d5625f51d8332.log (45 bytes)
- .mokioclaw/diagnostics/model-stream-23193930ea3a470ca620484c93305efc.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-3165793cadee4ce6a05dbab976478fa7.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-34c3492ebce843d28f20a1329837611f.log (43 bytes)
- .mokioclaw/diagnostics/model-stream-4959408055f3452785394cf055bd196f.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-5345b698e6d84042ad27c82d94b17273.log (4459 bytes)
- .mokioclaw/diagnostics/model-stream-56370964379f44cba466424d4e020573.log (90 bytes)
- .mokioclaw/diagnostics/model-stream-5ff91339e8224baea709c512f66c8c9f.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-7de4a41d3c0845f9a9275c3f8e3f63f4.log (3040 bytes)
- .mokioclaw/diagnostics/model-stream-8581cf6333714e79b93ed1813e00d0fd.log (6316 bytes)
- .mokioclaw/diagnostics/model-stream-8ff723a20b4942ccbe59957254fc4b7c.log (282 bytes)
- .mokioclaw/diagnostics/model-stream-adc648aba43047fab346cfff787f8004.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-bf28195d858149d8a1367a56c6762e7d.log (54 bytes)
- .mokioclaw/diagnostics/model-stream-c5c1e076b2d345d5ae972fe594694fc2.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-c79dbf95378048a9ad8e73f7931fb7f8.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-cbbb51c3bb4d4e45b1033a901c77d312.log (143 bytes)
- .mokioclaw/diagnostics/model-stream-ce875c9051344b7abb1f7cac9760eb4c.log (92 bytes)
- .mokioclaw/diagnostics/model-stream-db0783bd15224d28b4cfd897805e4937.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-db42ad20dcc141029c45ead9df604ed0.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-e1b0fdcf94a0474fbcd75a851ca7e529.log (47 bytes)
- .mokioclaw/diagnostics/model-stream-e3d8a57f2ae64330849806a0767bc920.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-e909db150c7945ad996ab6f161818db1.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-fac24a8687504961bdc737a8c0217e38.log (0 bytes)
- .mokioclaw/inbox/local-b1fa5722d1df4f59975ab02a56678425.json (2 bytes)
- .mokioclaw/memory/repo-64560053a21c0f9241ebaf60.json (5635 bytes)
- .mokioclaw/session/writer.lock (62 bytes)
- .mokioclaw/tool-results/012a22bd9329869ec484ab41.json (12876 bytes)
- .mokioclaw/tool-results/3de87d5a9c30e27b05d5771a.json (16391 bytes)
- .mokioclaw/tool-results/4ca227dd1e89cc0141bb3fc7.json (13746 bytes)
- .mokioclaw/traces/trace-20261017-152936-b4f4d3/events.jsonl (366793 bytes)
- .python-version (5 bytes)
