"""Time filtering helpers for ``mokioclaw trace --since``.

The ``--since`` boundary must be an ISO-8601 datetime that carries an explicit
timezone (``Z`` or a UTC offset). Naive datetimes are rejected because they are
ambiguous. All comparisons happen in UTC and the boundary is inclusive.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

__all__ = ["parse_since", "record_at_or_after", "parse_record_timestamp"]


def _normalize(value: str) -> str:
    text = value.strip()
    if text.endswith(("Z", "z")):
        text = text[:-1] + "+00:00"
    return text


def parse_since(value: str) -> datetime:
    """Parse an ISO-8601 ``--since`` value into an aware UTC datetime.

    Raises ``ValueError`` for unparsable values or values without a timezone.
    """
    if not isinstance(value, str) or not value.strip():
        raise ValueError("--since requires an ISO-8601 datetime with a timezone")
    try:
        parsed = datetime.fromisoformat(_normalize(value))
    except ValueError as exc:
        raise ValueError(
            f"invalid --since value {value!r}: expected ISO-8601 with 'Z' or a UTC offset"
        ) from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError(
            f"invalid --since value {value!r}: timezone is required ('Z' or a UTC offset)"
        )
    return parsed.astimezone(UTC)


def parse_record_timestamp(record: Any) -> datetime | None:
    """Return the record timestamp as an aware UTC datetime, or ``None``."""
    if not isinstance(record, dict):
        return None
    raw = record.get("timestamp")
    if not isinstance(raw, str) or not raw.strip():
        return None
    try:
        parsed = datetime.fromisoformat(_normalize(raw))
    except ValueError:
        return None
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        return None
    return parsed.astimezone(UTC)


def record_at_or_after(record: Any, since: datetime) -> bool:
    """True when the record timestamp is at or after ``since`` (inclusive, UTC)."""
    stamp = parse_record_timestamp(record)
    if stamp is None:
        return False
    return stamp >= since
