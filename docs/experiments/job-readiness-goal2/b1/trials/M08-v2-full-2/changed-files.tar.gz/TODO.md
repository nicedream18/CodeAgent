# MokioClaw Todo

## Plan

Single focused implementation in src/mokioclaw/cli/app.py (plus optional small helper) adding --since filtering to the trace command, then targeted verification.

## Todos

- [-] **todo-1** `in_progress` Add --since option to trace_command in src/mokioclaw/cli/app.py: validate ISO-8601 with Z/UTC offset (reject naive/invalid via typer.BadParameter before any run starts), normalize to UTC, filter records inclusively (>=), skip missing/invalid timestamps only when --since given, keep --follow composition.
- [ ] **todo-2** `pending` Verify: run PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py plus ad-hoc CLI checks for --since Z/offset/inclusive/invalid/naive and --follow composition.

## Acceptance Criteria

- trace --since accepts ISO-8601 with Z or UTC offset, compares in UTC, boundary inclusive
- Invalid or timezone-less --since yields CLI usage error (exit code 2) and starts no run
- Records with missing/invalid timestamps skipped only when --since is set; unchanged output otherwise
- since composes with --follow, --run-id, --layer, --direction
- Visible test suite passes; only src/mokioclaw/** modified

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
