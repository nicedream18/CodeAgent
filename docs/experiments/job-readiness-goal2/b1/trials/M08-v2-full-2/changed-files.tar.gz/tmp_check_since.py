import json
import tempfile
from pathlib import Path

from typer.testing import CliRunner

from mokioclaw.cli.app import app

runner = CliRunner()
ws = Path(tempfile.mkdtemp())
d = ws / ".mokioclaw" / "traces" / "r1"
d.mkdir(parents=True)
recs = [
    {"timestamp": "2023-12-31T23:59:59+00:00", "layer": "event", "direction": "CORE", "type": "before", "run_id": "r1"},
    {"timestamp": "2024-01-01T00:00:00+00:00", "layer": "event", "direction": "CORE", "type": "boundary", "run_id": "r1"},
    {"timestamp": "2024-01-01T08:00:00+08:00", "layer": "event", "direction": "CORE", "type": "offset_equal", "run_id": "r1"},
    {"timestamp": "2024-01-01T00:00:01+00:00", "layer": "event", "direction": "CORE", "type": "after", "run_id": "r1"},
    {"layer": "event", "direction": "CORE", "type": "no_ts", "run_id": "r1"},
    {"timestamp": "not-a-time", "layer": "event", "direction": "CORE", "type": "bad_ts", "run_id": "r1"},
    {"timestamp": "2024-01-01T00:00:00", "layer": "event", "direction": "CORE", "type": "naive_ts", "run_id": "r1"},
]
(d / "events.jsonl").write_text("\n".join(json.dumps(r) for r in recs) + "\n")


def types(res):
    return [json.loads(line)["type"] for line in res.stdout.splitlines() if line.strip()]


def usage(res):
    return "Usage" in res.output or "Invalid value" in res.output


base = ["trace", "--workspace", str(ws), "--raw"]
r = runner.invoke(app, base)
print("no-since:", r.exit_code, types(r))
r = runner.invoke(app, base + ["--since", "2024-01-01T00:00:00Z"])
print("Z:", r.exit_code, types(r))
r = runner.invoke(app, base + ["--since", "2024-01-01T08:00:00+08:00"])
print("offset:", r.exit_code, types(r))
r = runner.invoke(app, base + ["--since", "2024-01-01T00:00:01Z"])
print("after-only:", r.exit_code, types(r))
r = runner.invoke(app, base + ["--since", "2024-01-01T00:00:00+0000"])
print("+0000:", r.exit_code, types(r))
r = runner.invoke(app, base + ["--since", "2024-01-01T00:00:00"])
print("naive:", r.exit_code, usage(r))
r = runner.invoke(app, base + ["--since", "garbage"])
print("invalid:", r.exit_code, usage(r))
r = runner.invoke(app, base + ["--since", "2024-01-01T00:00:00Z", "--run-id", "r1", "--layer", "event", "--direction", "CORE"])
print("combo:", r.exit_code, types(r))
r = runner.invoke(app, base + ["--since", "2024-01-01T00:00:00Z", "--run-id", "nope"])
print("combo-empty:", r.exit_code, types(r))
r = runner.invoke(app, ["trace", "--help"])
print("help:", r.exit_code, "--since" in r.output)
