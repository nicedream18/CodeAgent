# MokioClaw Recovery

- status: failed
- mode: light
- updated_at: 2026-10-17T07:36:35.514567+00:00
- latest_node: verifier
- next_node: verifier
- attempts: 0 / 3
- workspace: /Users/nicedream/.cache/mokioclaw/eval/job-readiness-v1/experiments/job-readiness-goal2-20261017-b1/trials/M02-v2-full-2/workspace
- resume: `uv run mokioclaw --resume /Users/nicedream/.cache/mokioclaw/eval/job-readiness-v1/experiments/job-readiness-goal2-20261017-b1/trials/M02-v2-full-2/workspace`

## Task
模型返回 length/max_tokens 时，该响应的所有工具调用（包括看似完整的调用）都必须作废并补齐未执行结果；只允许重新决策一次，再次截断安全停止。原始半截 JSON 不得用 SDK 补全值执行。保留取消、纠正和预算检查。

本工作区是固定工程任务切片，不是原仓库的完整测试环境。可见基础检查命令：PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py。该检查验证基础读写/搜索、CLI 帮助和本地 stdio fixture；目标边界请自行验证。隐藏目标及固定回归由外部评分器在全新离线容器重建。只修改 src/mokioclaw 下实现，保留测试和示例 fixture。
允许修改范围：src/mokioclaw/**

评测环境：只修改允许的源代码，禁止修改测试、依赖和测试配置。隐藏测试在外部验收。可以新增源代码辅助文件；TODO.md/NOTEPAD.md/HISTORY_SUMMARY.md 为允许的过程记录。Bash 使用离线 Docker 和预装依赖，不要联网或装包；使用 PYTHONPATH=src:. python -m pytest 运行可见测试。不使用网页、MCP、自定义 hooks、持久授权或后台执行。最后如实说明实现与验证，最后一行用 AGENT_CLAIM: solved 或 AGENT_CLAIM: unsolved 标明自评。

## Plan
Truncation invalidation enabled in validate_generation; provider retry/not_executed and lifecycle safe stop verified; visible tests pass.

## Todos
- [pending] Enable output_limit invalidation in providers/generation.py validate_generation.
- [pending] Verify openai_provider.py retry/not_executed path and lifecycle safe stop; run visible tests.

## Acceptance Criteria
- validate_generation raises ModelGenerationStopped('model_output_truncated', message) when outcome is output_limit, before blocked/unknown handling and before JSON arg validation
- All tool calls in a truncated response (including complete-looking ones) are invalidated and get not_executed results
- Only one re-decision attempt is allowed; a second truncation stops safely via lifecycle handler
- SDK-repaired/partial JSON args are never executed
- Cancellation, correction and budget checks remain intact
- PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py passes

## Verification Commands
- PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py

## Sources
- (none)

## Recent Summaries
- research: (none)
- codeAgent: ## Report

### Files changed
- `src/mokioclaw/providers/generation.py` (only file modified)

### Exact edit
In `validate_generation`, the dead guard was replaced:

```python
    if result.reason == "output_limit":
        # Truncated output invalidates every declared call in this response,
        # including ones whose arguments happen to look complete: the model was
        # cut off mid-generation, so no call from this response may execute.
        raise ModelGenerationStopped("model_output_truncated", message)
```

This sits immediately after `outcome(message)` and **before** the blocked/unknown handling and **before** the strict `json.loads` argument validation, so every declared call in a `length`/`max_tokens` response (including complete-looking ones) is invalidated.

### Verified by reading (no edits needed)
- `src/mokioclaw/providers/openai_provider.py`:
  - `invoke_streaming` uses `for attempt in range(2)` — exactly one re-decision; on the second truncation `raise` propagates.
  - Synthetic `AIMessage` for the re-decision carries `args: {}` for every declared call (never parsed partial args).
  - Corrective `HumanMessage` is appended; `ToolMessage` "Not executed: output was truncated…" is appended for every declared call.
  - `_invoke_once` `except ModelGenerationStopped` emits a `tool_result` with `status: "not_executed"` and `error_type: exc.reason` for every `declared_calls(assembled)`, with `metadata` updated to `finish_reason=outcome(assembled).reason` (i.e. `output_limit`).
  - Strict `json.loads` on `tool_call_chunks` and `additional_kwargs.tool_calls` r...
- verifier: (none)
- last_error: (none)

## Recent Files
- .codegraph/.gitignore (173 bytes)
- .codegraph/daemon.pid (144 bytes)
- .gitignore (83 bytes)
- .mokioclaw/changes/job-readiness-goal2-20261017-b1-M02-v2-full-2/d9a5c1308c55434fab417ad734f17f8d.bin (3590 bytes)
- .mokioclaw/changes/job-readiness-goal2-20261017-b1-M02-v2-full-2/manifest.json (519 bytes)
- .mokioclaw/diagnostics/bash-stderr-307565af1df34557821df705677c4560.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-61d3e30d26a64c40976890196c5d631f.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-709fcfaa24834485b9cb95ffa5822650.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-93e830607a744cdaa37827f2d48e8506.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-af6bbfcf09b240d0ae8be5a636fab104.log (258 bytes)
- .mokioclaw/diagnostics/bash-stderr-afea4355658243a292c71a61010fca9f.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-b5328d2a637447c4a313b609c1332000.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-ec218c5de2ef4975b8cd7c75349e3c56.log (0 bytes)
- .mokioclaw/diagnostics/bash-stdout-0031248b7a7148689499e9e349aa1ef4.log (5716 bytes)
- .mokioclaw/diagnostics/bash-stdout-2a2c139fa7084a168fa7f7de0bc19e7f.log (345 bytes)
- .mokioclaw/diagnostics/bash-stdout-3c5c82e97e774e7f834b60eea4273ba5.log (258 bytes)
- .mokioclaw/diagnostics/bash-stdout-66991e6eb9f74614a20fc44d77860f6a.log (83 bytes)
- .mokioclaw/diagnostics/bash-stdout-74a8c7cd3750497e8972a24c4e7cbd78.log (3401 bytes)
- .mokioclaw/diagnostics/bash-stdout-833e006189e34075b225107fed0c5b0f.log (98 bytes)
- .mokioclaw/diagnostics/bash-stdout-a83101112768427da40b1030f5e009ce.log (156 bytes)
- .mokioclaw/diagnostics/bash-stdout-fc8cf48e28834aaebe7e9f827aa4051b.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-0cc099c2550140cfb7a4367b38ede83f.log (319 bytes)
- .mokioclaw/diagnostics/model-stream-144249819a9f4dbaa77bd725e8c455f3.log (45 bytes)
- .mokioclaw/diagnostics/model-stream-18ad28afeb3a4d93aa753035957d74a9.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-2029db23f2784767bb127b8c444c25a6.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-36b176734b6e47e79fd012f18cc712f7.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-3d7e2e296117432abe713aead8ba3467.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-8ae44540727a408aa49ea809e0258ee3.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-a52780254b684f2c87aa951c4207de0b.log (89 bytes)
- .mokioclaw/diagnostics/model-stream-a5a926cb2a414ea0849fa2eeb1770be9.log (2134 bytes)
- .mokioclaw/diagnostics/model-stream-c6d29c788a464537900c1f982113472a.log (158 bytes)
- .mokioclaw/diagnostics/model-stream-ca97ff57685f40bfa4d4f5e8d2280a30.log (47 bytes)
- .mokioclaw/diagnostics/model-stream-d0dbe570ef594ce6b31b150399d71a7e.log (90 bytes)
- .mokioclaw/diagnostics/model-stream-e9f178b0dffb4caabe8042c1e6f84dc8.log (2791 bytes)
- .mokioclaw/diagnostics/model-stream-efc188eb91324a08b29c1e9bfc9ebb08.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-f8a28ef70bbc4739a70fb51b5ea8b47b.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-fc82db38bf7246c5a695aa7dffdb88cb.log (68 bytes)
- .mokioclaw/inbox/local-17b657e105f74b5fa25314813cdebd23.json (2 bytes)
- .mokioclaw/memory/repo-f0a63589b81792e9aa688451.json (5978 bytes)
- .mokioclaw/session/writer.lock (62 bytes)
