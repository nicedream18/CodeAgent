# MokioClaw Todo

## Plan

Truncation invalidation enabled in validate_generation; provider retry/not_executed and lifecycle safe stop verified; visible tests pass.

## Todos

- [ ] **todo-1** `pending` Enable output_limit invalidation in providers/generation.py validate_generation.
- [ ] **todo-2** `pending` Verify openai_provider.py retry/not_executed path and lifecycle safe stop; run visible tests.

## Acceptance Criteria

- validate_generation raises ModelGenerationStopped('model_output_truncated', message) when outcome is output_limit, before blocked/unknown handling and before JSON arg validation
- All tool calls in a truncated response (including complete-looking ones) are invalidated and get not_executed results
- Only one re-decision attempt is allowed; a second truncation stops safely via lifecycle handler
- SDK-repaired/partial JSON args are never executed
- Cancellation, correction and budget checks remain intact
- PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py passes

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
