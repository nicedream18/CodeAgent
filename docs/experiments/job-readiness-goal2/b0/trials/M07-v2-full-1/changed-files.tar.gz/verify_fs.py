import shutil, tempfile
from pathlib import Path
from types import SimpleNamespace
from mokioclaw.tools.grep_tool import grep
from mokioclaw.tools.registry import build_tools


def mkstate(root, backend="auto"):
    return SimpleNamespace(workspace=Path(root).resolve(),
                           settings={"search": {"backend": backend}},
                           run_control=None)


results = {}
tmp = tempfile.mkdtemp()
try:
    ws = Path(tmp)
    (ws / "a.txt").write_text("hello\nhallo\nhxllo\n")
    (ws / "lit.txt").write_text("a.b\naxb\n(x)\n[y]\nHELLO\nhello\n")
    (ws / "中文目录").mkdir()
    (ws / "中文目录" / "文件.txt").write_text("a.b 中文\naxb\n")
    (ws / "ignored.txt").write_text("a.b ignored\n")
    (ws / ".gitignore").write_text("ignored.txt\n")
    (ws / "many.txt").write_text("\n".join(["a.b"] * 5) + "\n")
    st = mkstate(ws)

    r = grep(st, "h.llo")
    results["default_regex"] = r["ok"] and len(r["matches"]) == 3
    r = grep(st, "a.b", fixed_strings=True)
    texts = [m["text"] for m in r["matches"]]
    results["literal_dot"] = r["ok"] and "a.b" in texts and "axb" not in texts
    r = grep(st, "(x)", fixed_strings=True)
    results["literal_paren"] = r["ok"] and [m["text"] for m in r["matches"]] == ["(x)"]
    r = grep(st, "[y]", fixed_strings=True)
    results["literal_bracket"] = r["ok"] and [m["text"] for m in r["matches"]] == ["[y]"]
    r = grep(st, "hello", fixed_strings=True, ignore_case=True)
    results["literal_ignore_case"] = r["ok"] and sorted(m["text"] for m in r["matches"]) == ["HELLO", "hello"]
    r = grep(st, "a.b", fixed_strings=True, head_limit=2)
    results["head_limit"] = r["ok"] and len(r["matches"]) == 2
    r = grep(st, "a.b", path="中文目录", fixed_strings=True)
    results["chinese_path"] = r["ok"] and len(r["matches"]) == 1 and "中文目录" in r["matches"][0]["path"]
    r = grep(st, "a.b", fixed_strings=True)
    results["ignore_rules"] = r["ok"] and not any("ignored.txt" in m["path"] for m in r["matches"])

    rg = shutil.which("rg")
    if rg:
        a = grep(mkstate(ws, "auto"), "a.b", fixed_strings=True)
        b = grep(mkstate(ws, "python"), "a.b", fixed_strings=True)
        results["parity_fixed"] = a["matches"] == b["matches"] and len(a["matches"]) > 0
        a = grep(mkstate(ws, "auto"), "hello", fixed_strings=True, ignore_case=True)
        b = grep(mkstate(ws, "python"), "hello", fixed_strings=True, ignore_case=True)
        results["parity_icase"] = a["matches"] == b["matches"] and len(a["matches"]) > 0
        a = grep(mkstate(ws, "auto"), "h.llo")
        b = grep(mkstate(ws, "python"), "h.llo")
        results["parity_regex"] = a["matches"] == b["matches"]
    else:
        results["parity"] = "skipped (no rg)"

    tools = build_tools(st)
    gt = tools["GrepTool"] if isinstance(tools, dict) else next(t for t in tools if t.name == "GrepTool")
    schema = gt.args_schema.model_json_schema() if hasattr(gt.args_schema, "model_json_schema") else gt.args_schema.schema()
    props = schema.get("properties", {})
    results["schema"] = "fixed_strings" in props and props["fixed_strings"].get("default") is False
    out = gt.invoke({"pattern": "a.b", "fixed_strings": True})
    results["tool_invoke"] = out["ok"] and any(m["text"] == "a.b" for m in out["matches"])
finally:
    shutil.rmtree(tmp, ignore_errors=True)

for k, v in results.items():
    print(f"{k}: {v}")
print("ALL_PASS:", all(v is True or isinstance(v, str) for v in results.values()))
