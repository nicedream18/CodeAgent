# MokioClaw Todo

## Plan

Implementation is in place; remaining work is verification only, with a minimal fix if a check fails.

## Todos

- [ ] **todo-1** `pending` Add fixed_strings=False to grep() in src/mokioclaw/tools/grep_tool.py (re.escape for Python backend, -F for rg).
- [ ] **todo-2** `pending` Expose fixed_strings: bool=False on GrepTool in src/mokioclaw/tools/registry.py and forward to grep().
- [ ] **todo-3** `pending` Verify: run visible pytest plus ad-hoc checks (literal metachars, ignore_case, Chinese paths, ignore rules, head_limit, rg-vs-python parity, default regex unchanged); fix only if a check fails.

## Acceptance Criteria

- grep accepts fixed_strings and treats metacharacters literally when True
- GrepTool schema exposes fixed_strings: bool = False and forwards it
- fixed_strings composes with ignore_case, Chinese paths, ignore rules, head_limit
- rg and Python backends produce identical matches content and order
- Default regex behavior unchanged; visible tests pass

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
