# MokioClaw Todo

## Plan

Implementation is in place (grep_tool.py re.escape/-F, registry.py fixed_strings passthrough). Remaining work is verification only.

## Todos

- [x] **todo-1** `completed` Add fixed_strings=False to grep() in src/mokioclaw/tools/grep_tool.py: literal matching via re.escape (Python backend) and -F flag (rg backend), preserving ignore_case, ignore rules, head_limit, and match content/order parity.
- [x] **todo-2** `completed` Expose fixed_strings: bool=False on GrepTool in src/mokioclaw/tools/registry.py (lambda + description) and pass through to grep().
- [-] **todo-3** `in_progress` Verify: run visible pytest, plus ad-hoc checks for literal metacharacters, ignore_case, Chinese paths, ignore rules, head_limit, and rg-vs-python parity.

## Acceptance Criteria

- grep() accepts fixed_strings=False and GrepTool schema exposes fixed_strings: bool=False
- With fixed_strings=True, '.', '(', '[', '*', 'C++' etc. match literally and no re.error is raised
- fixed_strings composes with ignore_case, glob, ignore rules, head_limit, and Chinese paths
- rg backend and Python backend return identical matches content and order for fixed_strings searches
- Default (fixed_strings=False) regex behavior unchanged; visible tests pass

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
