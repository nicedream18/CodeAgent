# MokioClaw Todo

## Plan

Implementation of --since is in place in src/mokioclaw/cli/app.py; remaining work is runtime verification and any small fix it reveals.

## Todos

- [ ] **todo-1** `pending` Add --since option + helpers in src/mokioclaw/cli/app.py (done by code agent).
- [ ] **todo-2** `pending` Apply inclusive UTC filter in record loop (done by code agent).
- [-] **todo-3** `in_progress` Run visible pytest, trace --help, and ad-hoc --since boundary/offset/naive/garbage checks; fix any failure found.

## Acceptance Criteria

- trace --since accepts ISO8601 with Z or ±HH:MM offset and filters records with timestamp >= since compared in UTC (inclusive boundary)
- Invalid or timezone-less --since raises a CLI usage error (exit code 2) and starts no run/reader
- Records with missing or invalid timestamps are skipped when --since is given; without --since output is unchanged
- since composes with --follow, --layer, --direction, --run-id, --raw
- Visible test suite passes

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
- `PYTHONPATH=src:. python -m mokioclaw trace --help`
