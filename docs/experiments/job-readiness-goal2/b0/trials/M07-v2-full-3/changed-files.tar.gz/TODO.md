# MokioClaw Todo

## Plan

Implementation and verification complete: fixed_strings literal search added to grep() and GrepTool; visible suite 3 passed; 12/12 ad-hoc assertions pass.

## Todos

- [ ] **todo-1** `pending` Add fixed_strings=False to grep() in src/mokioclaw/tools/grep_tool.py (rg -F; Python re.escape) — done.
- [ ] **todo-2** `pending` Expose fixed_strings: bool=False on GrepTool in src/mokioclaw/tools/registry.py — done.
- [ ] **todo-3** `pending` Verify visible suite + ad-hoc literal/ignore_case/Chinese path/ignore rules/head_limit/parity checks — 3 passed, 12/12 assertions pass.

## Acceptance Criteria

- grep() accepts fixed_strings=False and GrepTool schema exposes fixed_strings: bool = False
- With fixed_strings=True, '.', '(', '[', etc. match literally; ignore_case, Chinese paths, ignore rules and head_limit still work
- rg and Python backends produce identical matches content and order
- Default (fixed_strings=False) regex behavior unchanged; visible tests pass

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
