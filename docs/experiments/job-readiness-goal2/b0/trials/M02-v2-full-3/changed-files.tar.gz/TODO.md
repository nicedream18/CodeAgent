# MokioClaw Todo

## Plan

Fix truncation handling: validate_generation must raise ModelGenerationStopped on output_limit before tool-arg validation; provider retry loop must invalidate all calls, retry once, and stop safely on second truncation.

## Todos

- [x] **todo-1** `completed` In src/mokioclaw/providers/generation.py: make validate_generation raise ModelGenerationStopped('model_output_truncated', message) when outcome(message).reason == 'output_limit' (length/max_tokens), before any tool-argument validation, so ALL declared calls (including complete-looking ones) are invalidated and no SDK-completed partial JSON args are used.
- [x] **todo-2** `completed` In src/mokioclaw/providers/openai_provider.py: ensure invoke_streaming retries exactly once (range(2)) with a corrective HumanMessage and synthetic AIMessage carrying empty args (never SDK-completed values), re-raises on second truncation for safe stop, and emits not_executed tool_result events for every declared call; keep check_run/check_redirect/RunControl and budget checks intact.
- [x] **todo-3** `completed` Run PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py plus a focused ad-hoc check of truncation invalidation / single retry / second-truncation stop.

## Acceptance Criteria

- output_limit (length/max_tokens) responses raise ModelGenerationStopped before any tool call is executed, including complete-looking calls
- All declared calls on a truncated response get not_executed tool results
- Exactly one re-decision attempt; a second truncation stops safely
- Partial JSON args are never executed via SDK-completed values
- Cancellation, correction and budget checks preserved
- Visible test suite passes

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
