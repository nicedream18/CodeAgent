# MokioClaw Todo

## Plan

Implementation complete; remaining work is end-to-end behavioral verification through a working CLI entry point.

## Todos

- [-] **todo-1** `in_progress` Add --since ISO8601 (tz-aware, UTC-compared, inclusive) filter to `mokioclaw trace` in src/mokioclaw/cli/app.py; invalid/naive values raise CLI usage error before any run starts; records with missing/invalid timestamps skipped only when --since given; --follow composes with filters.
- [ ] **todo-2** `pending` Verify end-to-end via a working entry point (`python -c "from mokioclaw.cli.app import app; app()"` or CliRunner): Z/offset/inclusive boundary/invalid/naive/missing-timestamp/--follow, plus visible pytest.

## Acceptance Criteria

- `--since` filters by UTC timestamp, inclusive of the boundary instant
- Offsets like +08:00 normalized to UTC before comparison
- Invalid or timezone-less --since -> CLI usage error (non-zero exit) with no run started
- Records with missing/invalid timestamps skipped only when --since given; unchanged output otherwise
- follow composes with --since and other filters
- PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py passes

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
