# MokioClaw Todo

## Plan

Truncation gate implemented in generation.py; provider retry path verified by reading. Remaining: verify the openai_provider.py edit is syntactically/import-wise correct (check_run/check_redirect imports and runtime lookup) and run the visible suite plus a focused truncation check.

## Todos

- [ ] **todo-1** `pending` generation.py: validate_generation raises ModelGenerationStopped('model_output_truncated') on output_limit before tool-arg parsing.
- [-] **todo-2** `in_progress` openai_provider.py: verify the added check_run/check_redirect calls in invoke_streaming use correct imports/signatures and that the module imports cleanly; fix minimally if broken.
- [ ] **todo-3** `pending` Run PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py plus a focused ad-hoc truncation check (length + complete-looking tool_call -> ModelGenerationStopped; normal message passes).

## Acceptance Criteria

- finish_reason/stop_reason length|max_tokens invalidates every tool call in that response, including apparently complete ones
- Each invalidated call gets a not_executed tool result; no tool executes with SDK-completed/partial JSON args
- Exactly one re-decision attempt is allowed; a second truncation stops safely
- Cancellation, redirect/correction and budget checks still run on the retry path
- Visible test suite passes and module imports cleanly

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
- `PYTHONPATH=src:. python -c "import mokioclaw.providers.openai_provider, mokioclaw.providers.generation"`
