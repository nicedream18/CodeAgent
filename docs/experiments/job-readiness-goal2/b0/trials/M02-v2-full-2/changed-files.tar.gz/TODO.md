# MokioClaw Todo

## Plan

Implementation done (truncation gate enabled + retry-branch cancellation/redirect checks). Remaining: run verification only.

## Todos

- [x] **todo-1** `completed` Enable truncation gate in generation.validate_generation (done) — Verified generation.py:66-71 raises ModelGenerationStopped('model_output_truncated') for output_limit before any arg validation.
- [x] **todo-2** `completed` Provider single-retry / empty-args / not_executed / preserved checks (done) — Verified openai_provider.py:88-128 single retry (line 101 `or attempt`), synthetic args {} (line 112), not_executed loop over declared_calls (115-122); 300-317 emits not_executed for every declared call; check_run/check_redirect at 104-107, 145-148, 211, 250, 258, 273, 298.
- [x] **todo-3** `completed` Run visible pytest suite and a focused ad-hoc truncation check using python -c (no shell redirection). — pytest: 3 passed. Ad-hoc: length/max_tokens -> model_output_truncated with 3 declared calls; stop/end_turn -> completed. No source edits needed.

## Acceptance Criteria

- length/max_tokens invalidates every tool call in that response
- Only one re-decision retry; second truncation stops safely
- Partial JSON args never executed
- Cancellation/redirect/budget checks preserved
- Visible test suite passes

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
