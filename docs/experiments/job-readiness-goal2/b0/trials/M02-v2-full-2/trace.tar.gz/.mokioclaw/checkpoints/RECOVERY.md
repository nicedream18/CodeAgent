# MokioClaw Recovery

- status: failed
- mode: light
- updated_at: 2026-10-17T07:35:34.703197+00:00
- latest_node: codeAgent
- next_node: 
- attempts: 0 / 3
- workspace: /Users/nicedream/.cache/mokioclaw/eval/job-readiness-v1/experiments/job-readiness-goal2-20261017-b0/trials/M02-v2-full-2/workspace
- resume: `uv run mokioclaw --resume /Users/nicedream/.cache/mokioclaw/eval/job-readiness-v1/experiments/job-readiness-goal2-20261017-b0/trials/M02-v2-full-2/workspace`

## Task
模型返回 length/max_tokens 时，该响应的所有工具调用（包括看似完整的调用）都必须作废并补齐未执行结果；只允许重新决策一次，再次截断安全停止。原始半截 JSON 不得用 SDK 补全值执行。保留取消、纠正和预算检查。

本工作区是固定工程任务切片，不是原仓库的完整测试环境。可见基础检查命令：PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py。该检查验证基础读写/搜索、CLI 帮助和本地 stdio fixture；目标边界请自行验证。隐藏目标及固定回归由外部评分器在全新离线容器重建。只修改 src/mokioclaw 下实现，保留测试和示例 fixture。
允许修改范围：src/mokioclaw/**

评测环境：只修改允许的源代码，禁止修改测试、依赖和测试配置。隐藏测试在外部验收。可以新增源代码辅助文件；TODO.md/NOTEPAD.md/HISTORY_SUMMARY.md 为允许的过程记录。Bash 使用离线 Docker 和预装依赖，不要联网或装包；使用 PYTHONPATH=src:. python -m pytest 运行可见测试。不使用网页、MCP、自定义 hooks、持久授权或后台执行。最后如实说明实现与验证，最后一行用 AGENT_CLAIM: solved 或 AGENT_CLAIM: unsolved 标明自评。

## Plan
Implementation done (truncation gate enabled + retry-branch cancellation/redirect checks). Remaining: run verification only.

## Todos
- [completed] Enable truncation gate in generation.validate_generation (done)
- [completed] Provider single-retry / empty-args / not_executed / preserved checks (done)
- [completed] Run visible pytest suite and a focused ad-hoc truncation check using python -c (no shell redirection).

## Acceptance Criteria
- length/max_tokens invalidates every tool call in that response
- Only one re-decision retry; second truncation stops safely
- Partial JSON args never executed
- Cancellation/redirect/budget checks preserved
- Visible test suite passes

## Verification Commands
- PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py

## Sources
- (none)

## Recent Summaries
- research: (none)
- codeAgent: ## Report

### Files changed

**1. `src/mokioclaw/providers/generation.py` (lines 66–71)**
Replaced the dead `if False:` gate in `validate_generation` with a real truncation check:

```python
def validate_generation(message: Any) -> GenerationOutcome:
    result = outcome(message)
    if result.reason == "output_limit":
        # A truncated response is never executable: every declared call is discarded,
        # even ones that look complete, because the raw JSON may be cut off.
        raise ModelGenerationStopped("model_output_truncated", message)
```

- `outcome()` maps `finish_reason`/`stop_reason` in `{length, max_tokens}` to `output_limit`, so both raw reasons now raise `ModelGenerationStopped("model_output_truncated", message)`.
- The check runs **before** the tool-argument validation block, so it fires regardless of whether the calls look complete or parse cleanly — no call from a truncated response can reach execution.
- The exception carries the original message, so `declared_calls(message)` (tool_calls + invalid_tool_calls + tool_call_chunks) is available to the caller for `not_executed` reporting.

**2. `src/mokioclaw/providers/openai_provider.py` (`invoke_streaming`, lines ~99–108)**
Added cancellation/redirect checks in the retry branch, before building the synthetic re-decision messages:

```python
except ModelGenerationStopped as exc:
    # Exactly one re-decision is allowed; a second truncation stops safely.
    if exc.reason != "model_output_truncated" or attempt:
        raise
    runtime = (state or {}).get("runtime")
    check_run(runtime)
    from ...
- verifier: (none)
- last_error: (none)

## Recent Files
- .codegraph/.gitignore (173 bytes)
- .codegraph/daemon.pid (144 bytes)
- .gitignore (83 bytes)
- .mokioclaw/changes/job-readiness-goal2-20261017-b0-M02-v2-full-2/7a78c65acafc411587c3268be946b481.bin (13827 bytes)
- .mokioclaw/changes/job-readiness-goal2-20261017-b0-M02-v2-full-2/d4dc4f8ae83544a79829a34d41cce70d.bin (3590 bytes)
- .mokioclaw/changes/job-readiness-goal2-20261017-b0-M02-v2-full-2/manifest.json (925 bytes)
- .mokioclaw/diagnostics/bash-stderr-3bd4b4339cc6433da4408a5c922d89d2.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-6a0f2403cf474e0fb8cdc2451d0f7c1f.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-b10bde099b4448af9cd0da2431fd6d98.log (0 bytes)
- .mokioclaw/diagnostics/bash-stdout-b75e2c15034c4f7c916252b3cf2b94fe.log (60 bytes)
- .mokioclaw/diagnostics/bash-stdout-e08a2e36c077478791f81fbbbe509a4f.log (198 bytes)
- .mokioclaw/diagnostics/bash-stdout-e962af3ae87c4a1da54e2a06de0d5a98.log (98 bytes)
- .mokioclaw/diagnostics/model-stream-1d429b9eb0434deeaa2d111090ac0dce.log (54 bytes)
- .mokioclaw/diagnostics/model-stream-28af339d261f44759ba25b34881165b3.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-2a35968b775947c0b982107b2bdc81ca.log (6748 bytes)
- .mokioclaw/diagnostics/model-stream-3baa7cc527ab49d3b47a59b5ff6bf3f0.log (49 bytes)
- .mokioclaw/diagnostics/model-stream-424c3718f40c41f48341cb6aa77b0db6.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-5ca6f1a2c98044f7922c5a6e9143efd6.log (38 bytes)
- .mokioclaw/diagnostics/model-stream-77baa4d316984a4ca2a231b62de42f4c.log (40 bytes)
- .mokioclaw/diagnostics/model-stream-77c8fc5087c64b46a40da0b16817e850.log (73 bytes)
- .mokioclaw/diagnostics/model-stream-7847531c04934b07b14b04531a29670d.log (200 bytes)
- .mokioclaw/diagnostics/model-stream-7e4cd39957f8427fa5fc82f551a2ae10.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-848448346aa24613aba7225149c8f60a.log (98 bytes)
- .mokioclaw/diagnostics/model-stream-84e83df1f2b347248f3ab8fc234320e9.log (3834 bytes)
- .mokioclaw/diagnostics/model-stream-912143682c2b44979e2adaf59c63b1d6.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-9a4e42119860438e9ab0fd2d372bc5be.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-b0ad77d6226b4b29848185a2728a8332.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-b76449d83e8044d48f916ac98bfea3c5.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-bf8cddc927954d80b6dfd2541ef3075b.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-dd6225960596486483fc8a8f0e4cff6b.log (282 bytes)
- .mokioclaw/diagnostics/model-stream-e2aac520c8014d19a7a1809d582fd6e3.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-e9f0372412624a72a466814e019420cb.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-edab68eaca8a47c4bc06d2547ca3b4d9.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-f7471b097cc04bb0bad135b872df79a0.log (43 bytes)
- .mokioclaw/inbox/local-129dce83979847cb9d3ab01ada4e7941.json (2 bytes)
- .mokioclaw/memory/repo-029ad4c95486a29fd92ff5b7.json (5867 bytes)
- .mokioclaw/session/writer.lock (62 bytes)
- .mokioclaw/traces/trace-20261017-153441-307ea6/events.jsonl (305133 bytes)
- .python-version (5 bytes)
- Makefile (346 bytes)
