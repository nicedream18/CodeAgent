# MokioClaw Todo

## Plan

Implemented --since in src/mokioclaw/cli/app.py with strict tz-aware parsing, UTC-inclusive filtering, and pre-run validation; visible tests pass and manual CLI checks confirm exit code 2 for invalid input.

## Todos

- [x] **todo-1** `completed` Add --since ISO8601 (tz-aware, inclusive, UTC compare) filter to trace command in src/mokioclaw/cli/app.py; invalid/no-tz -> typer.BadParameter before any run; skip missing/invalid timestamps only when --since set; keep --follow composable.
- [x] **todo-2** `completed` Run visible tests plus a targeted manual check of --since parsing/filtering.

## Acceptance Criteria

- trace --since accepts Z and +HH:MM offsets, inclusive boundary, compares in UTC
- Invalid or timezone-less --since yields CLI usage error (exit 2) and starts no run
- Records with missing/invalid timestamps skipped only when --since given; output unchanged otherwise
- follow composes with --since and other filters
- PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py passes

## Verification Commands

- `PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py`
