# MokioClaw Recovery

- status: finished
- mode: light
- updated_at: 2026-10-17T07:25:00.897921+00:00
- latest_node: final
- next_node: final
- attempts: 1 / 3
- workspace: /Users/nicedream/.cache/mokioclaw/eval/job-readiness-v1/experiments/job-readiness-goal2-20261017-b0/trials/M08-v2-full-1/workspace
- resume: `uv run mokioclaw --resume /Users/nicedream/.cache/mokioclaw/eval/job-readiness-v1/experiments/job-readiness-goal2-20261017-b0/trials/M08-v2-full-1/workspace`

## Task
为 mokioclaw trace 增加 --since ISO8601 时间过滤，要求带 Z 或 UTC 偏移、包含边界时刻并按 UTC 比较。不合法或没有时区的参数返回 CLI 用法错误，不能启动任何运行。旧记录无时间戳或时间戳无效时，在有 --since 条件下跳过；无该参数时仍保持原输出。--follow 与其他筛选可组合。

本工作区是固定工程任务切片，不是原仓库的完整测试环境。可见基础检查命令：PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py。该检查验证基础读写/搜索、CLI 帮助和本地 stdio fixture；目标边界请自行验证。隐藏目标及固定回归由外部评分器在全新离线容器重建。只修改 src/mokioclaw 下实现，保留测试和示例 fixture。
允许修改范围：src/mokioclaw/**

评测环境：只修改允许的源代码，禁止修改测试、依赖和测试配置。隐藏测试在外部验收。可以新增源代码辅助文件；TODO.md/NOTEPAD.md/HISTORY_SUMMARY.md 为允许的过程记录。Bash 使用离线 Docker 和预装依赖，不要联网或装包；使用 PYTHONPATH=src:. python -m pytest 运行可见测试。不使用网页、MCP、自定义 hooks、持久授权或后台执行。最后如实说明实现与验证，最后一行用 AGENT_CLAIM: solved 或 AGENT_CLAIM: unsolved 标明自评。

## Plan
Implemented --since in src/mokioclaw/cli/app.py with strict tz-aware parsing, UTC-inclusive filtering, and pre-run validation; visible tests pass and manual CLI checks confirm exit code 2 for invalid input.

## Todos
- [completed] Add --since ISO8601 (tz-aware, inclusive, UTC compare) filter to trace command in src/mokioclaw/cli/app.py; invalid/no-tz -> typer.BadParameter before any run; skip missing/invalid timestamps only when --since set; keep --follow composable.
- [completed] Run visible tests plus a targeted manual check of --since parsing/filtering.

## Acceptance Criteria
- trace --since accepts Z and +HH:MM offsets, inclusive boundary, compares in UTC
- Invalid or timezone-less --since yields CLI usage error (exit 2) and starts no run
- Records with missing/invalid timestamps skipped only when --since given; output unchanged otherwise
- follow composes with --since and other filters
- PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py passes

## Verification Commands
- PYTHONPATH=src:. python -m pytest -q tests/test_visible_basics.py

## Sources
- (none)

## Recent Summaries
- research: (none)
- codeAgent: ## Summary

**File changed:** `src/mokioclaw/cli/app.py` (only file touched; no tests/fixtures/deps modified)

**Implementation:**
- New module-level helpers (placed just above `trace_command`):
  - `_parse_iso8601_utc(value: str) -> datetime` — strips trailing `Z`/`z` → `+00:00`, calls `datetime.fromisoformat`, rejects naive timestamps (`tzinfo is None` or `utcoffset() is None`) with `ValueError`, returns `parsed.astimezone(UTC)`.
  - `_parse_since(value: str) -> datetime` — wraps the above and converts any `ValueError` into `typer.BadParameter(...)` (Typer → usage error, exit code 2).
  - `_record_at_or_after(record: dict, since_utc: datetime) -> bool` — returns `False` when `timestamp` is missing, not a `str`, unparseable, or naive; otherwise `record_utc >= since_utc` (inclusive, UTC comparison).
- `trace_command` gained option `since: Annotated[str | None, typer.Option("--since", help=...)] = None`.
- Validation happens as the **first statement** of the command body (`since_utc = _parse_since(since) if since is not None else None`), before importing/constructing `TraceReader` or entering the follow loop — so invalid input starts no run.
- Filter inserted after the existing `run_id`/`layer`/`direction` filters and before output: `if since_utc is not None and not _record_at_or_after(record, since_utc): continue`. It sits inside the `while True` loop, so it applies equally to `--follow` streaming. When `--since` is absent, `since_utc` is `None` and no filtering occurs — output path (raw vs formatted) unchanged.

**Verification:**
- `PYTHONPATH=src:. python -m pytest -q ...
- verifier: `--since` is implemented in src/mokioclaw/cli/app.py with strict tz-aware ISO8601 parsing (Z and +HH:MM), inclusive UTC comparison, pre-run validation raising typer.BadParameter (exit 2, no reader/run started), skipping missing/invalid timestamps only when --since is set, and composability with --follow/--raw/--run-id. Visible tests pass and targeted manual checks confirm all boundary behaviors.
- last_error: (none)

## Recent Files
- .codegraph/.gitignore (173 bytes)
- .codegraph/daemon.pid (144 bytes)
- .gitignore (83 bytes)
- .mokioclaw/changes/job-readiness-goal2-20261017-b0-M08-v2-full-1/a6f9414f496645d3bb3c8eb971f660e7.bin (17801 bytes)
- .mokioclaw/changes/job-readiness-goal2-20261017-b0-M08-v2-full-1/c4b038a437ff412c8a431c7b7cabbada.bin (19460 bytes)
- .mokioclaw/changes/job-readiness-goal2-20261017-b0-M08-v2-full-1/manifest.json (894 bytes)
- .mokioclaw/diagnostics/bash-stderr-381f9b0c77d3413ab1d04bb35a90daaf.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-400efe6a30094aa5bbd83adcb89f05c8.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-432755d6883946278106c43e1b7a99ef.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-4e00b177d3804c8baa5a21dd04be06fb.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-70c50a966609401ea517b2ebf95a8c8f.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-78f203be814a498eb4d00228995ede3d.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-e69f7f49cbec41a1a6bd48604f58e7f2.log (0 bytes)
- .mokioclaw/diagnostics/bash-stderr-f12302a55fa34ffc9fe3aa18d6142ddf.log (0 bytes)
- .mokioclaw/diagnostics/bash-stdout-0c01dc5b14cf4818bdc5658c21b9968f.log (527 bytes)
- .mokioclaw/diagnostics/bash-stdout-5288f44d469442b680552151a57f2cf4.log (332 bytes)
- .mokioclaw/diagnostics/bash-stdout-6155464cc5e946fa8aa8849f3fc20ae3.log (98 bytes)
- .mokioclaw/diagnostics/bash-stdout-67efc1173ae840e3a5aa636e30792cb1.log (844 bytes)
- .mokioclaw/diagnostics/bash-stdout-6d3ae6202b4b473e9b22ee0c1ee511f3.log (663 bytes)
- .mokioclaw/diagnostics/bash-stdout-cc48e919896647e2be1b2a47eeb7f6b5.log (258 bytes)
- .mokioclaw/diagnostics/bash-stdout-e205a033797948bcbeae95aab28c9ff4.log (31 bytes)
- .mokioclaw/diagnostics/bash-stdout-f840594c80ea42ad89350087494ead0b.log (269 bytes)
- .mokioclaw/diagnostics/model-stream-0d9c52e37f2845258c51039972e59790.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-1980676d9c00480eae082cde79043d6e.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-236278d504fc4a0681b9baf5cab8e40a.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-32656c20f7f44290849aa1fb13ef3ca8.log (31 bytes)
- .mokioclaw/diagnostics/model-stream-3a66739e1934449a93a1108af629aa68.log (54 bytes)
- .mokioclaw/diagnostics/model-stream-400839f874b74db18965b0bf9b04bf78.log (1684 bytes)
- .mokioclaw/diagnostics/model-stream-4aa84a50464644a796679d4b21eda0a4.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-68ca5092fd6e44a0919d6f04404fa1a1.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-6c341c7259e34247952c50ec7c4949d4.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-85fbbe0672174022b26bf10cfcb09268.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-8e4f9040d3a147869af26b5054689f1a.log (2384 bytes)
- .mokioclaw/diagnostics/model-stream-8e641e062d9942c4abc56f6b80ac00e8.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-92695f3ab3f1430abfa01e44ddf9271f.log (2254 bytes)
- .mokioclaw/diagnostics/model-stream-afb069bbf0e647278177237916bfbea3.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-d5d70a9b12cb45f3b628d255e9aba375.log (0 bytes)
- .mokioclaw/diagnostics/model-stream-ed6fe04f4cb7461baa3732cb0b548535.log (0 bytes)
- .mokioclaw/inbox/local-72dc4eca24ee4e21adead4a0f600ba73.json (2 bytes)
- .mokioclaw/memory/repo-f463117177d937c9ea1e047a.json (6128 bytes)
